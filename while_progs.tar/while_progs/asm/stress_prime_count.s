#vars: rem=s6(slot 8), output=s1(slot 7), n=s2(slot 6), isprime=s5(slot 5), input=s1(slot 4), dm1=s4(slot 3), d=s3(slot 2), count=s1(slot 1), c=s2(slot 0), 
.text
.globl stress_prime_count
stress_prime_count:
   addi sp, sp, -8
   # s1 <- input (input)
   ld s1, 32(a0)
   
   # n := input
   mv t0, s1
   mv s2, t0
   # count := 0
   li t0, 0
   mv s1, t0
   # c := n
   mv t0, s2
   mv s2, t0
# if [c > 1]
L_cond_3:
   mv t2, s2
   li t3, 1
   blt t3, t2, L_true_4
   j L_false_19
# then
L_true_4:
   # isprime := 1
   li t0, 1
   mv s5, t0
   # d := (c - 1)
   mv t0, s2
   li t1, 1
   sub t0, t0, t1
   mv s3, t0
# if [d > 1]
L_cond_6:
   mv t2, s3
   li t3, 1
   blt t3, t2, L_true_7
   j L_false_15
# then
L_true_7:
   # rem := c
   mv t0, s2
   mv s6, t0
   # dm1 := (d - 1)
   mv t0, s3
   li t1, 1
   sub t0, t0, t1
   mv s4, t0
# if [rem > dm1]
L_cond_9:
   mv t2, s6
   mv t3, s4
   blt t3, t2, L_true_10
   j L_false_11
# then
L_true_10:
   # rem := (rem - d)
   mv t0, s6
   mv t1, s3
   sub t0, t0, t1
   mv s6, t0
   j L_cond_9
# else
# if [rem = 0]
L_false_11:
   mv t2, s6
   li t3, 0
   beq t2, t3, L_true_12
   j L_false_13
# then
L_true_12:
   # isprime := 0
   li t0, 0
   mv s5, t0
L_block_14:
   # d := (d - 1)
   mv t0, s3
   li t1, 1
   sub t0, t0, t1
   mv s3, t0
   j L_cond_6
# else
   # Skip
L_false_13:
   j L_block_14
# else
# if [isprime = 1]
L_false_15:
   mv t2, s5
   li t3, 1
   beq t2, t3, L_true_16
   j L_false_17
# then
L_true_16:
   # count := (count + 1)
   mv t0, s1
   li t1, 1
   add t0, t0, t1
   mv s1, t0
L_block_18:
   # c := (c - 1)
   mv t0, s2
   li t1, 1
   sub t0, t0, t1
   mv s2, t0
   j L_cond_3
# else
   # Skip
L_false_17:
   j L_block_18
# else
L_false_19:
   # output := count
   mv t0, s1
   mv s1, t0
   j L_return
   
L_return:
   mv a0, s1
   addi sp, sp, 8
   ret
