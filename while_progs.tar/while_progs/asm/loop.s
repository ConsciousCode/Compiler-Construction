#vars: output=s2(slot 1), n=s1(slot 0), 
.text
.globl loop
loop:
   addi sp, sp, -8
   # s1 <- input (n)
   ld s1, 0(a0)
   # s2 <- input (output)
   ld s2, 8(a0)
   
# if [n > 0]
L_cond_0:
   mv t2, s1
   li t3, 0
   blt t3, t2, L_true_1
   j L_return
# then
L_true_1:
   # output := (output + 1)
   mv t0, s2
   li t1, 1
   add t0, t0, t1
   mv s2, t0
   # n := (n - 1)
   mv t0, s1
   li t1, 1
   sub t0, t0, t1
   mv s1, t0
   j L_cond_0
   
L_return:
   mv a0, s2
   addi sp, sp, 8
   ret
