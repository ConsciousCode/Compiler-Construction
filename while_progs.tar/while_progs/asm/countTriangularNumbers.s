#vars: sum=s6(slot 6), output=s1(slot 5), n=s5(slot 4), isNumFact=s4(slot 3), i=s3(slot 2), goUpToNumber=s2(slot 1), count=s1(slot 0), 
.text
.globl countTriangularNumbers
countTriangularNumbers:
   addi sp, sp, -8
   # s2 <- input (goUpToNumber)
   ld s2, 8(a0)
   # s3 <- input (i)
   ld s3, 16(a0)
   
   # isNumFact := 0
   li t0, 0
   mv s4, t0
   # sum := 0
   li t0, 0
   mv s6, t0
   # n := 1
   li t0, 1
   mv s5, t0
   # count := 0
   li t0, 0
   mv s1, t0
# if [i < goUpToNumber]
L_cond_4:
   mv t2, s3
   mv t3, s2
   blt t2, t3, L_true_5
   j L_false_19
# then
# if [sum <= i]
L_true_5:
   mv t2, s6
   mv t3, s3
   bge t3, t2, L_true_6
   j L_false_12
# then
L_true_6:
   # sum := (sum + n)
   mv t0, s6
   mv t1, s5
   add t0, t0, t1
   mv s6, t0
# if [sum = i]
L_cond_7:
   mv t2, s6
   mv t3, s3
   beq t2, t3, L_true_8
   j L_false_10
# then
L_true_8:
   # isNumFact := 1
   li t0, 1
   mv s4, t0
   # sum := (i + 1)
   mv t0, s3
   li t1, 1
   add t0, t0, t1
   mv s6, t0
L_block_11:
   # n := (n + 1)
   mv t0, s5
   li t1, 1
   add t0, t0, t1
   mv s5, t0
   j L_true_5
# else
   # Skip
L_false_10:
   j L_block_11
# else
# if [isNumFact = 1]
L_false_12:
   mv t2, s4
   li t3, 1
   beq t2, t3, L_true_13
   j L_false_14
# then
L_true_13:
   # count := (count + 1)
   mv t0, s1
   li t1, 1
   add t0, t0, t1
   mv s1, t0
L_block_15:
   # isNumFact := 0
   li t0, 0
   mv s4, t0
   # sum := 0
   li t0, 0
   mv s6, t0
   # n := 1
   li t0, 1
   mv s5, t0
   # i := (i + 1)
   mv t0, s3
   li t1, 1
   add t0, t0, t1
   mv s3, t0
   j L_cond_4
# else
   # Skip
L_false_14:
   j L_block_15
# else
L_false_19:
   # output := count
   mv t0, s1
   mv s1, t0
   j L_return
   
L_return:
   mv a0, s1
   addi sp, sp, 8
   ret
