#vars: t=[spill @slot 35], s=[spill @slot 34], output=s1(slot 33), k=[spill @slot 32], j=s1(slot 31), i=s2(slot 30), c_2_2=s3(slot 29), c_2_1=s4(slot 28), c_2_0=s5(slot 27), c_1_2=s6(slot 26), c_1_1=s7(slot 25), c_1_0=s8(slot 24), c_0_2=s9(slot 23), c_0_1=s10(slot 22), c_0_0=s11(slot 21), c=[spill @slot 20], b_2_2=[spill @slot 19], b_2_1=[spill @slot 18], b_2_0=[spill @slot 17], b_1_2=[spill @slot 16], b_1_1=[spill @slot 15], b_1_0=[spill @slot 14], b_0_2=[spill @slot 13], b_0_1=[spill @slot 12], b_0_0=[spill @slot 11], b=[spill @slot 10], a_2_2=[spill @slot 9], a_2_1=[spill @slot 8], a_2_0=[spill @slot 7], a_1_2=[spill @slot 6], a_1_1=[spill @slot 5], a_1_0=[spill @slot 4], a_0_2=[spill @slot 3], a_0_1=[spill @slot 2], a_0_0=[spill @slot 1], a=[spill @slot 0], 
.text
.globl pseudomatrices
pseudomatrices:
   addi sp, sp, -16
   
   # c_0_0 := 0
   li t0, 0
   mv s11, t0
   # c_0_1 := 0
   li t0, 0
   mv s10, t0
   # c_0_2 := 0
   li t0, 0
   mv s9, t0
   # c_1_0 := 0
   li t0, 0
   mv s8, t0
   # c_1_1 := 0
   li t0, 0
   mv s7, t0
   # c_1_2 := 0
   li t0, 0
   mv s6, t0
   # c_2_0 := 0
   li t0, 0
   mv s5, t0
   # c_2_1 := 0
   li t0, 0
   mv s4, t0
   # c_2_2 := 0
   li t0, 0
   mv s3, t0
   # i := 0
   li t0, 0
   mv s2, t0
# if [i < 3]
L_cond_10:
   mv t2, s2
   li t3, 3
   blt t2, t3, L_true_11
   j L_false_95
# then
L_true_11:
   # j := 0
   li t0, 0
   mv s1, t0
# if [j < 3]
L_cond_12:
   mv t2, s1
   li t3, 3
   blt t2, t3, L_true_13
   j L_false_94
# then
L_true_13:
   # s := 0
   li t0, 0
   sd t0, 272(a0)
   # k := 0
   li t0, 0
   sd t0, 256(a0)
# if [k < 3]
L_cond_15:
   ld t2, 256(a0)
   li t3, 3
   blt t2, t3, L_true_16
   j L_false_68
# then
# if [i = 0]
L_true_16:
   mv t2, s2
   li t3, 0
   beq t2, t3, L_true_17
   j L_false_24
# then
# if [k = 0]
L_true_17:
   ld t2, 256(a0)
   li t3, 0
   beq t2, t3, L_true_18
   j L_false_19
# then
L_true_18:
   # a := a_0_0
   ld t0, 8(a0)
   sd t0, 0(a0)
# if [k = 0]
L_cond_41:
   ld t2, 256(a0)
   li t3, 0
   beq t2, t3, L_true_42
   j L_false_49
# then
# if [j = 0]
L_true_42:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_true_43
   j L_false_44
# then
L_true_43:
   # b := b_0_0
   ld t0, 88(a0)
   sd t0, 80(a0)
L_block_66:
   # s := (s + (a * b))
   ld t0, 272(a0)
   sd t0, 0(sp)
   ld t0, 0(a0)
   ld t1, 80(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 272(a0)
   # k := (k + 1)
   ld t0, 256(a0)
   li t1, 1
   add t0, t0, t1
   sd t0, 256(a0)
   j L_cond_15
# else
# if [j = 1]
L_false_44:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_true_45
   j L_false_46
# then
L_true_45:
   # b := b_0_1
   ld t0, 96(a0)
   sd t0, 80(a0)
   j L_block_66
# else
# if [j = 2]
L_false_46:
   mv t2, s1
   li t3, 2
   beq t2, t3, L_true_47
   j L_false_48
# then
L_true_47:
   # b := b_0_2
   ld t0, 104(a0)
   sd t0, 80(a0)
   j L_block_66
# else
L_false_48:
   # b := 0
   li t0, 0
   sd t0, 80(a0)
   j L_block_66
# else
# if [k = 1]
L_false_49:
   ld t2, 256(a0)
   li t3, 1
   beq t2, t3, L_true_50
   j L_false_57
# then
# if [j = 0]
L_true_50:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_true_51
   j L_false_52
# then
L_true_51:
   # b := b_1_0
   ld t0, 112(a0)
   sd t0, 80(a0)
   j L_block_66
# else
# if [j = 1]
L_false_52:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_true_53
   j L_false_54
# then
L_true_53:
   # b := b_1_1
   ld t0, 120(a0)
   sd t0, 80(a0)
   j L_block_66
# else
# if [j = 2]
L_false_54:
   mv t2, s1
   li t3, 2
   beq t2, t3, L_true_55
   j L_false_56
# then
L_true_55:
   # b := b_1_2
   ld t0, 128(a0)
   sd t0, 80(a0)
   j L_block_66
# else
L_false_56:
   # b := 0
   li t0, 0
   sd t0, 80(a0)
   j L_block_66
# else
# if [k = 2]
L_false_57:
   ld t2, 256(a0)
   li t3, 2
   beq t2, t3, L_true_58
   j L_false_65
# then
# if [j = 0]
L_true_58:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_true_59
   j L_false_60
# then
L_true_59:
   # b := b_2_0
   ld t0, 136(a0)
   sd t0, 80(a0)
   j L_block_66
# else
# if [j = 1]
L_false_60:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_true_61
   j L_false_62
# then
L_true_61:
   # b := b_2_1
   ld t0, 144(a0)
   sd t0, 80(a0)
   j L_block_66
# else
# if [j = 2]
L_false_62:
   mv t2, s1
   li t3, 2
   beq t2, t3, L_true_63
   j L_false_64
# then
L_true_63:
   # b := b_2_2
   ld t0, 152(a0)
   sd t0, 80(a0)
   j L_block_66
# else
L_false_64:
   # b := 0
   li t0, 0
   sd t0, 80(a0)
   j L_block_66
# else
L_false_65:
   # b := 0
   li t0, 0
   sd t0, 80(a0)
   j L_block_66
# else
# if [k = 1]
L_false_19:
   ld t2, 256(a0)
   li t3, 1
   beq t2, t3, L_true_20
   j L_false_21
# then
L_true_20:
   # a := a_0_1
   ld t0, 16(a0)
   sd t0, 0(a0)
   j L_cond_41
# else
# if [k = 2]
L_false_21:
   ld t2, 256(a0)
   li t3, 2
   beq t2, t3, L_true_22
   j L_false_23
# then
L_true_22:
   # a := a_0_2
   ld t0, 24(a0)
   sd t0, 0(a0)
   j L_cond_41
# else
L_false_23:
   # a := 0
   li t0, 0
   sd t0, 0(a0)
   j L_cond_41
# else
# if [i = 1]
L_false_24:
   mv t2, s2
   li t3, 1
   beq t2, t3, L_true_25
   j L_false_32
# then
# if [k = 0]
L_true_25:
   ld t2, 256(a0)
   li t3, 0
   beq t2, t3, L_true_26
   j L_false_27
# then
L_true_26:
   # a := a_1_0
   ld t0, 32(a0)
   sd t0, 0(a0)
   j L_cond_41
# else
# if [k = 1]
L_false_27:
   ld t2, 256(a0)
   li t3, 1
   beq t2, t3, L_true_28
   j L_false_29
# then
L_true_28:
   # a := a_1_1
   ld t0, 40(a0)
   sd t0, 0(a0)
   j L_cond_41
# else
# if [k = 2]
L_false_29:
   ld t2, 256(a0)
   li t3, 2
   beq t2, t3, L_true_30
   j L_false_31
# then
L_true_30:
   # a := a_1_2
   ld t0, 48(a0)
   sd t0, 0(a0)
   j L_cond_41
# else
L_false_31:
   # a := 0
   li t0, 0
   sd t0, 0(a0)
   j L_cond_41
# else
# if [i = 2]
L_false_32:
   mv t2, s2
   li t3, 2
   beq t2, t3, L_true_33
   j L_false_40
# then
# if [k = 0]
L_true_33:
   ld t2, 256(a0)
   li t3, 0
   beq t2, t3, L_true_34
   j L_false_35
# then
L_true_34:
   # a := a_2_0
   ld t0, 56(a0)
   sd t0, 0(a0)
   j L_cond_41
# else
# if [k = 1]
L_false_35:
   ld t2, 256(a0)
   li t3, 1
   beq t2, t3, L_true_36
   j L_false_37
# then
L_true_36:
   # a := a_2_1
   ld t0, 64(a0)
   sd t0, 0(a0)
   j L_cond_41
# else
# if [k = 2]
L_false_37:
   ld t2, 256(a0)
   li t3, 2
   beq t2, t3, L_true_38
   j L_false_39
# then
L_true_38:
   # a := a_2_2
   ld t0, 72(a0)
   sd t0, 0(a0)
   j L_cond_41
# else
L_false_39:
   # a := 0
   li t0, 0
   sd t0, 0(a0)
   j L_cond_41
# else
L_false_40:
   # a := 0
   li t0, 0
   sd t0, 0(a0)
   j L_cond_41
# else
# if [i = 0]
L_false_68:
   mv t2, s2
   li t3, 0
   beq t2, t3, L_true_69
   j L_false_76
# then
# if [j = 0]
L_true_69:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_true_70
   j L_false_71
# then
L_true_70:
   # c_0_0 := s
   ld t0, 272(a0)
   mv s11, t0
L_block_93:
   # j := (j + 1)
   mv t0, s1
   li t1, 1
   add t0, t0, t1
   mv s1, t0
   j L_cond_12
# else
# if [j = 1]
L_false_71:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_true_72
   j L_false_73
# then
L_true_72:
   # c_0_1 := s
   ld t0, 272(a0)
   mv s10, t0
   j L_block_93
# else
# if [j = 2]
L_false_73:
   mv t2, s1
   li t3, 2
   beq t2, t3, L_true_74
   j L_false_75
# then
L_true_74:
   # c_0_2 := s
   ld t0, 272(a0)
   mv s9, t0
   j L_block_93
# else
   # Skip
L_false_75:
   j L_block_93
# else
# if [i = 1]
L_false_76:
   mv t2, s2
   li t3, 1
   beq t2, t3, L_true_77
   j L_false_84
# then
# if [j = 0]
L_true_77:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_true_78
   j L_false_79
# then
L_true_78:
   # c_1_0 := s
   ld t0, 272(a0)
   mv s8, t0
   j L_block_93
# else
# if [j = 1]
L_false_79:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_true_80
   j L_false_81
# then
L_true_80:
   # c_1_1 := s
   ld t0, 272(a0)
   mv s7, t0
   j L_block_93
# else
# if [j = 2]
L_false_81:
   mv t2, s1
   li t3, 2
   beq t2, t3, L_true_82
   j L_false_83
# then
L_true_82:
   # c_1_2 := s
   ld t0, 272(a0)
   mv s6, t0
   j L_block_93
# else
   # Skip
L_false_83:
   j L_block_93
# else
# if [i = 2]
L_false_84:
   mv t2, s2
   li t3, 2
   beq t2, t3, L_true_85
   j L_false_92
# then
# if [j = 0]
L_true_85:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_true_86
   j L_false_87
# then
L_true_86:
   # c_2_0 := s
   ld t0, 272(a0)
   mv s5, t0
   j L_block_93
# else
# if [j = 1]
L_false_87:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_true_88
   j L_false_89
# then
L_true_88:
   # c_2_1 := s
   ld t0, 272(a0)
   mv s4, t0
   j L_block_93
# else
# if [j = 2]
L_false_89:
   mv t2, s1
   li t3, 2
   beq t2, t3, L_true_90
   j L_false_91
# then
L_true_90:
   # c_2_2 := s
   ld t0, 272(a0)
   mv s3, t0
   j L_block_93
# else
   # Skip
L_false_91:
   j L_block_93
# else
   # Skip
L_false_92:
   j L_block_93
# else
L_false_94:
   # i := (i + 1)
   mv t0, s2
   li t1, 1
   add t0, t0, t1
   mv s2, t0
   j L_cond_10
# else
L_false_95:
   # t := 0
   li t0, 0
   sd t0, 280(a0)
   # i := 0
   li t0, 0
   mv s2, t0
# if [i < 3]
L_cond_97:
   mv t2, s2
   li t3, 3
   blt t2, t3, L_true_98
   j L_false_128
# then
L_true_98:
   # j := 0
   li t0, 0
   mv s1, t0
# if [j < 3]
L_cond_99:
   mv t2, s1
   li t3, 3
   blt t2, t3, L_true_100
   j L_false_127
# then
# if [i = 0]
L_true_100:
   mv t2, s2
   li t3, 0
   beq t2, t3, L_true_101
   j L_false_108
# then
# if [j = 0]
L_true_101:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_true_102
   j L_false_103
# then
L_true_102:
   # c := c_0_0
   mv t0, s11
   sd t0, 160(a0)
L_block_125:
   # t := (t + c)
   ld t0, 280(a0)
   ld t1, 160(a0)
   add t0, t0, t1
   sd t0, 280(a0)
   # j := (j + 1)
   mv t0, s1
   li t1, 1
   add t0, t0, t1
   mv s1, t0
   j L_cond_99
# else
# if [j = 1]
L_false_103:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_true_104
   j L_false_105
# then
L_true_104:
   # c := c_0_1
   mv t0, s10
   sd t0, 160(a0)
   j L_block_125
# else
# if [j = 2]
L_false_105:
   mv t2, s1
   li t3, 2
   beq t2, t3, L_true_106
   j L_false_107
# then
L_true_106:
   # c := c_0_2
   mv t0, s9
   sd t0, 160(a0)
   j L_block_125
# else
L_false_107:
   # c := 0
   li t0, 0
   sd t0, 160(a0)
   j L_block_125
# else
# if [i = 1]
L_false_108:
   mv t2, s2
   li t3, 1
   beq t2, t3, L_true_109
   j L_false_116
# then
# if [j = 0]
L_true_109:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_true_110
   j L_false_111
# then
L_true_110:
   # c := c_1_0
   mv t0, s8
   sd t0, 160(a0)
   j L_block_125
# else
# if [j = 1]
L_false_111:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_true_112
   j L_false_113
# then
L_true_112:
   # c := c_1_1
   mv t0, s7
   sd t0, 160(a0)
   j L_block_125
# else
# if [j = 2]
L_false_113:
   mv t2, s1
   li t3, 2
   beq t2, t3, L_true_114
   j L_false_115
# then
L_true_114:
   # c := c_1_2
   mv t0, s6
   sd t0, 160(a0)
   j L_block_125
# else
L_false_115:
   # c := 0
   li t0, 0
   sd t0, 160(a0)
   j L_block_125
# else
# if [i = 2]
L_false_116:
   mv t2, s2
   li t3, 2
   beq t2, t3, L_true_117
   j L_false_124
# then
# if [j = 0]
L_true_117:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_true_118
   j L_false_119
# then
L_true_118:
   # c := c_2_0
   mv t0, s5
   sd t0, 160(a0)
   j L_block_125
# else
# if [j = 1]
L_false_119:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_true_120
   j L_false_121
# then
L_true_120:
   # c := c_2_1
   mv t0, s4
   sd t0, 160(a0)
   j L_block_125
# else
# if [j = 2]
L_false_121:
   mv t2, s1
   li t3, 2
   beq t2, t3, L_true_122
   j L_false_123
# then
L_true_122:
   # c := c_2_2
   mv t0, s3
   sd t0, 160(a0)
   j L_block_125
# else
L_false_123:
   # c := 0
   li t0, 0
   sd t0, 160(a0)
   j L_block_125
# else
L_false_124:
   # c := 0
   li t0, 0
   sd t0, 160(a0)
   j L_block_125
# else
L_false_127:
   # i := (i + 1)
   mv t0, s2
   li t1, 1
   add t0, t0, t1
   mv s2, t0
   j L_cond_97
# else
L_false_128:
   # output := t
   ld t0, 280(a0)
   mv s1, t0
   j L_return
   
L_return:
   mv a0, s1
   addi sp, sp, 16
   ret
