#vars: z=s4(slot 5), t=s4(slot 4), output=s1(slot 3), n=s3(slot 2), b=s2(slot 1), a=s1(slot 0), 
.text
.globl fibonacci
fibonacci:
   addi sp, sp, -8
   # s3 <- input (n)
   ld s3, 16(a0)
   
   # a := 0
   li t0, 0
   mv s1, t0
   # b := 1
   li t0, 1
   mv s2, t0
   # z := 0
   li t0, 0
   mv s4, t0
# if not [[n = z]]
L_cond_3:
   mv t2, s3
   mv t3, s4
   beq t2, t3, L_false_9
   j L_true_4
# then
L_true_4:
   # t := (a + b)
   mv t0, s1
   mv t1, s2
   add t0, t0, t1
   mv s4, t0
   # a := b
   mv t0, s2
   mv s1, t0
   # b := t
   mv t0, s4
   mv s2, t0
   # n := (n - 1)
   mv t0, s3
   li t1, 1
   sub t0, t0, t1
   mv s3, t0
   # z := 0
   li t0, 0
   mv s4, t0
   j L_cond_3
# else
L_false_9:
   # output := a
   mv t0, s1
   mv s1, t0
   j L_return
   
L_return:
   mv a0, s1
   addi sp, sp, 8
   ret
