#vars: z=s2(slot 3), y=s1(slot 2), x=s1(slot 1), output=s1(slot 0), 
.text
.globl factorial
factorial:
   addi sp, sp, -8
   # s1 <- input (x)
   ld s1, 8(a0)
   
   # y := x
   mv t0, s1
   mv s1, t0
   # z := 1
   li t0, 1
   mv s2, t0
# if [y > 1]
L_cond_2:
   mv t2, s1
   li t3, 1
   blt t3, t2, L_true_3
   j L_false_6
# then
L_true_3:
   # z := (z * y)
   mv t0, s2
   mv t1, s1
   mul t0, t0, t1
   mv s2, t0
   # y := (y - 1)
   mv t0, s1
   li t1, 1
   sub t0, t0, t1
   mv s1, t0
   j L_cond_2
# else
L_false_6:
   # output := z
   mv t0, s2
   mv s1, t0
   j L_return
   
L_return:
   mv a0, s1
   addi sp, sp, 8
   ret
