#vars: output=s1(slot 4), j=s4(slot 3), input=s3(slot 2), i=s2(slot 1), composite=s1(slot 0), 
.text
.globl isprime
isprime:
   addi sp, sp, -8
   # s3 <- input (input)
   ld s3, 16(a0)
   
   # composite := 0
   li t0, 0
   mv s1, t0
   # i := 2
   li t0, 2
   mv s2, t0
# if [[i < input] and [composite = 0]]
L_cond_2:
   mv t2, s2
   mv t3, s3
   blt t2, t3, L_and_0
   j L_false_9
L_and_0:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_true_3
   j L_false_9
# then
L_true_3:
   # j := 1
   li t0, 1
   mv s4, t0
# if [(i * j) < input]
L_cond_4:
   mv t0, s2
   mv t1, s4
   mul t2, t0, t1
   mv t3, s3
   blt t2, t3, L_true_5
   j L_false_6
# then
L_true_5:
   # j := (j + 1)
   mv t0, s4
   li t1, 1
   add t0, t0, t1
   mv s4, t0
   j L_cond_4
# else
# if [(i * j) = input]
L_false_6:
   mv t0, s2
   mv t1, s4
   mul t2, t0, t1
   mv t3, s3
   beq t2, t3, L_true_7
   j L_false_8
# then
L_true_7:
   # composite := 1
   li t0, 1
   mv s1, t0
   j L_cond_2
# else
L_false_8:
   # i := (i + 1)
   mv t0, s2
   li t1, 1
   add t0, t0, t1
   mv s2, t0
   j L_cond_2
# else
L_false_9:
   # output := (1 - composite)
   li t0, 1
   mv t1, s1
   sub t0, t0, t1
   mv s1, t0
   j L_return
   
L_return:
   mv a0, s1
   addi sp, sp, 8
   ret
