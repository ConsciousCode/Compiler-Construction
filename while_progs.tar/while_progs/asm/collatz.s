#vars: steps=s4(slot 5), rem=s3(slot 4), quot=s2(slot 3), output=s1(slot 2), n=s1(slot 1), input=s1(slot 0), 
.text
.globl collatz
collatz:
   addi sp, sp, -16
   # s1 <- input (input)
   ld s1, 0(a0)
   
   # n := input
   mv t0, s1
   mv s1, t0
   # steps := 0
   li t0, 0
   mv s4, t0
# if [n > 1]
L_cond_2:
   mv t2, s1
   li t3, 1
   blt t3, t2, L_true_3
   j L_false_12
# then
L_true_3:
   # rem := n
   mv t0, s1
   mv s3, t0
   # quot := 0
   li t0, 0
   mv s2, t0
# if [rem > 1]
L_cond_5:
   mv t2, s3
   li t3, 1
   blt t3, t2, L_true_6
   j L_false_8
# then
L_true_6:
   # rem := (rem - 2)
   mv t0, s3
   li t1, 2
   sub t0, t0, t1
   mv s3, t0
   # quot := (quot + 1)
   mv t0, s2
   li t1, 1
   add t0, t0, t1
   mv s2, t0
   j L_cond_5
# else
# if [rem = 0]
L_false_8:
   mv t2, s3
   li t3, 0
   beq t2, t3, L_true_9
   j L_false_10
# then
L_true_9:
   # n := quot
   mv t0, s2
   mv s1, t0
L_block_11:
   # steps := (steps + 1)
   mv t0, s4
   li t1, 1
   add t0, t0, t1
   mv s4, t0
   j L_cond_2
# else
L_false_10:
   # n := ((3 * n) + 1)
   li t0, 3
   mv t1, s1
   mul t0, t0, t1
   li t1, 1
   add t0, t0, t1
   mv s1, t0
   j L_block_11
# else
L_false_12:
   # output := steps
   mv t0, s4
   mv s1, t0
   j L_return
   
L_return:
   mv a0, s1
   addi sp, sp, 16
   ret
