#vars: stop1=s6(slot 8), stop=s5(slot 7), sqrt=s4(slot 6), output=s1(slot 5), mod=s1(slot 4), j=s3(slot 3), input=s2(slot 2), i=s2(slot 1), closestprime=s1(slot 0), 
.text
.globl closest_prime
closest_prime:
   addi sp, sp, -8
   # s2 <- input (input)
   ld s2, 16(a0)
   
   # mod := input
   mv t0, s2
   mv s1, t0
# if not [[[mod = 1] or [mod = 0]]]
L_cond_1:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_false_3
   j L_or_0
L_or_0:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_false_3
   j L_true_2
# then
L_true_2:
   # mod := (mod - 2)
   mv t0, s1
   li t1, 2
   sub t0, t0, t1
   mv s1, t0
   j L_cond_1
# else
# if [mod = 1]
L_false_3:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_true_4
   j L_false_5
# then
L_true_4:
   # input := (input - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
L_block_6:
   # i := input
   mv t0, s2
   mv s2, t0
   # stop1 := 0
   li t0, 0
   mv s6, t0
# if [[i >= 2] and [stop1 = 0]]
L_cond_8:
   mv t2, s2
   li t3, 2
   bge t2, t3, L_and_1
   j L_false_24
L_and_1:
   mv t2, s6
   li t3, 0
   beq t2, t3, L_true_9
   j L_false_24
# then
L_true_9:
   # sqrt := 1
   li t0, 1
   mv s4, t0
# if [(sqrt * sqrt) <= i]
L_cond_10:
   mv t0, s4
   mv t1, s4
   mul t2, t0, t1
   mv t3, s2
   bge t3, t2, L_true_11
   j L_false_12
# then
L_true_11:
   # sqrt := (sqrt + 1)
   mv t0, s4
   li t1, 1
   add t0, t0, t1
   mv s4, t0
   j L_cond_10
# else
L_false_12:
   # j := 3
   li t0, 3
   mv s3, t0
   # stop := 0
   li t0, 0
   mv s5, t0
# if [[j <= sqrt] and [stop = 0]]
L_cond_14:
   mv t2, s3
   mv t3, s4
   bge t3, t2, L_and_2
   j L_false_21
L_and_2:
   mv t2, s5
   li t3, 0
   beq t2, t3, L_true_15
   j L_false_21
# then
L_true_15:
   # mod := i
   mv t0, s2
   mv s1, t0
# if [mod > 0]
L_cond_16:
   mv t2, s1
   li t3, 0
   blt t3, t2, L_true_17
   j L_false_18
# then
L_true_17:
   # mod := (mod - j)
   mv t0, s1
   mv t1, s3
   sub t0, t0, t1
   mv s1, t0
   j L_cond_16
# else
# if [mod = 0]
L_false_18:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_true_19
   j L_false_20
# then
L_true_19:
   # stop := 1
   li t0, 1
   mv s5, t0
   j L_cond_14
# else
L_false_20:
   # j := (j + 2)
   mv t0, s3
   li t1, 2
   add t0, t0, t1
   mv s3, t0
   j L_cond_14
# else
# if [j > sqrt]
L_false_21:
   mv t2, s3
   mv t3, s4
   blt t3, t2, L_true_22
   j L_false_23
# then
L_true_22:
   # stop1 := 1
   li t0, 1
   mv s6, t0
   j L_cond_8
# else
L_false_23:
   # i := (i - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
   j L_cond_8
# else
L_false_24:
   # closestprime := i
   mv t0, s2
   mv s1, t0
   # output := closestprime
   mv t0, s1
   mv s1, t0
   j L_return
# else
L_false_5:
   # input := (input - 1)
   mv t0, s2
   li t1, 1
   sub t0, t0, t1
   mv s2, t0
   j L_block_6
   
L_return:
   mv a0, s1
   addi sp, sp, 8
   ret
