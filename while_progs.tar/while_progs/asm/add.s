#vars: z=s1(slot 3), y=s2(slot 2), x=s1(slot 1), output=s1(slot 0), 
.text
.globl add
add:
   addi sp, sp, -8
   
   # x := 1
   li t0, 1
   mv s1, t0
   # y := 2
   li t0, 2
   mv s2, t0
   # z := (x + y)
   mv t0, s1
   mv t1, s2
   add t0, t0, t1
   mv s1, t0
   # output := z
   mv t0, s1
   mv s1, t0
   j L_return
   
L_return:
   mv a0, s1
   addi sp, sp, 8
   ret
