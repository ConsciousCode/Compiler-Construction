#vars: stop1=s6(slot 8), stop=s5(slot 7), sqrt=s4(slot 6), output=s1(slot 5), mod=s1(slot 4), j=s3(slot 3), input=s2(slot 2), i=s2(slot 1), closestprime=s1(slot 0), 
.text
.globl chain_prime
chain_prime:
   addi sp, sp, -8
   # s2 <- input (input)
   ld s2, 16(a0)
   
   # mod := input
   mv t0, s2
   mv s1, t0
# if not [[[mod = 1] or [mod = 0]]]
L_cond_1:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_false_3
   j L_or_0
L_or_0:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_false_3
   j L_true_2
# then
L_true_2:
   # mod := (mod - 2)
   mv t0, s1
   li t1, 2
   sub t0, t0, t1
   mv s1, t0
   j L_cond_1
# else
# if [mod = 1]
L_false_3:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_true_4
   j L_false_5
# then
L_true_4:
   # input := (input - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
L_block_6:
   # i := input
   mv t0, s2
   mv s2, t0
   # stop1 := 0
   li t0, 0
   mv s6, t0
# if [[i >= 2] and [stop1 = 0]]
L_cond_8:
   mv t2, s2
   li t3, 2
   bge t2, t3, L_and_1
   j L_false_24
L_and_1:
   mv t2, s6
   li t3, 0
   beq t2, t3, L_true_9
   j L_false_24
# then
L_true_9:
   # sqrt := 1
   li t0, 1
   mv s4, t0
# if [(sqrt * sqrt) <= i]
L_cond_10:
   mv t0, s4
   mv t1, s4
   mul t2, t0, t1
   mv t3, s2
   bge t3, t2, L_true_11
   j L_false_12
# then
L_true_11:
   # sqrt := (sqrt + 1)
   mv t0, s4
   li t1, 1
   add t0, t0, t1
   mv s4, t0
   j L_cond_10
# else
L_false_12:
   # j := 3
   li t0, 3
   mv s3, t0
   # stop := 0
   li t0, 0
   mv s5, t0
# if [[j <= sqrt] and [stop = 0]]
L_cond_14:
   mv t2, s3
   mv t3, s4
   bge t3, t2, L_and_2
   j L_false_21
L_and_2:
   mv t2, s5
   li t3, 0
   beq t2, t3, L_true_15
   j L_false_21
# then
L_true_15:
   # mod := i
   mv t0, s2
   mv s1, t0
# if [mod > 0]
L_cond_16:
   mv t2, s1
   li t3, 0
   blt t3, t2, L_true_17
   j L_false_18
# then
L_true_17:
   # mod := (mod - j)
   mv t0, s1
   mv t1, s3
   sub t0, t0, t1
   mv s1, t0
   j L_cond_16
# else
# if [mod = 0]
L_false_18:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_true_19
   j L_false_20
# then
L_true_19:
   # stop := 1
   li t0, 1
   mv s5, t0
   j L_cond_14
# else
L_false_20:
   # j := (j + 2)
   mv t0, s3
   li t1, 2
   add t0, t0, t1
   mv s3, t0
   j L_cond_14
# else
# if [j > sqrt]
L_false_21:
   mv t2, s3
   mv t3, s4
   blt t3, t2, L_true_22
   j L_false_23
# then
L_true_22:
   # stop1 := 1
   li t0, 1
   mv s6, t0
   j L_cond_8
# else
L_false_23:
   # i := (i - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
   j L_cond_8
# else
L_false_24:
   # closestprime := i
   mv t0, s2
   mv s1, t0
   # output := closestprime
   mv t0, s1
   mv s1, t0
   # input := output
   mv t0, s1
   mv s2, t0
   # mod := input
   mv t0, s2
   mv s1, t0
# if not [[[mod = 1] or [mod = 0]]]
L_cond_28:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_false_30
   j L_or_3
L_or_3:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_false_30
   j L_true_29
# then
L_true_29:
   # mod := (mod - 2)
   mv t0, s1
   li t1, 2
   sub t0, t0, t1
   mv s1, t0
   j L_cond_28
# else
# if [mod = 1]
L_false_30:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_true_31
   j L_false_32
# then
L_true_31:
   # input := (input - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
L_block_33:
   # i := input
   mv t0, s2
   mv s2, t0
   # stop1 := 0
   li t0, 0
   mv s6, t0
# if [[i >= 2] and [stop1 = 0]]
L_cond_35:
   mv t2, s2
   li t3, 2
   bge t2, t3, L_and_4
   j L_false_51
L_and_4:
   mv t2, s6
   li t3, 0
   beq t2, t3, L_true_36
   j L_false_51
# then
L_true_36:
   # sqrt := 1
   li t0, 1
   mv s4, t0
# if [(sqrt * sqrt) <= i]
L_cond_37:
   mv t0, s4
   mv t1, s4
   mul t2, t0, t1
   mv t3, s2
   bge t3, t2, L_true_38
   j L_false_39
# then
L_true_38:
   # sqrt := (sqrt + 1)
   mv t0, s4
   li t1, 1
   add t0, t0, t1
   mv s4, t0
   j L_cond_37
# else
L_false_39:
   # j := 3
   li t0, 3
   mv s3, t0
   # stop := 0
   li t0, 0
   mv s5, t0
# if [[j <= sqrt] and [stop = 0]]
L_cond_41:
   mv t2, s3
   mv t3, s4
   bge t3, t2, L_and_5
   j L_false_48
L_and_5:
   mv t2, s5
   li t3, 0
   beq t2, t3, L_true_42
   j L_false_48
# then
L_true_42:
   # mod := i
   mv t0, s2
   mv s1, t0
# if [mod > 0]
L_cond_43:
   mv t2, s1
   li t3, 0
   blt t3, t2, L_true_44
   j L_false_45
# then
L_true_44:
   # mod := (mod - j)
   mv t0, s1
   mv t1, s3
   sub t0, t0, t1
   mv s1, t0
   j L_cond_43
# else
# if [mod = 0]
L_false_45:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_true_46
   j L_false_47
# then
L_true_46:
   # stop := 1
   li t0, 1
   mv s5, t0
   j L_cond_41
# else
L_false_47:
   # j := (j + 2)
   mv t0, s3
   li t1, 2
   add t0, t0, t1
   mv s3, t0
   j L_cond_41
# else
# if [j > sqrt]
L_false_48:
   mv t2, s3
   mv t3, s4
   blt t3, t2, L_true_49
   j L_false_50
# then
L_true_49:
   # stop1 := 1
   li t0, 1
   mv s6, t0
   j L_cond_35
# else
L_false_50:
   # i := (i - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
   j L_cond_35
# else
L_false_51:
   # closestprime := i
   mv t0, s2
   mv s1, t0
   # output := closestprime
   mv t0, s1
   mv s1, t0
   # input := output
   mv t0, s1
   mv s2, t0
   # mod := input
   mv t0, s2
   mv s1, t0
# if not [[[mod = 1] or [mod = 0]]]
L_cond_55:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_false_57
   j L_or_6
L_or_6:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_false_57
   j L_true_56
# then
L_true_56:
   # mod := (mod - 2)
   mv t0, s1
   li t1, 2
   sub t0, t0, t1
   mv s1, t0
   j L_cond_55
# else
# if [mod = 1]
L_false_57:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_true_58
   j L_false_59
# then
L_true_58:
   # input := (input - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
L_block_60:
   # i := input
   mv t0, s2
   mv s2, t0
   # stop1 := 0
   li t0, 0
   mv s6, t0
# if [[i >= 2] and [stop1 = 0]]
L_cond_62:
   mv t2, s2
   li t3, 2
   bge t2, t3, L_and_7
   j L_false_78
L_and_7:
   mv t2, s6
   li t3, 0
   beq t2, t3, L_true_63
   j L_false_78
# then
L_true_63:
   # sqrt := 1
   li t0, 1
   mv s4, t0
# if [(sqrt * sqrt) <= i]
L_cond_64:
   mv t0, s4
   mv t1, s4
   mul t2, t0, t1
   mv t3, s2
   bge t3, t2, L_true_65
   j L_false_66
# then
L_true_65:
   # sqrt := (sqrt + 1)
   mv t0, s4
   li t1, 1
   add t0, t0, t1
   mv s4, t0
   j L_cond_64
# else
L_false_66:
   # j := 3
   li t0, 3
   mv s3, t0
   # stop := 0
   li t0, 0
   mv s5, t0
# if [[j <= sqrt] and [stop = 0]]
L_cond_68:
   mv t2, s3
   mv t3, s4
   bge t3, t2, L_and_8
   j L_false_75
L_and_8:
   mv t2, s5
   li t3, 0
   beq t2, t3, L_true_69
   j L_false_75
# then
L_true_69:
   # mod := i
   mv t0, s2
   mv s1, t0
# if [mod > 0]
L_cond_70:
   mv t2, s1
   li t3, 0
   blt t3, t2, L_true_71
   j L_false_72
# then
L_true_71:
   # mod := (mod - j)
   mv t0, s1
   mv t1, s3
   sub t0, t0, t1
   mv s1, t0
   j L_cond_70
# else
# if [mod = 0]
L_false_72:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_true_73
   j L_false_74
# then
L_true_73:
   # stop := 1
   li t0, 1
   mv s5, t0
   j L_cond_68
# else
L_false_74:
   # j := (j + 2)
   mv t0, s3
   li t1, 2
   add t0, t0, t1
   mv s3, t0
   j L_cond_68
# else
# if [j > sqrt]
L_false_75:
   mv t2, s3
   mv t3, s4
   blt t3, t2, L_true_76
   j L_false_77
# then
L_true_76:
   # stop1 := 1
   li t0, 1
   mv s6, t0
   j L_cond_62
# else
L_false_77:
   # i := (i - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
   j L_cond_62
# else
L_false_78:
   # closestprime := i
   mv t0, s2
   mv s1, t0
   # output := closestprime
   mv t0, s1
   mv s1, t0
   # input := output
   mv t0, s1
   mv s2, t0
   # mod := input
   mv t0, s2
   mv s1, t0
# if not [[[mod = 1] or [mod = 0]]]
L_cond_82:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_false_84
   j L_or_9
L_or_9:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_false_84
   j L_true_83
# then
L_true_83:
   # mod := (mod - 2)
   mv t0, s1
   li t1, 2
   sub t0, t0, t1
   mv s1, t0
   j L_cond_82
# else
# if [mod = 1]
L_false_84:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_true_85
   j L_false_86
# then
L_true_85:
   # input := (input - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
L_block_87:
   # i := input
   mv t0, s2
   mv s2, t0
   # stop1 := 0
   li t0, 0
   mv s6, t0
# if [[i >= 2] and [stop1 = 0]]
L_cond_89:
   mv t2, s2
   li t3, 2
   bge t2, t3, L_and_10
   j L_false_105
L_and_10:
   mv t2, s6
   li t3, 0
   beq t2, t3, L_true_90
   j L_false_105
# then
L_true_90:
   # sqrt := 1
   li t0, 1
   mv s4, t0
# if [(sqrt * sqrt) <= i]
L_cond_91:
   mv t0, s4
   mv t1, s4
   mul t2, t0, t1
   mv t3, s2
   bge t3, t2, L_true_92
   j L_false_93
# then
L_true_92:
   # sqrt := (sqrt + 1)
   mv t0, s4
   li t1, 1
   add t0, t0, t1
   mv s4, t0
   j L_cond_91
# else
L_false_93:
   # j := 3
   li t0, 3
   mv s3, t0
   # stop := 0
   li t0, 0
   mv s5, t0
# if [[j <= sqrt] and [stop = 0]]
L_cond_95:
   mv t2, s3
   mv t3, s4
   bge t3, t2, L_and_11
   j L_false_102
L_and_11:
   mv t2, s5
   li t3, 0
   beq t2, t3, L_true_96
   j L_false_102
# then
L_true_96:
   # mod := i
   mv t0, s2
   mv s1, t0
# if [mod > 0]
L_cond_97:
   mv t2, s1
   li t3, 0
   blt t3, t2, L_true_98
   j L_false_99
# then
L_true_98:
   # mod := (mod - j)
   mv t0, s1
   mv t1, s3
   sub t0, t0, t1
   mv s1, t0
   j L_cond_97
# else
# if [mod = 0]
L_false_99:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_true_100
   j L_false_101
# then
L_true_100:
   # stop := 1
   li t0, 1
   mv s5, t0
   j L_cond_95
# else
L_false_101:
   # j := (j + 2)
   mv t0, s3
   li t1, 2
   add t0, t0, t1
   mv s3, t0
   j L_cond_95
# else
# if [j > sqrt]
L_false_102:
   mv t2, s3
   mv t3, s4
   blt t3, t2, L_true_103
   j L_false_104
# then
L_true_103:
   # stop1 := 1
   li t0, 1
   mv s6, t0
   j L_cond_89
# else
L_false_104:
   # i := (i - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
   j L_cond_89
# else
L_false_105:
   # closestprime := i
   mv t0, s2
   mv s1, t0
   # output := closestprime
   mv t0, s1
   mv s1, t0
   # input := output
   mv t0, s1
   mv s2, t0
   # mod := input
   mv t0, s2
   mv s1, t0
# if not [[[mod = 1] or [mod = 0]]]
L_cond_109:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_false_111
   j L_or_12
L_or_12:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_false_111
   j L_true_110
# then
L_true_110:
   # mod := (mod - 2)
   mv t0, s1
   li t1, 2
   sub t0, t0, t1
   mv s1, t0
   j L_cond_109
# else
# if [mod = 1]
L_false_111:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_true_112
   j L_false_113
# then
L_true_112:
   # input := (input - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
L_block_114:
   # i := input
   mv t0, s2
   mv s2, t0
   # stop1 := 0
   li t0, 0
   mv s6, t0
# if [[i >= 2] and [stop1 = 0]]
L_cond_116:
   mv t2, s2
   li t3, 2
   bge t2, t3, L_and_13
   j L_false_132
L_and_13:
   mv t2, s6
   li t3, 0
   beq t2, t3, L_true_117
   j L_false_132
# then
L_true_117:
   # sqrt := 1
   li t0, 1
   mv s4, t0
# if [(sqrt * sqrt) <= i]
L_cond_118:
   mv t0, s4
   mv t1, s4
   mul t2, t0, t1
   mv t3, s2
   bge t3, t2, L_true_119
   j L_false_120
# then
L_true_119:
   # sqrt := (sqrt + 1)
   mv t0, s4
   li t1, 1
   add t0, t0, t1
   mv s4, t0
   j L_cond_118
# else
L_false_120:
   # j := 3
   li t0, 3
   mv s3, t0
   # stop := 0
   li t0, 0
   mv s5, t0
# if [[j <= sqrt] and [stop = 0]]
L_cond_122:
   mv t2, s3
   mv t3, s4
   bge t3, t2, L_and_14
   j L_false_129
L_and_14:
   mv t2, s5
   li t3, 0
   beq t2, t3, L_true_123
   j L_false_129
# then
L_true_123:
   # mod := i
   mv t0, s2
   mv s1, t0
# if [mod > 0]
L_cond_124:
   mv t2, s1
   li t3, 0
   blt t3, t2, L_true_125
   j L_false_126
# then
L_true_125:
   # mod := (mod - j)
   mv t0, s1
   mv t1, s3
   sub t0, t0, t1
   mv s1, t0
   j L_cond_124
# else
# if [mod = 0]
L_false_126:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_true_127
   j L_false_128
# then
L_true_127:
   # stop := 1
   li t0, 1
   mv s5, t0
   j L_cond_122
# else
L_false_128:
   # j := (j + 2)
   mv t0, s3
   li t1, 2
   add t0, t0, t1
   mv s3, t0
   j L_cond_122
# else
# if [j > sqrt]
L_false_129:
   mv t2, s3
   mv t3, s4
   blt t3, t2, L_true_130
   j L_false_131
# then
L_true_130:
   # stop1 := 1
   li t0, 1
   mv s6, t0
   j L_cond_116
# else
L_false_131:
   # i := (i - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
   j L_cond_116
# else
L_false_132:
   # closestprime := i
   mv t0, s2
   mv s1, t0
   # output := closestprime
   mv t0, s1
   mv s1, t0
   # input := output
   mv t0, s1
   mv s2, t0
   # mod := input
   mv t0, s2
   mv s1, t0
# if not [[[mod = 1] or [mod = 0]]]
L_cond_136:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_false_138
   j L_or_15
L_or_15:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_false_138
   j L_true_137
# then
L_true_137:
   # mod := (mod - 2)
   mv t0, s1
   li t1, 2
   sub t0, t0, t1
   mv s1, t0
   j L_cond_136
# else
# if [mod = 1]
L_false_138:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_true_139
   j L_false_140
# then
L_true_139:
   # input := (input - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
L_block_141:
   # i := input
   mv t0, s2
   mv s2, t0
   # stop1 := 0
   li t0, 0
   mv s6, t0
# if [[i >= 2] and [stop1 = 0]]
L_cond_143:
   mv t2, s2
   li t3, 2
   bge t2, t3, L_and_16
   j L_false_159
L_and_16:
   mv t2, s6
   li t3, 0
   beq t2, t3, L_true_144
   j L_false_159
# then
L_true_144:
   # sqrt := 1
   li t0, 1
   mv s4, t0
# if [(sqrt * sqrt) <= i]
L_cond_145:
   mv t0, s4
   mv t1, s4
   mul t2, t0, t1
   mv t3, s2
   bge t3, t2, L_true_146
   j L_false_147
# then
L_true_146:
   # sqrt := (sqrt + 1)
   mv t0, s4
   li t1, 1
   add t0, t0, t1
   mv s4, t0
   j L_cond_145
# else
L_false_147:
   # j := 3
   li t0, 3
   mv s3, t0
   # stop := 0
   li t0, 0
   mv s5, t0
# if [[j <= sqrt] and [stop = 0]]
L_cond_149:
   mv t2, s3
   mv t3, s4
   bge t3, t2, L_and_17
   j L_false_156
L_and_17:
   mv t2, s5
   li t3, 0
   beq t2, t3, L_true_150
   j L_false_156
# then
L_true_150:
   # mod := i
   mv t0, s2
   mv s1, t0
# if [mod > 0]
L_cond_151:
   mv t2, s1
   li t3, 0
   blt t3, t2, L_true_152
   j L_false_153
# then
L_true_152:
   # mod := (mod - j)
   mv t0, s1
   mv t1, s3
   sub t0, t0, t1
   mv s1, t0
   j L_cond_151
# else
# if [mod = 0]
L_false_153:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_true_154
   j L_false_155
# then
L_true_154:
   # stop := 1
   li t0, 1
   mv s5, t0
   j L_cond_149
# else
L_false_155:
   # j := (j + 2)
   mv t0, s3
   li t1, 2
   add t0, t0, t1
   mv s3, t0
   j L_cond_149
# else
# if [j > sqrt]
L_false_156:
   mv t2, s3
   mv t3, s4
   blt t3, t2, L_true_157
   j L_false_158
# then
L_true_157:
   # stop1 := 1
   li t0, 1
   mv s6, t0
   j L_cond_143
# else
L_false_158:
   # i := (i - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
   j L_cond_143
# else
L_false_159:
   # closestprime := i
   mv t0, s2
   mv s1, t0
   # output := closestprime
   mv t0, s1
   mv s1, t0
   # input := output
   mv t0, s1
   mv s2, t0
   # mod := input
   mv t0, s2
   mv s1, t0
# if not [[[mod = 1] or [mod = 0]]]
L_cond_163:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_false_165
   j L_or_18
L_or_18:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_false_165
   j L_true_164
# then
L_true_164:
   # mod := (mod - 2)
   mv t0, s1
   li t1, 2
   sub t0, t0, t1
   mv s1, t0
   j L_cond_163
# else
# if [mod = 1]
L_false_165:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_true_166
   j L_false_167
# then
L_true_166:
   # input := (input - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
L_block_168:
   # i := input
   mv t0, s2
   mv s2, t0
   # stop1 := 0
   li t0, 0
   mv s6, t0
# if [[i >= 2] and [stop1 = 0]]
L_cond_170:
   mv t2, s2
   li t3, 2
   bge t2, t3, L_and_19
   j L_false_186
L_and_19:
   mv t2, s6
   li t3, 0
   beq t2, t3, L_true_171
   j L_false_186
# then
L_true_171:
   # sqrt := 1
   li t0, 1
   mv s4, t0
# if [(sqrt * sqrt) <= i]
L_cond_172:
   mv t0, s4
   mv t1, s4
   mul t2, t0, t1
   mv t3, s2
   bge t3, t2, L_true_173
   j L_false_174
# then
L_true_173:
   # sqrt := (sqrt + 1)
   mv t0, s4
   li t1, 1
   add t0, t0, t1
   mv s4, t0
   j L_cond_172
# else
L_false_174:
   # j := 3
   li t0, 3
   mv s3, t0
   # stop := 0
   li t0, 0
   mv s5, t0
# if [[j <= sqrt] and [stop = 0]]
L_cond_176:
   mv t2, s3
   mv t3, s4
   bge t3, t2, L_and_20
   j L_false_183
L_and_20:
   mv t2, s5
   li t3, 0
   beq t2, t3, L_true_177
   j L_false_183
# then
L_true_177:
   # mod := i
   mv t0, s2
   mv s1, t0
# if [mod > 0]
L_cond_178:
   mv t2, s1
   li t3, 0
   blt t3, t2, L_true_179
   j L_false_180
# then
L_true_179:
   # mod := (mod - j)
   mv t0, s1
   mv t1, s3
   sub t0, t0, t1
   mv s1, t0
   j L_cond_178
# else
# if [mod = 0]
L_false_180:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_true_181
   j L_false_182
# then
L_true_181:
   # stop := 1
   li t0, 1
   mv s5, t0
   j L_cond_176
# else
L_false_182:
   # j := (j + 2)
   mv t0, s3
   li t1, 2
   add t0, t0, t1
   mv s3, t0
   j L_cond_176
# else
# if [j > sqrt]
L_false_183:
   mv t2, s3
   mv t3, s4
   blt t3, t2, L_true_184
   j L_false_185
# then
L_true_184:
   # stop1 := 1
   li t0, 1
   mv s6, t0
   j L_cond_170
# else
L_false_185:
   # i := (i - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
   j L_cond_170
# else
L_false_186:
   # closestprime := i
   mv t0, s2
   mv s1, t0
   # output := closestprime
   mv t0, s1
   mv s1, t0
   # input := output
   mv t0, s1
   mv s2, t0
   # mod := input
   mv t0, s2
   mv s1, t0
# if not [[[mod = 1] or [mod = 0]]]
L_cond_190:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_false_192
   j L_or_21
L_or_21:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_false_192
   j L_true_191
# then
L_true_191:
   # mod := (mod - 2)
   mv t0, s1
   li t1, 2
   sub t0, t0, t1
   mv s1, t0
   j L_cond_190
# else
# if [mod = 1]
L_false_192:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_true_193
   j L_false_194
# then
L_true_193:
   # input := (input - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
L_block_195:
   # i := input
   mv t0, s2
   mv s2, t0
   # stop1 := 0
   li t0, 0
   mv s6, t0
# if [[i >= 2] and [stop1 = 0]]
L_cond_197:
   mv t2, s2
   li t3, 2
   bge t2, t3, L_and_22
   j L_false_213
L_and_22:
   mv t2, s6
   li t3, 0
   beq t2, t3, L_true_198
   j L_false_213
# then
L_true_198:
   # sqrt := 1
   li t0, 1
   mv s4, t0
# if [(sqrt * sqrt) <= i]
L_cond_199:
   mv t0, s4
   mv t1, s4
   mul t2, t0, t1
   mv t3, s2
   bge t3, t2, L_true_200
   j L_false_201
# then
L_true_200:
   # sqrt := (sqrt + 1)
   mv t0, s4
   li t1, 1
   add t0, t0, t1
   mv s4, t0
   j L_cond_199
# else
L_false_201:
   # j := 3
   li t0, 3
   mv s3, t0
   # stop := 0
   li t0, 0
   mv s5, t0
# if [[j <= sqrt] and [stop = 0]]
L_cond_203:
   mv t2, s3
   mv t3, s4
   bge t3, t2, L_and_23
   j L_false_210
L_and_23:
   mv t2, s5
   li t3, 0
   beq t2, t3, L_true_204
   j L_false_210
# then
L_true_204:
   # mod := i
   mv t0, s2
   mv s1, t0
# if [mod > 0]
L_cond_205:
   mv t2, s1
   li t3, 0
   blt t3, t2, L_true_206
   j L_false_207
# then
L_true_206:
   # mod := (mod - j)
   mv t0, s1
   mv t1, s3
   sub t0, t0, t1
   mv s1, t0
   j L_cond_205
# else
# if [mod = 0]
L_false_207:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_true_208
   j L_false_209
# then
L_true_208:
   # stop := 1
   li t0, 1
   mv s5, t0
   j L_cond_203
# else
L_false_209:
   # j := (j + 2)
   mv t0, s3
   li t1, 2
   add t0, t0, t1
   mv s3, t0
   j L_cond_203
# else
# if [j > sqrt]
L_false_210:
   mv t2, s3
   mv t3, s4
   blt t3, t2, L_true_211
   j L_false_212
# then
L_true_211:
   # stop1 := 1
   li t0, 1
   mv s6, t0
   j L_cond_197
# else
L_false_212:
   # i := (i - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
   j L_cond_197
# else
L_false_213:
   # closestprime := i
   mv t0, s2
   mv s1, t0
   # output := closestprime
   mv t0, s1
   mv s1, t0
   # input := output
   mv t0, s1
   mv s2, t0
   # mod := input
   mv t0, s2
   mv s1, t0
# if not [[[mod = 1] or [mod = 0]]]
L_cond_217:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_false_219
   j L_or_24
L_or_24:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_false_219
   j L_true_218
# then
L_true_218:
   # mod := (mod - 2)
   mv t0, s1
   li t1, 2
   sub t0, t0, t1
   mv s1, t0
   j L_cond_217
# else
# if [mod = 1]
L_false_219:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_true_220
   j L_false_221
# then
L_true_220:
   # input := (input - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
L_block_222:
   # i := input
   mv t0, s2
   mv s2, t0
   # stop1 := 0
   li t0, 0
   mv s6, t0
# if [[i >= 2] and [stop1 = 0]]
L_cond_224:
   mv t2, s2
   li t3, 2
   bge t2, t3, L_and_25
   j L_false_240
L_and_25:
   mv t2, s6
   li t3, 0
   beq t2, t3, L_true_225
   j L_false_240
# then
L_true_225:
   # sqrt := 1
   li t0, 1
   mv s4, t0
# if [(sqrt * sqrt) <= i]
L_cond_226:
   mv t0, s4
   mv t1, s4
   mul t2, t0, t1
   mv t3, s2
   bge t3, t2, L_true_227
   j L_false_228
# then
L_true_227:
   # sqrt := (sqrt + 1)
   mv t0, s4
   li t1, 1
   add t0, t0, t1
   mv s4, t0
   j L_cond_226
# else
L_false_228:
   # j := 3
   li t0, 3
   mv s3, t0
   # stop := 0
   li t0, 0
   mv s5, t0
# if [[j <= sqrt] and [stop = 0]]
L_cond_230:
   mv t2, s3
   mv t3, s4
   bge t3, t2, L_and_26
   j L_false_237
L_and_26:
   mv t2, s5
   li t3, 0
   beq t2, t3, L_true_231
   j L_false_237
# then
L_true_231:
   # mod := i
   mv t0, s2
   mv s1, t0
# if [mod > 0]
L_cond_232:
   mv t2, s1
   li t3, 0
   blt t3, t2, L_true_233
   j L_false_234
# then
L_true_233:
   # mod := (mod - j)
   mv t0, s1
   mv t1, s3
   sub t0, t0, t1
   mv s1, t0
   j L_cond_232
# else
# if [mod = 0]
L_false_234:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_true_235
   j L_false_236
# then
L_true_235:
   # stop := 1
   li t0, 1
   mv s5, t0
   j L_cond_230
# else
L_false_236:
   # j := (j + 2)
   mv t0, s3
   li t1, 2
   add t0, t0, t1
   mv s3, t0
   j L_cond_230
# else
# if [j > sqrt]
L_false_237:
   mv t2, s3
   mv t3, s4
   blt t3, t2, L_true_238
   j L_false_239
# then
L_true_238:
   # stop1 := 1
   li t0, 1
   mv s6, t0
   j L_cond_224
# else
L_false_239:
   # i := (i - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
   j L_cond_224
# else
L_false_240:
   # closestprime := i
   mv t0, s2
   mv s1, t0
   # output := closestprime
   mv t0, s1
   mv s1, t0
   # input := output
   mv t0, s1
   mv s2, t0
   # mod := input
   mv t0, s2
   mv s1, t0
# if not [[[mod = 1] or [mod = 0]]]
L_cond_244:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_false_246
   j L_or_27
L_or_27:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_false_246
   j L_true_245
# then
L_true_245:
   # mod := (mod - 2)
   mv t0, s1
   li t1, 2
   sub t0, t0, t1
   mv s1, t0
   j L_cond_244
# else
# if [mod = 1]
L_false_246:
   mv t2, s1
   li t3, 1
   beq t2, t3, L_true_247
   j L_false_248
# then
L_true_247:
   # input := (input - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
L_block_249:
   # i := input
   mv t0, s2
   mv s2, t0
   # stop1 := 0
   li t0, 0
   mv s6, t0
# if [[i >= 2] and [stop1 = 0]]
L_cond_251:
   mv t2, s2
   li t3, 2
   bge t2, t3, L_and_28
   j L_false_267
L_and_28:
   mv t2, s6
   li t3, 0
   beq t2, t3, L_true_252
   j L_false_267
# then
L_true_252:
   # sqrt := 1
   li t0, 1
   mv s4, t0
# if [(sqrt * sqrt) <= i]
L_cond_253:
   mv t0, s4
   mv t1, s4
   mul t2, t0, t1
   mv t3, s2
   bge t3, t2, L_true_254
   j L_false_255
# then
L_true_254:
   # sqrt := (sqrt + 1)
   mv t0, s4
   li t1, 1
   add t0, t0, t1
   mv s4, t0
   j L_cond_253
# else
L_false_255:
   # j := 3
   li t0, 3
   mv s3, t0
   # stop := 0
   li t0, 0
   mv s5, t0
# if [[j <= sqrt] and [stop = 0]]
L_cond_257:
   mv t2, s3
   mv t3, s4
   bge t3, t2, L_and_29
   j L_false_264
L_and_29:
   mv t2, s5
   li t3, 0
   beq t2, t3, L_true_258
   j L_false_264
# then
L_true_258:
   # mod := i
   mv t0, s2
   mv s1, t0
# if [mod > 0]
L_cond_259:
   mv t2, s1
   li t3, 0
   blt t3, t2, L_true_260
   j L_false_261
# then
L_true_260:
   # mod := (mod - j)
   mv t0, s1
   mv t1, s3
   sub t0, t0, t1
   mv s1, t0
   j L_cond_259
# else
# if [mod = 0]
L_false_261:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_true_262
   j L_false_263
# then
L_true_262:
   # stop := 1
   li t0, 1
   mv s5, t0
   j L_cond_257
# else
L_false_263:
   # j := (j + 2)
   mv t0, s3
   li t1, 2
   add t0, t0, t1
   mv s3, t0
   j L_cond_257
# else
# if [j > sqrt]
L_false_264:
   mv t2, s3
   mv t3, s4
   blt t3, t2, L_true_265
   j L_false_266
# then
L_true_265:
   # stop1 := 1
   li t0, 1
   mv s6, t0
   j L_cond_251
# else
L_false_266:
   # i := (i - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
   j L_cond_251
# else
L_false_267:
   # closestprime := i
   mv t0, s2
   mv s1, t0
   # output := closestprime
   mv t0, s1
   mv s1, t0
   j L_return
# else
L_false_248:
   # input := (input - 1)
   mv t0, s2
   li t1, 1
   sub t0, t0, t1
   mv s2, t0
   j L_block_249
# else
L_false_221:
   # input := (input - 1)
   mv t0, s2
   li t1, 1
   sub t0, t0, t1
   mv s2, t0
   j L_block_222
# else
L_false_194:
   # input := (input - 1)
   mv t0, s2
   li t1, 1
   sub t0, t0, t1
   mv s2, t0
   j L_block_195
# else
L_false_167:
   # input := (input - 1)
   mv t0, s2
   li t1, 1
   sub t0, t0, t1
   mv s2, t0
   j L_block_168
# else
L_false_140:
   # input := (input - 1)
   mv t0, s2
   li t1, 1
   sub t0, t0, t1
   mv s2, t0
   j L_block_141
# else
L_false_113:
   # input := (input - 1)
   mv t0, s2
   li t1, 1
   sub t0, t0, t1
   mv s2, t0
   j L_block_114
# else
L_false_86:
   # input := (input - 1)
   mv t0, s2
   li t1, 1
   sub t0, t0, t1
   mv s2, t0
   j L_block_87
# else
L_false_59:
   # input := (input - 1)
   mv t0, s2
   li t1, 1
   sub t0, t0, t1
   mv s2, t0
   j L_block_60
# else
L_false_32:
   # input := (input - 1)
   mv t0, s2
   li t1, 1
   sub t0, t0, t1
   mv s2, t0
   j L_block_33
# else
L_false_5:
   # input := (input - 1)
   mv t0, s2
   li t1, 1
   sub t0, t0, t1
   mv s2, t0
   j L_block_6
   
L_return:
   mv a0, s1
   addi sp, sp, 8
   ret
