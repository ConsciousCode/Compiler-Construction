#vars: w=[spill @slot 50], val1=[spill @slot 49], val0=[spill @slot 48], stop1=s6(slot 47), stop=s5(slot 46), sqrt=s4(slot 45), result=s4(slot 44), range=s3(slot 43), output=s2(slot 42), mod=s2(slot 41), knapsack9=[spill @slot 40], knapsack8=[spill @slot 39], knapsack7=[spill @slot 38], knapsack6=[spill @slot 37], knapsack5=[spill @slot 36], knapsack4=s3(slot 35), knapsack33=[spill @slot 34], knapsack32=[spill @slot 33], knapsack31=[spill @slot 32], knapsack30=s11(slot 31), knapsack3=s10(slot 30), knapsack29=s9(slot 29), knapsack28=s8(slot 28), knapsack27=s7(slot 27), knapsack26=s6(slot 26), knapsack25=[spill @slot 25], knapsack24=s4(slot 24), knapsack23=[spill @slot 23], knapsack22=[spill @slot 22], knapsack21=[spill @slot 21], knapsack20=[spill @slot 20], knapsack2=[spill @slot 19], knapsack19=[spill @slot 18], knapsack18=[spill @slot 17], knapsack17=[spill @slot 16], knapsack16=[spill @slot 15], knapsack15=[spill @slot 14], knapsack14=[spill @slot 13], knapsack13=[spill @slot 12], knapsack12=[spill @slot 11], knapsack11=[spill @slot 10], knapsack10=[spill @slot 9], knapsack1=[spill @slot 8], knapsack0=[spill @slot 7], k=s2(slot 6), j=s3(slot 5), input=s1(slot 4), i=s1(slot 3), count=s5(slot 2), closestprime=s1(slot 1), W=s5(slot 0), 
.text
.globl madprimes
madprimes:
   addi sp, sp, -16
   # s5 <- input (W)
   ld s5, 0(a0)
   
   # input := W
   mv t0, s5
   mv s1, t0
   # mod := input
   mv t0, s1
   mv s2, t0
# if not [[[mod = 1] or [mod = 0]]]
L_cond_2:
   mv t2, s2
   li t3, 1
   beq t2, t3, L_false_4
   j L_or_0
L_or_0:
   mv t2, s2
   li t3, 0
   beq t2, t3, L_false_4
   j L_true_3
# then
L_true_3:
   # mod := (mod - 2)
   mv t0, s2
   li t1, 2
   sub t0, t0, t1
   mv s2, t0
   j L_cond_2
# else
# if [mod = 1]
L_false_4:
   mv t2, s2
   li t3, 1
   beq t2, t3, L_true_5
   j L_false_6
# then
L_true_5:
   # input := (input - 2)
   mv t0, s1
   li t1, 2
   sub t0, t0, t1
   mv s1, t0
L_block_7:
   # i := input
   mv t0, s1
   mv s1, t0
   # stop1 := 0
   li t0, 0
   mv s6, t0
# if [[i >= 2] and [stop1 = 0]]
L_cond_9:
   mv t2, s1
   li t3, 2
   bge t2, t3, L_and_1
   j L_false_25
L_and_1:
   mv t2, s6
   li t3, 0
   beq t2, t3, L_true_10
   j L_false_25
# then
L_true_10:
   # sqrt := 1
   li t0, 1
   mv s4, t0
# if [(sqrt * sqrt) <= i]
L_cond_11:
   mv t0, s4
   mv t1, s4
   mul t2, t0, t1
   mv t3, s1
   bge t3, t2, L_true_12
   j L_false_13
# then
L_true_12:
   # sqrt := (sqrt + 1)
   mv t0, s4
   li t1, 1
   add t0, t0, t1
   mv s4, t0
   j L_cond_11
# else
L_false_13:
   # j := 3
   li t0, 3
   mv s3, t0
   # stop := 0
   li t0, 0
   mv s5, t0
# if [[j <= sqrt] and [stop = 0]]
L_cond_15:
   mv t2, s3
   mv t3, s4
   bge t3, t2, L_and_2
   j L_false_22
L_and_2:
   mv t2, s5
   li t3, 0
   beq t2, t3, L_true_16
   j L_false_22
# then
L_true_16:
   # mod := i
   mv t0, s1
   mv s2, t0
# if [mod > 0]
L_cond_17:
   mv t2, s2
   li t3, 0
   blt t3, t2, L_true_18
   j L_false_19
# then
L_true_18:
   # mod := (mod - j)
   mv t0, s2
   mv t1, s3
   sub t0, t0, t1
   mv s2, t0
   j L_cond_17
# else
# if [mod = 0]
L_false_19:
   mv t2, s2
   li t3, 0
   beq t2, t3, L_true_20
   j L_false_21
# then
L_true_20:
   # stop := 1
   li t0, 1
   mv s5, t0
   j L_cond_15
# else
L_false_21:
   # j := (j + 2)
   mv t0, s3
   li t1, 2
   add t0, t0, t1
   mv s3, t0
   j L_cond_15
# else
# if [j > sqrt]
L_false_22:
   mv t2, s3
   mv t3, s4
   blt t3, t2, L_true_23
   j L_false_24
# then
L_true_23:
   # stop1 := 1
   li t0, 1
   mv s6, t0
   j L_cond_9
# else
L_false_24:
   # i := (i - 2)
   mv t0, s1
   li t1, 2
   sub t0, t0, t1
   mv s1, t0
   j L_cond_9
# else
L_false_25:
   # closestprime := i
   mv t0, s1
   mv s1, t0
   # output := 0
   li t0, 0
   mv s2, t0
   # W := closestprime
   mv t0, s1
   mv s5, t0
   # i := 0
   li t0, 0
   mv s1, t0
   # val0 := 9
   li t0, 9
   sd t0, 384(a0)
   # val1 := 10
   li t0, 10
   sd t0, 392(a0)
   # knapsack0 := 0
   li t0, 0
   sd t0, 56(a0)
   # knapsack1 := 0
   li t0, 0
   sd t0, 64(a0)
   # knapsack2 := 0
   li t0, 0
   sd t0, 152(a0)
   # knapsack3 := 0
   li t0, 0
   mv s10, t0
   # knapsack4 := 0
   li t0, 0
   mv s3, t0
   # knapsack5 := 0
   li t0, 0
   sd t0, 288(a0)
   # knapsack6 := 0
   li t0, 0
   sd t0, 296(a0)
   # knapsack7 := 0
   li t0, 0
   sd t0, 304(a0)
   # knapsack8 := 0
   li t0, 0
   sd t0, 312(a0)
   # knapsack9 := 0
   li t0, 0
   sd t0, 320(a0)
   # knapsack10 := 0
   li t0, 0
   sd t0, 72(a0)
   # knapsack11 := 0
   li t0, 0
   sd t0, 80(a0)
   # knapsack12 := 0
   li t0, 0
   sd t0, 88(a0)
   # knapsack13 := 0
   li t0, 0
   sd t0, 96(a0)
   # knapsack14 := 0
   li t0, 0
   sd t0, 104(a0)
   # knapsack15 := 0
   li t0, 0
   sd t0, 112(a0)
   # knapsack16 := 0
   li t0, 0
   sd t0, 120(a0)
   # knapsack17 := 0
   li t0, 0
   sd t0, 128(a0)
   # knapsack18 := 0
   li t0, 0
   sd t0, 136(a0)
   # knapsack19 := 0
   li t0, 0
   sd t0, 144(a0)
   # knapsack20 := 0
   li t0, 0
   sd t0, 160(a0)
   # knapsack21 := 0
   li t0, 0
   sd t0, 168(a0)
   # knapsack22 := 0
   li t0, 0
   sd t0, 176(a0)
   # knapsack23 := 0
   li t0, 0
   sd t0, 184(a0)
   # knapsack24 := 0
   li t0, 0
   mv s4, t0
   # knapsack25 := 0
   li t0, 0
   sd t0, 200(a0)
   # knapsack26 := 0
   li t0, 0
   mv s6, t0
   # knapsack27 := 0
   li t0, 0
   mv s7, t0
   # knapsack28 := 0
   li t0, 0
   mv s8, t0
   # knapsack29 := 0
   li t0, 0
   mv s9, t0
   # knapsack30 := 0
   li t0, 0
   mv s11, t0
   # knapsack31 := 0
   li t0, 0
   sd t0, 256(a0)
   # knapsack32 := 0
   li t0, 0
   sd t0, 264(a0)
   # knapsack33 := 0
   li t0, 0
   sd t0, 272(a0)
# if [(i * 17) <= W]
L_cond_68:
   mv t0, s1
   li t1, 17
   mul t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_69
   j L_false_424
# then
L_true_69:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack0 + (val0 * w)) > knapsack15]
L_cond_70:
   ld t0, 56(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 112(a0)
   blt t3, t2, L_true_71
   j L_false_72
# then
L_true_71:
   # knapsack15 := (knapsack0 + (val0 * w))
   ld t0, 56(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 112(a0)
L_block_73:
   # w := (w + 1)
   ld t0, 400(a0)
   li t1, 1
   add t0, t0, t1
   sd t0, 400(a0)
# if [(knapsack0 + (val0 * w)) > knapsack30]
L_cond_74:
   ld t0, 56(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   mv t3, s11
   blt t3, t2, L_true_75
   j L_false_76
# then
L_true_75:
   # knapsack30 := (knapsack0 + (val0 * w))
   ld t0, 56(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   mv s11, t0
L_block_78:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack1 + (val0 * w)) > knapsack16]
L_cond_79:
   ld t0, 64(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 120(a0)
   blt t3, t2, L_true_80
   j L_false_81
# then
L_true_80:
   # knapsack16 := (knapsack1 + (val0 * w))
   ld t0, 64(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 120(a0)
L_block_82:
   # w := (w + 1)
   ld t0, 400(a0)
   li t1, 1
   add t0, t0, t1
   sd t0, 400(a0)
# if [(knapsack1 + (val0 * w)) > knapsack31]
L_cond_83:
   ld t0, 64(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 256(a0)
   blt t3, t2, L_true_84
   j L_false_85
# then
L_true_84:
   # knapsack31 := (knapsack1 + (val0 * w))
   ld t0, 64(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 256(a0)
L_block_87:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack2 + (val0 * w)) > knapsack17]
L_cond_88:
   ld t0, 152(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 128(a0)
   blt t3, t2, L_true_89
   j L_false_90
# then
L_true_89:
   # knapsack17 := (knapsack2 + (val0 * w))
   ld t0, 152(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 128(a0)
L_block_91:
   # w := (w + 1)
   ld t0, 400(a0)
   li t1, 1
   add t0, t0, t1
   sd t0, 400(a0)
# if [(knapsack2 + (val0 * w)) > knapsack32]
L_cond_92:
   ld t0, 152(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 264(a0)
   blt t3, t2, L_true_93
   j L_false_94
# then
L_true_93:
   # knapsack32 := (knapsack2 + (val0 * w))
   ld t0, 152(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 264(a0)
L_block_96:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack3 + (val0 * w)) > knapsack18]
L_cond_97:
   mv t0, s10
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 136(a0)
   blt t3, t2, L_true_98
   j L_false_99
# then
L_true_98:
   # knapsack18 := (knapsack3 + (val0 * w))
   mv t0, s10
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 136(a0)
L_block_100:
   # w := (w + 1)
   ld t0, 400(a0)
   li t1, 1
   add t0, t0, t1
   sd t0, 400(a0)
# if [(knapsack3 + (val0 * w)) > knapsack33]
L_cond_101:
   mv t0, s10
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 272(a0)
   blt t3, t2, L_true_102
   j L_false_103
# then
L_true_102:
   # knapsack33 := (knapsack3 + (val0 * w))
   mv t0, s10
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 272(a0)
L_block_105:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack4 + (val0 * w)) > knapsack19]
L_cond_106:
   mv t0, s3
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 144(a0)
   blt t3, t2, L_true_107
   j L_false_108
# then
L_true_107:
   # knapsack19 := (knapsack4 + (val0 * w))
   mv t0, s3
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 144(a0)
L_block_110:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack5 + (val0 * w)) > knapsack20]
L_cond_111:
   ld t0, 288(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 160(a0)
   blt t3, t2, L_true_112
   j L_false_113
# then
L_true_112:
   # knapsack20 := (knapsack5 + (val0 * w))
   ld t0, 288(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 160(a0)
L_block_115:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack6 + (val0 * w)) > knapsack21]
L_cond_116:
   ld t0, 296(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 168(a0)
   blt t3, t2, L_true_117
   j L_false_118
# then
L_true_117:
   # knapsack21 := (knapsack6 + (val0 * w))
   ld t0, 296(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 168(a0)
L_block_120:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack7 + (val0 * w)) > knapsack22]
L_cond_121:
   ld t0, 304(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 176(a0)
   blt t3, t2, L_true_122
   j L_false_123
# then
L_true_122:
   # knapsack22 := (knapsack7 + (val0 * w))
   ld t0, 304(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 176(a0)
L_block_125:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack8 + (val0 * w)) > knapsack23]
L_cond_126:
   ld t0, 312(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 184(a0)
   blt t3, t2, L_true_127
   j L_false_128
# then
L_true_127:
   # knapsack23 := (knapsack8 + (val0 * w))
   ld t0, 312(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 184(a0)
L_block_130:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack9 + (val0 * w)) > knapsack24]
L_cond_131:
   ld t0, 320(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   mv t3, s4
   blt t3, t2, L_true_132
   j L_false_133
# then
L_true_132:
   # knapsack24 := (knapsack9 + (val0 * w))
   ld t0, 320(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   mv s4, t0
L_block_135:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack10 + (val0 * w)) > knapsack25]
L_cond_136:
   ld t0, 72(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 200(a0)
   blt t3, t2, L_true_137
   j L_false_138
# then
L_true_137:
   # knapsack25 := (knapsack10 + (val0 * w))
   ld t0, 72(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 200(a0)
L_block_140:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack11 + (val0 * w)) > knapsack26]
L_cond_141:
   ld t0, 80(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   mv t3, s6
   blt t3, t2, L_true_142
   j L_false_143
# then
L_true_142:
   # knapsack26 := (knapsack11 + (val0 * w))
   ld t0, 80(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   mv s6, t0
L_block_145:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack12 + (val0 * w)) > knapsack27]
L_cond_146:
   ld t0, 88(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   mv t3, s7
   blt t3, t2, L_true_147
   j L_false_148
# then
L_true_147:
   # knapsack27 := (knapsack12 + (val0 * w))
   ld t0, 88(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   mv s7, t0
L_block_150:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack13 + (val0 * w)) > knapsack28]
L_cond_151:
   ld t0, 96(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   mv t3, s8
   blt t3, t2, L_true_152
   j L_false_153
# then
L_true_152:
   # knapsack28 := (knapsack13 + (val0 * w))
   ld t0, 96(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   mv s8, t0
L_block_155:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack14 + (val0 * w)) > knapsack29]
L_cond_156:
   ld t0, 104(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   mv t3, s9
   blt t3, t2, L_true_157
   j L_false_158
# then
L_true_157:
   # knapsack29 := (knapsack14 + (val0 * w))
   ld t0, 104(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   mv s9, t0
L_block_160:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack15 + (val0 * w)) > knapsack30]
L_cond_161:
   ld t0, 112(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   mv t3, s11
   blt t3, t2, L_true_162
   j L_false_163
# then
L_true_162:
   # knapsack30 := (knapsack15 + (val0 * w))
   ld t0, 112(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   mv s11, t0
L_block_165:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack16 + (val0 * w)) > knapsack31]
L_cond_166:
   ld t0, 120(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 256(a0)
   blt t3, t2, L_true_167
   j L_false_168
# then
L_true_167:
   # knapsack31 := (knapsack16 + (val0 * w))
   ld t0, 120(a0)
   sd t0, 0(sp)
   ld t0, 384(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 256(a0)
L_block_170:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack0 + (val1 * w)) > knapsack13]
L_cond_171:
   ld t0, 56(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 96(a0)
   blt t3, t2, L_true_172
   j L_false_173
# then
L_true_172:
   # knapsack13 := (knapsack0 + (val1 * w))
   ld t0, 56(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 96(a0)
L_block_174:
   # w := (w + 1)
   ld t0, 400(a0)
   li t1, 1
   add t0, t0, t1
   sd t0, 400(a0)
# if [(knapsack0 + (val1 * w)) > knapsack26]
L_cond_175:
   ld t0, 56(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   mv t3, s6
   blt t3, t2, L_true_176
   j L_false_177
# then
L_true_176:
   # knapsack26 := (knapsack0 + (val1 * w))
   ld t0, 56(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   mv s6, t0
L_block_179:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack1 + (val1 * w)) > knapsack14]
L_cond_180:
   ld t0, 64(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 104(a0)
   blt t3, t2, L_true_181
   j L_false_182
# then
L_true_181:
   # knapsack14 := (knapsack1 + (val1 * w))
   ld t0, 64(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 104(a0)
L_block_183:
   # w := (w + 1)
   ld t0, 400(a0)
   li t1, 1
   add t0, t0, t1
   sd t0, 400(a0)
# if [(knapsack1 + (val1 * w)) > knapsack27]
L_cond_184:
   ld t0, 64(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   mv t3, s7
   blt t3, t2, L_true_185
   j L_false_186
# then
L_true_185:
   # knapsack27 := (knapsack1 + (val1 * w))
   ld t0, 64(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   mv s7, t0
L_block_188:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack2 + (val1 * w)) > knapsack15]
L_cond_189:
   ld t0, 152(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 112(a0)
   blt t3, t2, L_true_190
   j L_false_191
# then
L_true_190:
   # knapsack15 := (knapsack2 + (val1 * w))
   ld t0, 152(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 112(a0)
L_block_192:
   # w := (w + 1)
   ld t0, 400(a0)
   li t1, 1
   add t0, t0, t1
   sd t0, 400(a0)
# if [(knapsack2 + (val1 * w)) > knapsack28]
L_cond_193:
   ld t0, 152(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   mv t3, s8
   blt t3, t2, L_true_194
   j L_false_195
# then
L_true_194:
   # knapsack28 := (knapsack2 + (val1 * w))
   ld t0, 152(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   mv s8, t0
L_block_197:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack3 + (val1 * w)) > knapsack16]
L_cond_198:
   mv t0, s10
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 120(a0)
   blt t3, t2, L_true_199
   j L_false_200
# then
L_true_199:
   # knapsack16 := (knapsack3 + (val1 * w))
   mv t0, s10
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 120(a0)
L_block_201:
   # w := (w + 1)
   ld t0, 400(a0)
   li t1, 1
   add t0, t0, t1
   sd t0, 400(a0)
# if [(knapsack3 + (val1 * w)) > knapsack29]
L_cond_202:
   mv t0, s10
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   mv t3, s9
   blt t3, t2, L_true_203
   j L_false_204
# then
L_true_203:
   # knapsack29 := (knapsack3 + (val1 * w))
   mv t0, s10
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   mv s9, t0
L_block_206:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack4 + (val1 * w)) > knapsack17]
L_cond_207:
   mv t0, s3
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 128(a0)
   blt t3, t2, L_true_208
   j L_false_209
# then
L_true_208:
   # knapsack17 := (knapsack4 + (val1 * w))
   mv t0, s3
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 128(a0)
L_block_210:
   # w := (w + 1)
   ld t0, 400(a0)
   li t1, 1
   add t0, t0, t1
   sd t0, 400(a0)
# if [(knapsack4 + (val1 * w)) > knapsack30]
L_cond_211:
   mv t0, s3
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   mv t3, s11
   blt t3, t2, L_true_212
   j L_false_213
# then
L_true_212:
   # knapsack30 := (knapsack4 + (val1 * w))
   mv t0, s3
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   mv s11, t0
L_block_215:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack5 + (val1 * w)) > knapsack18]
L_cond_216:
   ld t0, 288(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 136(a0)
   blt t3, t2, L_true_217
   j L_false_218
# then
L_true_217:
   # knapsack18 := (knapsack5 + (val1 * w))
   ld t0, 288(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 136(a0)
L_block_219:
   # w := (w + 1)
   ld t0, 400(a0)
   li t1, 1
   add t0, t0, t1
   sd t0, 400(a0)
# if [(knapsack5 + (val1 * w)) > knapsack31]
L_cond_220:
   ld t0, 288(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 256(a0)
   blt t3, t2, L_true_221
   j L_false_222
# then
L_true_221:
   # knapsack31 := (knapsack5 + (val1 * w))
   ld t0, 288(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 256(a0)
L_block_224:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack6 + (val1 * w)) > knapsack19]
L_cond_225:
   ld t0, 296(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 144(a0)
   blt t3, t2, L_true_226
   j L_false_227
# then
L_true_226:
   # knapsack19 := (knapsack6 + (val1 * w))
   ld t0, 296(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 144(a0)
L_block_228:
   # w := (w + 1)
   ld t0, 400(a0)
   li t1, 1
   add t0, t0, t1
   sd t0, 400(a0)
# if [(knapsack6 + (val1 * w)) > knapsack32]
L_cond_229:
   ld t0, 296(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 264(a0)
   blt t3, t2, L_true_230
   j L_false_231
# then
L_true_230:
   # knapsack32 := (knapsack6 + (val1 * w))
   ld t0, 296(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 264(a0)
L_block_233:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack7 + (val1 * w)) > knapsack20]
L_cond_234:
   ld t0, 304(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 160(a0)
   blt t3, t2, L_true_235
   j L_false_236
# then
L_true_235:
   # knapsack20 := (knapsack7 + (val1 * w))
   ld t0, 304(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 160(a0)
L_block_237:
   # w := (w + 1)
   ld t0, 400(a0)
   li t1, 1
   add t0, t0, t1
   sd t0, 400(a0)
# if [(knapsack7 + (val1 * w)) > knapsack33]
L_cond_238:
   ld t0, 304(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 272(a0)
   blt t3, t2, L_true_239
   j L_false_240
# then
L_true_239:
   # knapsack33 := (knapsack7 + (val1 * w))
   ld t0, 304(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 272(a0)
L_block_242:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack8 + (val1 * w)) > knapsack21]
L_cond_243:
   ld t0, 312(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 168(a0)
   blt t3, t2, L_true_244
   j L_false_245
# then
L_true_244:
   # knapsack21 := (knapsack8 + (val1 * w))
   ld t0, 312(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 168(a0)
L_block_247:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack9 + (val1 * w)) > knapsack22]
L_cond_248:
   ld t0, 320(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 176(a0)
   blt t3, t2, L_true_249
   j L_false_250
# then
L_true_249:
   # knapsack22 := (knapsack9 + (val1 * w))
   ld t0, 320(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 176(a0)
L_block_252:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack10 + (val1 * w)) > knapsack23]
L_cond_253:
   ld t0, 72(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 184(a0)
   blt t3, t2, L_true_254
   j L_false_255
# then
L_true_254:
   # knapsack23 := (knapsack10 + (val1 * w))
   ld t0, 72(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 184(a0)
L_block_257:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack11 + (val1 * w)) > knapsack24]
L_cond_258:
   ld t0, 80(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   mv t3, s4
   blt t3, t2, L_true_259
   j L_false_260
# then
L_true_259:
   # knapsack24 := (knapsack11 + (val1 * w))
   ld t0, 80(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   mv s4, t0
L_block_262:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack12 + (val1 * w)) > knapsack25]
L_cond_263:
   ld t0, 88(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   ld t3, 200(a0)
   blt t3, t2, L_true_264
   j L_false_265
# then
L_true_264:
   # knapsack25 := (knapsack12 + (val1 * w))
   ld t0, 88(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   sd t0, 200(a0)
L_block_267:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack13 + (val1 * w)) > knapsack26]
L_cond_268:
   ld t0, 96(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   mv t3, s6
   blt t3, t2, L_true_269
   j L_false_270
# then
L_true_269:
   # knapsack26 := (knapsack13 + (val1 * w))
   ld t0, 96(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   mv s6, t0
L_block_272:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack14 + (val1 * w)) > knapsack27]
L_cond_273:
   ld t0, 104(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   mv t3, s7
   blt t3, t2, L_true_274
   j L_false_275
# then
L_true_274:
   # knapsack27 := (knapsack14 + (val1 * w))
   ld t0, 104(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   mv s7, t0
L_block_277:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack15 + (val1 * w)) > knapsack28]
L_cond_278:
   ld t0, 112(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   mv t3, s8
   blt t3, t2, L_true_279
   j L_false_280
# then
L_true_279:
   # knapsack28 := (knapsack15 + (val1 * w))
   ld t0, 112(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   mv s8, t0
L_block_282:
   # w := 1
   li t0, 1
   sd t0, 400(a0)
# if [(knapsack16 + (val1 * w)) > knapsack29]
L_cond_283:
   ld t0, 120(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t2, t0, t1
   mv t3, s9
   blt t3, t2, L_true_284
   j L_false_285
# then
L_true_284:
   # knapsack29 := (knapsack16 + (val1 * w))
   ld t0, 120(a0)
   sd t0, 0(sp)
   ld t0, 392(a0)
   ld t1, 400(a0)
   mul t1, t0, t1
   ld t0, 0(sp)
   add t0, t0, t1
   mv s9, t0
# if [[output < knapsack0] and [((i * 17) + 0) <= W]]
L_cond_287:
   mv t2, s2
   ld t3, 56(a0)
   blt t2, t3, L_and_3
   j L_false_289
L_and_3:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 0
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_288
   j L_false_289
# then
L_true_288:
   # output := knapsack0
   ld t0, 56(a0)
   mv s2, t0
# if [[output < knapsack1] and [((i * 17) + 1) <= W]]
L_cond_290:
   mv t2, s2
   ld t3, 64(a0)
   blt t2, t3, L_and_4
   j L_false_292
L_and_4:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 1
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_291
   j L_false_292
# then
L_true_291:
   # output := knapsack1
   ld t0, 64(a0)
   mv s2, t0
# if [[output < knapsack2] and [((i * 17) + 2) <= W]]
L_cond_293:
   mv t2, s2
   ld t3, 152(a0)
   blt t2, t3, L_and_5
   j L_false_295
L_and_5:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 2
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_294
   j L_false_295
# then
L_true_294:
   # output := knapsack2
   ld t0, 152(a0)
   mv s2, t0
# if [[output < knapsack3] and [((i * 17) + 3) <= W]]
L_cond_296:
   mv t2, s2
   mv t3, s10
   blt t2, t3, L_and_6
   j L_false_298
L_and_6:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 3
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_297
   j L_false_298
# then
L_true_297:
   # output := knapsack3
   mv t0, s10
   mv s2, t0
# if [[output < knapsack4] and [((i * 17) + 4) <= W]]
L_cond_299:
   mv t2, s2
   mv t3, s3
   blt t2, t3, L_and_7
   j L_false_301
L_and_7:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 4
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_300
   j L_false_301
# then
L_true_300:
   # output := knapsack4
   mv t0, s3
   mv s2, t0
# if [[output < knapsack5] and [((i * 17) + 5) <= W]]
L_cond_302:
   mv t2, s2
   ld t3, 288(a0)
   blt t2, t3, L_and_8
   j L_false_304
L_and_8:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 5
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_303
   j L_false_304
# then
L_true_303:
   # output := knapsack5
   ld t0, 288(a0)
   mv s2, t0
# if [[output < knapsack6] and [((i * 17) + 6) <= W]]
L_cond_305:
   mv t2, s2
   ld t3, 296(a0)
   blt t2, t3, L_and_9
   j L_false_307
L_and_9:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 6
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_306
   j L_false_307
# then
L_true_306:
   # output := knapsack6
   ld t0, 296(a0)
   mv s2, t0
# if [[output < knapsack7] and [((i * 17) + 7) <= W]]
L_cond_308:
   mv t2, s2
   ld t3, 304(a0)
   blt t2, t3, L_and_10
   j L_false_310
L_and_10:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 7
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_309
   j L_false_310
# then
L_true_309:
   # output := knapsack7
   ld t0, 304(a0)
   mv s2, t0
# if [[output < knapsack8] and [((i * 17) + 8) <= W]]
L_cond_311:
   mv t2, s2
   ld t3, 312(a0)
   blt t2, t3, L_and_11
   j L_false_313
L_and_11:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 8
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_312
   j L_false_313
# then
L_true_312:
   # output := knapsack8
   ld t0, 312(a0)
   mv s2, t0
# if [[output < knapsack9] and [((i * 17) + 9) <= W]]
L_cond_314:
   mv t2, s2
   ld t3, 320(a0)
   blt t2, t3, L_and_12
   j L_false_316
L_and_12:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 9
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_315
   j L_false_316
# then
L_true_315:
   # output := knapsack9
   ld t0, 320(a0)
   mv s2, t0
# if [[output < knapsack10] and [((i * 17) + 10) <= W]]
L_cond_317:
   mv t2, s2
   ld t3, 72(a0)
   blt t2, t3, L_and_13
   j L_false_319
L_and_13:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 10
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_318
   j L_false_319
# then
L_true_318:
   # output := knapsack10
   ld t0, 72(a0)
   mv s2, t0
# if [[output < knapsack11] and [((i * 17) + 11) <= W]]
L_cond_320:
   mv t2, s2
   ld t3, 80(a0)
   blt t2, t3, L_and_14
   j L_false_322
L_and_14:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 11
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_321
   j L_false_322
# then
L_true_321:
   # output := knapsack11
   ld t0, 80(a0)
   mv s2, t0
# if [[output < knapsack12] and [((i * 17) + 12) <= W]]
L_cond_323:
   mv t2, s2
   ld t3, 88(a0)
   blt t2, t3, L_and_15
   j L_false_325
L_and_15:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 12
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_324
   j L_false_325
# then
L_true_324:
   # output := knapsack12
   ld t0, 88(a0)
   mv s2, t0
# if [[output < knapsack13] and [((i * 17) + 13) <= W]]
L_cond_326:
   mv t2, s2
   ld t3, 96(a0)
   blt t2, t3, L_and_16
   j L_false_328
L_and_16:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 13
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_327
   j L_false_328
# then
L_true_327:
   # output := knapsack13
   ld t0, 96(a0)
   mv s2, t0
# if [[output < knapsack14] and [((i * 17) + 14) <= W]]
L_cond_329:
   mv t2, s2
   ld t3, 104(a0)
   blt t2, t3, L_and_17
   j L_false_331
L_and_17:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 14
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_330
   j L_false_331
# then
L_true_330:
   # output := knapsack14
   ld t0, 104(a0)
   mv s2, t0
# if [[output < knapsack15] and [((i * 17) + 15) <= W]]
L_cond_332:
   mv t2, s2
   ld t3, 112(a0)
   blt t2, t3, L_and_18
   j L_false_334
L_and_18:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 15
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_333
   j L_false_334
# then
L_true_333:
   # output := knapsack15
   ld t0, 112(a0)
   mv s2, t0
# if [[output < knapsack16] and [((i * 17) + 16) <= W]]
L_cond_335:
   mv t2, s2
   ld t3, 120(a0)
   blt t2, t3, L_and_19
   j L_false_337
L_and_19:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 16
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_336
   j L_false_337
# then
L_true_336:
   # output := knapsack16
   ld t0, 120(a0)
   mv s2, t0
# if [[output < knapsack17] and [((i * 17) + 17) <= W]]
L_cond_338:
   mv t2, s2
   ld t3, 128(a0)
   blt t2, t3, L_and_20
   j L_false_340
L_and_20:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 17
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_339
   j L_false_340
# then
L_true_339:
   # output := knapsack17
   ld t0, 128(a0)
   mv s2, t0
# if [[output < knapsack18] and [((i * 17) + 18) <= W]]
L_cond_341:
   mv t2, s2
   ld t3, 136(a0)
   blt t2, t3, L_and_21
   j L_false_343
L_and_21:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 18
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_342
   j L_false_343
# then
L_true_342:
   # output := knapsack18
   ld t0, 136(a0)
   mv s2, t0
# if [[output < knapsack19] and [((i * 17) + 19) <= W]]
L_cond_344:
   mv t2, s2
   ld t3, 144(a0)
   blt t2, t3, L_and_22
   j L_false_346
L_and_22:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 19
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_345
   j L_false_346
# then
L_true_345:
   # output := knapsack19
   ld t0, 144(a0)
   mv s2, t0
# if [[output < knapsack20] and [((i * 17) + 20) <= W]]
L_cond_347:
   mv t2, s2
   ld t3, 160(a0)
   blt t2, t3, L_and_23
   j L_false_349
L_and_23:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 20
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_348
   j L_false_349
# then
L_true_348:
   # output := knapsack20
   ld t0, 160(a0)
   mv s2, t0
# if [[output < knapsack21] and [((i * 17) + 21) <= W]]
L_cond_350:
   mv t2, s2
   ld t3, 168(a0)
   blt t2, t3, L_and_24
   j L_false_352
L_and_24:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 21
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_351
   j L_false_352
# then
L_true_351:
   # output := knapsack21
   ld t0, 168(a0)
   mv s2, t0
# if [[output < knapsack22] and [((i * 17) + 22) <= W]]
L_cond_353:
   mv t2, s2
   ld t3, 176(a0)
   blt t2, t3, L_and_25
   j L_false_355
L_and_25:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 22
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_354
   j L_false_355
# then
L_true_354:
   # output := knapsack22
   ld t0, 176(a0)
   mv s2, t0
# if [[output < knapsack23] and [((i * 17) + 23) <= W]]
L_cond_356:
   mv t2, s2
   ld t3, 184(a0)
   blt t2, t3, L_and_26
   j L_false_358
L_and_26:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 23
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_357
   j L_false_358
# then
L_true_357:
   # output := knapsack23
   ld t0, 184(a0)
   mv s2, t0
# if [[output < knapsack24] and [((i * 17) + 24) <= W]]
L_cond_359:
   mv t2, s2
   mv t3, s4
   blt t2, t3, L_and_27
   j L_false_361
L_and_27:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 24
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_360
   j L_false_361
# then
L_true_360:
   # output := knapsack24
   mv t0, s4
   mv s2, t0
# if [[output < knapsack25] and [((i * 17) + 25) <= W]]
L_cond_362:
   mv t2, s2
   ld t3, 200(a0)
   blt t2, t3, L_and_28
   j L_false_364
L_and_28:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 25
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_363
   j L_false_364
# then
L_true_363:
   # output := knapsack25
   ld t0, 200(a0)
   mv s2, t0
# if [[output < knapsack26] and [((i * 17) + 26) <= W]]
L_cond_365:
   mv t2, s2
   mv t3, s6
   blt t2, t3, L_and_29
   j L_false_367
L_and_29:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 26
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_366
   j L_false_367
# then
L_true_366:
   # output := knapsack26
   mv t0, s6
   mv s2, t0
# if [[output < knapsack27] and [((i * 17) + 27) <= W]]
L_cond_368:
   mv t2, s2
   mv t3, s7
   blt t2, t3, L_and_30
   j L_false_370
L_and_30:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 27
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_369
   j L_false_370
# then
L_true_369:
   # output := knapsack27
   mv t0, s7
   mv s2, t0
# if [[output < knapsack28] and [((i * 17) + 28) <= W]]
L_cond_371:
   mv t2, s2
   mv t3, s8
   blt t2, t3, L_and_31
   j L_false_373
L_and_31:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 28
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_372
   j L_false_373
# then
L_true_372:
   # output := knapsack28
   mv t0, s8
   mv s2, t0
# if [[output < knapsack29] and [((i * 17) + 29) <= W]]
L_cond_374:
   mv t2, s2
   mv t3, s9
   blt t2, t3, L_and_32
   j L_false_376
L_and_32:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 29
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_375
   j L_false_376
# then
L_true_375:
   # output := knapsack29
   mv t0, s9
   mv s2, t0
# if [[output < knapsack30] and [((i * 17) + 30) <= W]]
L_cond_377:
   mv t2, s2
   mv t3, s11
   blt t2, t3, L_and_33
   j L_false_379
L_and_33:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 30
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_378
   j L_false_379
# then
L_true_378:
   # output := knapsack30
   mv t0, s11
   mv s2, t0
# if [[output < knapsack31] and [((i * 17) + 31) <= W]]
L_cond_380:
   mv t2, s2
   ld t3, 256(a0)
   blt t2, t3, L_and_34
   j L_false_382
L_and_34:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 31
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_381
   j L_false_382
# then
L_true_381:
   # output := knapsack31
   ld t0, 256(a0)
   mv s2, t0
# if [[output < knapsack32] and [((i * 17) + 32) <= W]]
L_cond_383:
   mv t2, s2
   ld t3, 264(a0)
   blt t2, t3, L_and_35
   j L_false_385
L_and_35:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 32
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_384
   j L_false_385
# then
L_true_384:
   # output := knapsack32
   ld t0, 264(a0)
   mv s2, t0
# if [[output < knapsack33] and [((i * 17) + 33) <= W]]
L_cond_386:
   mv t2, s2
   ld t3, 272(a0)
   blt t2, t3, L_and_36
   j L_false_388
L_and_36:
   mv t0, s1
   li t1, 17
   mul t0, t0, t1
   li t1, 33
   add t2, t0, t1
   mv t3, s5
   bge t3, t2, L_true_387
   j L_false_388
# then
L_true_387:
   # output := knapsack33
   ld t0, 272(a0)
   mv s2, t0
L_block_389:
   # knapsack0 := knapsack17
   ld t0, 128(a0)
   sd t0, 56(a0)
   # knapsack17 := 0
   li t0, 0
   sd t0, 128(a0)
   # knapsack1 := knapsack18
   ld t0, 136(a0)
   sd t0, 64(a0)
   # knapsack18 := 0
   li t0, 0
   sd t0, 136(a0)
   # knapsack2 := knapsack19
   ld t0, 144(a0)
   sd t0, 152(a0)
   # knapsack19 := 0
   li t0, 0
   sd t0, 144(a0)
   # knapsack3 := knapsack20
   ld t0, 160(a0)
   mv s10, t0
   # knapsack20 := 0
   li t0, 0
   sd t0, 160(a0)
   # knapsack4 := knapsack21
   ld t0, 168(a0)
   mv s3, t0
   # knapsack21 := 0
   li t0, 0
   sd t0, 168(a0)
   # knapsack5 := knapsack22
   ld t0, 176(a0)
   sd t0, 288(a0)
   # knapsack22 := 0
   li t0, 0
   sd t0, 176(a0)
   # knapsack6 := knapsack23
   ld t0, 184(a0)
   sd t0, 296(a0)
   # knapsack23 := 0
   li t0, 0
   sd t0, 184(a0)
   # knapsack7 := knapsack24
   mv t0, s4
   sd t0, 304(a0)
   # knapsack24 := 0
   li t0, 0
   mv s4, t0
   # knapsack8 := knapsack25
   ld t0, 200(a0)
   sd t0, 312(a0)
   # knapsack25 := 0
   li t0, 0
   sd t0, 200(a0)
   # knapsack9 := knapsack26
   mv t0, s6
   sd t0, 320(a0)
   # knapsack26 := 0
   li t0, 0
   mv s6, t0
   # knapsack10 := knapsack27
   mv t0, s7
   sd t0, 72(a0)
   # knapsack27 := 0
   li t0, 0
   mv s7, t0
   # knapsack11 := knapsack28
   mv t0, s8
   sd t0, 80(a0)
   # knapsack28 := 0
   li t0, 0
   mv s8, t0
   # knapsack12 := knapsack29
   mv t0, s9
   sd t0, 88(a0)
   # knapsack29 := 0
   li t0, 0
   mv s9, t0
   # knapsack13 := knapsack30
   mv t0, s11
   sd t0, 96(a0)
   # knapsack30 := 0
   li t0, 0
   mv s11, t0
   # knapsack14 := knapsack31
   ld t0, 256(a0)
   sd t0, 104(a0)
   # knapsack31 := 0
   li t0, 0
   sd t0, 256(a0)
   # knapsack15 := knapsack32
   ld t0, 264(a0)
   sd t0, 112(a0)
   # knapsack32 := 0
   li t0, 0
   sd t0, 264(a0)
   # knapsack16 := knapsack33
   ld t0, 272(a0)
   sd t0, 120(a0)
   # knapsack33 := 0
   li t0, 0
   sd t0, 272(a0)
   # i := (i + 1)
   mv t0, s1
   li t1, 1
   add t0, t0, t1
   mv s1, t0
   j L_cond_68
# else
   # Skip
L_false_388:
   j L_block_389
# else
   # Skip
L_false_385:
   j L_cond_386
# else
   # Skip
L_false_382:
   j L_cond_383
# else
   # Skip
L_false_379:
   j L_cond_380
# else
   # Skip
L_false_376:
   j L_cond_377
# else
   # Skip
L_false_373:
   j L_cond_374
# else
   # Skip
L_false_370:
   j L_cond_371
# else
   # Skip
L_false_367:
   j L_cond_368
# else
   # Skip
L_false_364:
   j L_cond_365
# else
   # Skip
L_false_361:
   j L_cond_362
# else
   # Skip
L_false_358:
   j L_cond_359
# else
   # Skip
L_false_355:
   j L_cond_356
# else
   # Skip
L_false_352:
   j L_cond_353
# else
   # Skip
L_false_349:
   j L_cond_350
# else
   # Skip
L_false_346:
   j L_cond_347
# else
   # Skip
L_false_343:
   j L_cond_344
# else
   # Skip
L_false_340:
   j L_cond_341
# else
   # Skip
L_false_337:
   j L_cond_338
# else
   # Skip
L_false_334:
   j L_cond_335
# else
   # Skip
L_false_331:
   j L_cond_332
# else
   # Skip
L_false_328:
   j L_cond_329
# else
   # Skip
L_false_325:
   j L_cond_326
# else
   # Skip
L_false_322:
   j L_cond_323
# else
   # Skip
L_false_319:
   j L_cond_320
# else
   # Skip
L_false_316:
   j L_cond_317
# else
   # Skip
L_false_313:
   j L_cond_314
# else
   # Skip
L_false_310:
   j L_cond_311
# else
   # Skip
L_false_307:
   j L_cond_308
# else
   # Skip
L_false_304:
   j L_cond_305
# else
   # Skip
L_false_301:
   j L_cond_302
# else
   # Skip
L_false_298:
   j L_cond_299
# else
   # Skip
L_false_295:
   j L_cond_296
# else
   # Skip
L_false_292:
   j L_cond_293
# else
   # Skip
L_false_289:
   j L_cond_290
# else
   # Skip
L_false_285:
   j L_cond_287
# else
   # Skip
L_false_280:
   j L_block_282
# else
   # Skip
L_false_275:
   j L_block_277
# else
   # Skip
L_false_270:
   j L_block_272
# else
   # Skip
L_false_265:
   j L_block_267
# else
   # Skip
L_false_260:
   j L_block_262
# else
   # Skip
L_false_255:
   j L_block_257
# else
   # Skip
L_false_250:
   j L_block_252
# else
   # Skip
L_false_245:
   j L_block_247
# else
   # Skip
L_false_240:
   j L_block_242
# else
   # Skip
L_false_236:
   j L_block_237
# else
   # Skip
L_false_231:
   j L_block_233
# else
   # Skip
L_false_227:
   j L_block_228
# else
   # Skip
L_false_222:
   j L_block_224
# else
   # Skip
L_false_218:
   j L_block_219
# else
   # Skip
L_false_213:
   j L_block_215
# else
   # Skip
L_false_209:
   j L_block_210
# else
   # Skip
L_false_204:
   j L_block_206
# else
   # Skip
L_false_200:
   j L_block_201
# else
   # Skip
L_false_195:
   j L_block_197
# else
   # Skip
L_false_191:
   j L_block_192
# else
   # Skip
L_false_186:
   j L_block_188
# else
   # Skip
L_false_182:
   j L_block_183
# else
   # Skip
L_false_177:
   j L_block_179
# else
   # Skip
L_false_173:
   j L_block_174
# else
   # Skip
L_false_168:
   j L_block_170
# else
   # Skip
L_false_163:
   j L_block_165
# else
   # Skip
L_false_158:
   j L_block_160
# else
   # Skip
L_false_153:
   j L_block_155
# else
   # Skip
L_false_148:
   j L_block_150
# else
   # Skip
L_false_143:
   j L_block_145
# else
   # Skip
L_false_138:
   j L_block_140
# else
   # Skip
L_false_133:
   j L_block_135
# else
   # Skip
L_false_128:
   j L_block_130
# else
   # Skip
L_false_123:
   j L_block_125
# else
   # Skip
L_false_118:
   j L_block_120
# else
   # Skip
L_false_113:
   j L_block_115
# else
   # Skip
L_false_108:
   j L_block_110
# else
   # Skip
L_false_103:
   j L_block_105
# else
   # Skip
L_false_99:
   j L_block_100
# else
   # Skip
L_false_94:
   j L_block_96
# else
   # Skip
L_false_90:
   j L_block_91
# else
   # Skip
L_false_85:
   j L_block_87
# else
   # Skip
L_false_81:
   j L_block_82
# else
   # Skip
L_false_76:
   j L_block_78
# else
   # Skip
L_false_72:
   j L_block_73
# else
L_false_424:
   # range := output
   mv t0, s2
   mv s3, t0
   # result := 0
   li t0, 0
   mv s4, t0
# if [range >= 2]
L_cond_427:
   mv t2, s3
   li t3, 2
   bge t2, t3, L_true_428
   j L_false_444
# then
L_true_428:
   # count := 0
   li t0, 0
   mv s5, t0
   # i := 2
   li t0, 2
   mv s1, t0
# if [(i * i) <= range]
L_cond_430:
   mv t0, s1
   mv t1, s1
   mul t2, t0, t1
   mv t3, s3
   bge t3, t2, L_true_431
   j L_false_440
# then
L_true_431:
   # k := range
   mv t0, s3
   mv s2, t0
# if [count > 0]
L_cond_432:
   mv t2, s5
   li t3, 0
   blt t3, t2, L_true_433
   j L_false_434
# then
   # Skip
L_true_433:
L_block_439:
   # i := (i + 1)
   mv t0, s1
   li t1, 1
   add t0, t0, t1
   mv s1, t0
   j L_cond_430
# else
# if [k >= 1]
L_false_434:
   mv t2, s2
   li t3, 1
   bge t2, t3, L_true_435
   j L_block_439
# then
# if [(k * i) = range]
L_true_435:
   mv t0, s2
   mv t1, s1
   mul t2, t0, t1
   mv t3, s3
   beq t2, t3, L_true_436
   j L_false_437
# then
L_true_436:
   # count := (count + 1)
   mv t0, s5
   li t1, 1
   add t0, t0, t1
   mv s5, t0
L_block_438:
   # k := (k - 1)
   mv t0, s2
   li t1, 1
   sub t0, t0, t1
   mv s2, t0
   j L_false_434
# else
   # Skip
L_false_437:
   j L_block_438
# else
# if [count > 0]
L_false_440:
   mv t2, s5
   li t3, 0
   blt t3, t2, L_true_441
   j L_false_442
# then
   # Skip
L_true_441:
L_block_443:
   # range := (range - 1)
   mv t0, s3
   li t1, 1
   sub t0, t0, t1
   mv s3, t0
   j L_cond_427
# else
L_false_442:
   # result := (1 + result)
   li t0, 1
   mv t1, s4
   add t0, t0, t1
   mv s4, t0
   j L_block_443
# else
L_false_444:
   # output := result
   mv t0, s4
   mv s2, t0
   j L_return
# else
L_false_6:
   # input := (input - 1)
   mv t0, s1
   li t1, 1
   sub t0, t0, t1
   mv s1, t0
   j L_block_7
   
L_return:
   mv a0, s2
   addi sp, sp, 16
   ret
