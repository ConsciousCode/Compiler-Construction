#vars: sqrt_discriminant=s4(slot 16), roots=s1(slot 15), remainder=s8(slot 14), r2=s2(slot 13), r1=s5(slot 12), quotient=s9(slot 11), output=s1(slot 10), numerator2=s4(slot 9), numerator1=s6(slot 8), n=s7(slot 7), last_guess=s6(slot 6), guess=s5(slot 5), discriminant=s4(slot 4), denominator=s3(slot 3), c=s1(slot 2), b=s2(slot 1), a=s3(slot 0), 
.text
.globl quadratic
quadratic:
   addi sp, sp, -24
   # s3 <- input (a)
   ld s3, 0(a0)
   # s2 <- input (b)
   ld s2, 8(a0)
   # s1 <- input (c)
   ld s1, 16(a0)
   
   # discriminant := ((b * b) - ((4 * a) * c))
   mv t0, s2
   mv t1, s2
   mul t0, t0, t1
   sd t0, 0(sp)
   li t0, 4
   mv t1, s3
   mul t0, t0, t1
   mv t1, s1
   mul t1, t0, t1
   ld t0, 0(sp)
   sub t0, t0, t1
   mv s4, t0
# if [discriminant < 0]
L_cond_1:
   mv t2, s4
   li t3, 0
   blt t2, t3, L_true_2
   j L_false_3
# then
L_true_2:
   # roots := 0
   li t0, 0
   mv s1, t0
L_block_43:
   # output := roots
   mv t0, s1
   mv s1, t0
   j L_return
# else
# if [discriminant = 0]
L_false_3:
   mv t2, s4
   li t3, 0
   beq t2, t3, L_true_4
   j L_false_6
# then
L_true_4:
   # roots := 1
   li t0, 1
   mv s1, t0
   # sqrt_discriminant := 0
   li t0, 0
   mv s4, t0
L_block_24:
   # denominator := (2 * a)
   li t0, 2
   mv t1, s3
   mul t0, t0, t1
   mv s3, t0
   # numerator1 := ((0 - b) - sqrt_discriminant)
   li t0, 0
   mv t1, s2
   sub t0, t0, t1
   mv t1, s4
   sub t0, t0, t1
   mv s6, t0
   # r1 := 0
   li t0, 0
   mv s5, t0
# if [numerator1 >= denominator]
L_cond_27:
   mv t2, s6
   mv t3, s3
   bge t2, t3, L_true_28
   j L_false_30
# then
L_true_28:
   # r1 := (r1 + 1)
   mv t0, s5
   li t1, 1
   add t0, t0, t1
   mv s5, t0
   # numerator1 := (numerator1 - denominator)
   mv t0, s6
   mv t1, s3
   sub t0, t0, t1
   mv s6, t0
   j L_cond_27
# else
# if [numerator1 <= (0 - denominator)]
L_false_30:
   mv t2, s6
   li t0, 0
   mv t1, s3
   sub t3, t0, t1
   bge t3, t2, L_true_31
   j L_false_33
# then
L_true_31:
   # r1 := (r1 - 1)
   mv t0, s5
   li t1, 1
   sub t0, t0, t1
   mv s5, t0
   # numerator1 := (numerator1 + denominator)
   mv t0, s6
   mv t1, s3
   add t0, t0, t1
   mv s6, t0
   j L_false_30
# else
# if [roots > 1]
L_false_33:
   mv t2, s1
   li t3, 1
   blt t3, t2, L_true_34
   j L_false_42
# then
L_true_34:
   # numerator2 := ((0 - b) + sqrt_discriminant)
   li t0, 0
   mv t1, s2
   sub t0, t0, t1
   mv t1, s4
   add t0, t0, t1
   mv s4, t0
   # r2 := 0
   li t0, 0
   mv s2, t0
# if [numerator2 >= denominator]
L_cond_36:
   mv t2, s4
   mv t3, s3
   bge t2, t3, L_true_37
   j L_false_39
# then
L_true_37:
   # r2 := (r2 + 1)
   mv t0, s2
   li t1, 1
   add t0, t0, t1
   mv s2, t0
   # numerator2 := (numerator2 - denominator)
   mv t0, s4
   mv t1, s3
   sub t0, t0, t1
   mv s4, t0
   j L_cond_36
# else
# if [numerator2 <= (0 - denominator)]
L_false_39:
   mv t2, s4
   li t0, 0
   mv t1, s3
   sub t3, t0, t1
   bge t3, t2, L_true_40
   j L_block_43
# then
L_true_40:
   # r2 := (r2 - 1)
   mv t0, s2
   li t1, 1
   sub t0, t0, t1
   mv s2, t0
   # numerator2 := (numerator2 + denominator)
   mv t0, s4
   mv t1, s3
   add t0, t0, t1
   mv s4, t0
   j L_false_39
# else
   # Skip
L_false_42:
   j L_block_43
# else
L_false_6:
   # roots := 2
   li t0, 2
   mv s1, t0
   # n := 50
   li t0, 50
   mv s7, t0
   # last_guess := 0
   li t0, 0
   mv s6, t0
   # guess := 1
   li t0, 1
   mv s5, t0
# if [[n > 0] and not [[last_guess = guess]]]
L_cond_10:
   mv t2, s7
   li t3, 0
   blt t3, t2, L_and_0
   j L_false_23
L_and_0:
   mv t2, s6
   mv t3, s5
   beq t2, t3, L_false_23
   j L_true_11
# then
L_true_11:
   # last_guess := guess
   mv t0, s5
   mv s6, t0
   # quotient := 0
   li t0, 0
   mv s9, t0
   # remainder := discriminant
   mv t0, s4
   mv s8, t0
# if [remainder >= guess]
L_cond_14:
   mv t2, s8
   mv t3, s5
   bge t2, t3, L_true_15
   j L_false_17
# then
L_true_15:
   # quotient := (quotient + 1)
   mv t0, s9
   li t1, 1
   add t0, t0, t1
   mv s9, t0
   # remainder := (remainder - guess)
   mv t0, s8
   mv t1, s5
   sub t0, t0, t1
   mv s8, t0
   j L_cond_14
# else
L_false_17:
   # remainder := (guess + quotient)
   mv t0, s5
   mv t1, s9
   add t0, t0, t1
   mv s8, t0
   # quotient := 0
   li t0, 0
   mv s9, t0
# if [remainder >= 2]
L_cond_19:
   mv t2, s8
   li t3, 2
   bge t2, t3, L_true_20
   j L_false_22
# then
L_true_20:
   # quotient := (quotient + 1)
   mv t0, s9
   li t1, 1
   add t0, t0, t1
   mv s9, t0
   # remainder := (remainder - 2)
   mv t0, s8
   li t1, 2
   sub t0, t0, t1
   mv s8, t0
   j L_cond_19
# else
L_false_22:
   # guess := quotient
   mv t0, s9
   mv s5, t0
   j L_cond_10
# else
L_false_23:
   # sqrt_discriminant := guess
   mv t0, s5
   mv s4, t0
   j L_block_24
   
L_return:
   mv a0, s1
   addi sp, sp, 24
   ret
