#vars: result=s5(slot 5), range=s4(slot 4), output=s1(slot 3), k=s3(slot 2), i=s2(slot 1), count=s1(slot 0), 
.text
.globl primescounter
primescounter:
   addi sp, sp, -8
   # s4 <- input (range)
   ld s4, 32(a0)
   
   # result := 0
   li t0, 0
   mv s5, t0
# if [range >= 2]
L_cond_1:
   mv t2, s4
   li t3, 2
   bge t2, t3, L_true_2
   j L_false_18
# then
L_true_2:
   # count := 0
   li t0, 0
   mv s1, t0
   # i := 2
   li t0, 2
   mv s2, t0
# if [(i * i) <= range]
L_cond_4:
   mv t0, s2
   mv t1, s2
   mul t2, t0, t1
   mv t3, s4
   bge t3, t2, L_true_5
   j L_false_14
# then
L_true_5:
   # k := range
   mv t0, s4
   mv s3, t0
# if [count > 0]
L_cond_6:
   mv t2, s1
   li t3, 0
   blt t3, t2, L_true_7
   j L_false_8
# then
   # Skip
L_true_7:
L_block_13:
   # i := (i + 1)
   mv t0, s2
   li t1, 1
   add t0, t0, t1
   mv s2, t0
   j L_cond_4
# else
# if [k >= 1]
L_false_8:
   mv t2, s3
   li t3, 1
   bge t2, t3, L_true_9
   j L_block_13
# then
# if [(k * i) = range]
L_true_9:
   mv t0, s3
   mv t1, s2
   mul t2, t0, t1
   mv t3, s4
   beq t2, t3, L_true_10
   j L_false_11
# then
L_true_10:
   # count := (count + 1)
   mv t0, s1
   li t1, 1
   add t0, t0, t1
   mv s1, t0
L_block_12:
   # k := (k - 1)
   mv t0, s3
   li t1, 1
   sub t0, t0, t1
   mv s3, t0
   j L_false_8
# else
   # Skip
L_false_11:
   j L_block_12
# else
# if [count > 0]
L_false_14:
   mv t2, s1
   li t3, 0
   blt t3, t2, L_true_15
   j L_false_16
# then
   # Skip
L_true_15:
L_block_17:
   # range := (range - 1)
   mv t0, s4
   li t1, 1
   sub t0, t0, t1
   mv s4, t0
   j L_cond_1
# else
L_false_16:
   # result := (1 + result)
   li t0, 1
   mv t1, s5
   add t0, t0, t1
   mv s5, t0
   j L_block_17
# else
L_false_18:
   # output := result
   mv t0, s5
   mv s1, t0
   j L_return
   
L_return:
   mv a0, s1
   addi sp, sp, 8
   ret
