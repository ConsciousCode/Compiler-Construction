#vars: result=s5(slot 5), output=s1(slot 4), factors=s4(slot 3), b=s3(slot 2), a=s2(slot 1), N=s1(slot 0), 
.text
.globl sumfactors
sumfactors:
   addi sp, sp, -8
   # s1 <- input (N)
   ld s1, 0(a0)
   
   # result := 0
   li t0, 0
   mv s5, t0
# if [N >= 2]
L_cond_1:
   mv t2, s1
   li t3, 2
   bge t2, t3, L_true_2
   j L_false_14
# then
L_true_2:
   # factors := 0
   li t0, 0
   mv s4, t0
   # a := 2
   li t0, 2
   mv s2, t0
# if [(2 * a) <= N]
L_cond_4:
   li t0, 2
   mv t1, s2
   mul t2, t0, t1
   mv t3, s1
   bge t3, t2, L_true_5
   j L_false_12
# then
L_true_5:
   # b := N
   mv t0, s1
   mv s3, t0
# if [b >= 1]
L_cond_6:
   mv t2, s3
   li t3, 1
   bge t2, t3, L_true_7
   j L_false_11
# then
# if [(b * a) = N]
L_true_7:
   mv t0, s3
   mv t1, s2
   mul t2, t0, t1
   mv t3, s1
   beq t2, t3, L_true_8
   j L_false_9
# then
L_true_8:
   # factors := (factors + 1)
   mv t0, s4
   li t1, 1
   add t0, t0, t1
   mv s4, t0
L_block_10:
   # b := (b - 1)
   mv t0, s3
   li t1, 1
   sub t0, t0, t1
   mv s3, t0
   j L_cond_6
# else
   # Skip
L_false_9:
   j L_block_10
# else
L_false_11:
   # a := (a + 1)
   mv t0, s2
   li t1, 1
   add t0, t0, t1
   mv s2, t0
   j L_cond_4
# else
L_false_12:
   # result := (result + factors)
   mv t0, s5
   mv t1, s4
   add t0, t0, t1
   mv s5, t0
   # N := (N - 1)
   mv t0, s1
   li t1, 1
   sub t0, t0, t1
   mv s1, t0
   j L_cond_1
# else
L_false_14:
   # output := result
   mv t0, s5
   mv s1, t0
   j L_return
   
L_return:
   mv a0, s1
   addi sp, sp, 8
   ret
