#vars: t=s3(slot 5), output=s1(slot 4), input2=s2(slot 3), input=s1(slot 2), b=s2(slot 1), a=s1(slot 0), 
.text
.globl stress_gcd_mod
stress_gcd_mod:
   addi sp, sp, -8
   # s1 <- input (input)
   ld s1, 16(a0)
   # s2 <- input (input2)
   ld s2, 24(a0)
   
   # a := input
   mv t0, s1
   mv s1, t0
   # b := input2
   mv t0, s2
   mv s2, t0
# if not [[a = 0]]
L_cond_2:
   mv t2, s1
   li t3, 0
   beq t2, t3, L_false_8
   j L_true_3
# then
# if [b >= a]
L_true_3:
   mv t2, s2
   mv t3, s1
   bge t2, t3, L_true_4
   j L_false_5
# then
L_true_4:
   # b := (b - a)
   mv t0, s2
   mv t1, s1
   sub t0, t0, t1
   mv s2, t0
   j L_true_3
# else
L_false_5:
   # t := a
   mv t0, s1
   mv s3, t0
   # a := b
   mv t0, s2
   mv s1, t0
   # b := t
   mv t0, s3
   mv s2, t0
   j L_cond_2
# else
L_false_8:
   # output := b
   mv t0, s2
   mv s1, t0
   j L_return
   
L_return:
   mv a0, s1
   addi sp, sp, 8
   ret
