#vars: z=s3(slot 6), y=s2(slot 5), x=s1(slot 4), t=s1(slot 3), output=s1(slot 2), input=s1(slot 1), i=s3(slot 0), 
.text
.globl stress_factorial
stress_factorial:
   addi sp, sp, -8
   # s1 <- input (input)
   ld s1, 8(a0)
   
   # x := input
   mv t0, s1
   mv s1, t0
   # y := x
   mv t0, s1
   mv s2, t0
   # z := 1
   li t0, 1
   mv s3, t0
# if [y > 1]
L_cond_3:
   mv t2, s2
   li t3, 1
   blt t3, t2, L_true_4
   j L_false_11
# then
L_true_4:
   # t := 0
   li t0, 0
   mv s1, t0
   # i := z
   mv t0, s3
   mv s3, t0
# if [i > 0]
L_cond_6:
   mv t2, s3
   li t3, 0
   blt t3, t2, L_true_7
   j L_false_9
# then
L_true_7:
   # t := (t + y)
   mv t0, s1
   mv t1, s2
   add t0, t0, t1
   mv s1, t0
   # i := (i - 1)
   mv t0, s3
   li t1, 1
   sub t0, t0, t1
   mv s3, t0
   j L_cond_6
# else
L_false_9:
   # z := t
   mv t0, s1
   mv s3, t0
   # y := (y - 1)
   mv t0, s2
   li t1, 1
   sub t0, t0, t1
   mv s2, t0
   j L_cond_3
# else
L_false_11:
   # output := z
   mv t0, s3
   mv s1, t0
   j L_return
   
L_return:
   mv a0, s1
   addi sp, sp, 8
   ret
