#include <stdint.h>
int64_t quadratic(int64_t vars[]) {
    int64_t a = vars[0], b = vars[1], c = vars[2], denominator = 0, discriminant = 0, guess = 0, last__guess = 0, n = 0, numerator1 = 0, numerator2 = 0, output = 0, quotient = 0, r1 = 0, r2 = 0, remainder = 0, roots = 0, sqrt__discriminant = 0;
label_0:
    discriminant = (b*b)-((4*a)*c);
    goto label_1;
label_1:
    if (discriminant<0) goto label_2;
    else goto label_3;
label_2:
    roots = 0;
    goto label_43;
label_3:
    if (discriminant==0) goto label_4;
    else goto label_6;
label_4:
    roots = 1;
    goto label_5;
label_5:
    sqrt__discriminant = 0;
    goto label_24;
label_6:
    roots = 2;
    goto label_7;
label_7:
    n = 50;
    goto label_8;
label_8:
    last__guess = 0;
    goto label_9;
label_9:
    guess = 1;
    goto label_10;
label_10:
    if ((n>0)&&(!(last__guess==guess))) goto label_11;
    else goto label_23;
label_11:
    last__guess = guess;
    goto label_12;
label_12:
    quotient = 0;
    goto label_13;
label_13:
    remainder = discriminant;
    goto label_14;
label_14:
    if (remainder>=guess) goto label_15;
    else goto label_17;
label_15:
    quotient = quotient+1;
    goto label_16;
label_16:
    remainder = remainder-guess;
    goto label_14;
label_17:
    remainder = guess+quotient;
    goto label_18;
label_18:
    quotient = 0;
    goto label_19;
label_19:
    if (remainder>=2) goto label_20;
    else goto label_22;
label_20:
    quotient = quotient+1;
    goto label_21;
label_21:
    remainder = remainder-2;
    goto label_19;
label_22:
    guess = quotient;
    goto label_10;
label_23:
    sqrt__discriminant = guess;
    goto label_24;
label_24:
    denominator = 2*a;
    goto label_25;
label_25:
    numerator1 = (0-b)-sqrt__discriminant;
    goto label_26;
label_26:
    r1 = 0;
    goto label_27;
label_27:
    if (numerator1>=denominator) goto label_28;
    else goto label_30;
label_28:
    r1 = r1+1;
    goto label_29;
label_29:
    numerator1 = numerator1-denominator;
    goto label_27;
label_30:
    if (numerator1<=(0-denominator)) goto label_31;
    else goto label_33;
label_31:
    r1 = r1-1;
    goto label_32;
label_32:
    numerator1 = numerator1+denominator;
    goto label_30;
label_33:
    if (roots>1) goto label_34;
    else goto label_42;
label_34:
    numerator2 = (0-b)+sqrt__discriminant;
    goto label_35;
label_35:
    r2 = 0;
    goto label_36;
label_36:
    if (numerator2>=denominator) goto label_37;
    else goto label_39;
label_37:
    r2 = r2+1;
    goto label_38;
label_38:
    numerator2 = numerator2-denominator;
    goto label_36;
label_39:
    if (numerator2<=(0-denominator)) goto label_40;
    else goto label_43;
label_40:
    r2 = r2-1;
    goto label_41;
label_41:
    numerator2 = numerator2+denominator;
    goto label_39;
label_42:
    goto label_43;
label_43:
    output = roots;
    goto exit;
exit:
    vars[0] = a;
    vars[1] = b;
    vars[2] = c;
    vars[3] = denominator;
    vars[4] = discriminant;
    vars[5] = guess;
    vars[6] = last__guess;
    vars[7] = n;
    vars[8] = numerator1;
    vars[9] = numerator2;
    vars[10] = output;
    vars[11] = quotient;
    vars[12] = r1;
    vars[13] = r2;
    vars[14] = remainder;
    vars[15] = roots;
    vars[16] = sqrt__discriminant;
    return vars[10];
}
