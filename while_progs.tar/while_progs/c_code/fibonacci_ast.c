#include <stdint.h>
int64_t fibonacci(int64_t vars[]) {
    int64_t a = vars[0], b = vars[1], n = vars[2], output = vars[3], t = vars[4], z = vars[5];
    a = 0;
    b = 1;
    z = 0;
    while (!(n==z)) {
        t = a+b;
        a = b;
        b = t;
        n = n-1;
        z = 0;
    }

    output = a;
    vars[0] = a;
    vars[1] = b;
    vars[2] = n;
    vars[3] = output;
    vars[4] = t;
    vars[5] = z;
    return vars[3];
}
