#include <stdint.h>
int64_t stress_gcd_sub(int64_t vars[]) {
    int64_t a = 0, b = 0, input = vars[2], input2 = vars[3], output = 0;
label_0:
    a = input;
    goto label_1;
label_1:
    b = input2;
    goto label_2;
label_2:
    if (!(a==0)) goto label_3;
    else goto label_6;
label_3:
    if (a>=b) goto label_4;
    else goto label_5;
label_4:
    a = a-b;
    goto label_2;
label_5:
    b = b-a;
    goto label_2;
label_6:
    output = b;
    goto exit;
exit:
    vars[0] = a;
    vars[1] = b;
    vars[2] = input;
    vars[3] = input2;
    vars[4] = output;
    return vars[4];
}
