#include <stdint.h>
int64_t loop(int64_t vars[]) {
    int64_t n = vars[0], output = vars[1];
    while (n>0) {
        output = output+1;
        n = n-1;
    }

    vars[0] = n;
    vars[1] = output;
    return vars[1];
}
