#include <stdint.h>
int64_t stress_factorial(int64_t vars[]) {
    int64_t i = vars[0], input = vars[1], output = vars[2], t = vars[3], x = vars[4], y = vars[5], z = vars[6];
    x = input;
    y = x;
    z = 1;
    while (y>1) {
        t = 0;
        i = z;
        while (i>0) {
            t = t+y;
            i = i-1;
        }

        z = t;
        y = y-1;
    }

    output = z;
    vars[0] = i;
    vars[1] = input;
    vars[2] = output;
    vars[3] = t;
    vars[4] = x;
    vars[5] = y;
    vars[6] = z;
    return vars[2];
}
