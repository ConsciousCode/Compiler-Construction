#include <stdint.h>
int64_t loop(int64_t vars[]) {
    int64_t n = vars[0], output = vars[1];
label_0:
    goto exit;
label_1:
    output = output+1;
    goto label_2;
label_2:
    n = n-1;
    goto label_0;
exit:
    vars[0] = n;
    vars[1] = output;
    return vars[1];
}
