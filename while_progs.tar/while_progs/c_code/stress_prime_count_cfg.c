#include <stdint.h>
int64_t stress_prime_count(int64_t vars[]) {
    int64_t c = 0, count = 0, d = 0, dm1 = 0, input = vars[4], isprime = 0, n = 0, output = 0, rem = 0;
label_0:
    n = input;
    goto label_1;
label_1:
    count = 0;
    goto label_2;
label_2:
    c = n;
    goto label_3;
label_3:
    if (c>1) goto label_4;
    else goto label_19;
label_4:
    isprime = 1;
    goto label_5;
label_5:
    d = c-1;
    goto label_6;
label_6:
    if (d>1) goto label_7;
    else goto label_15;
label_7:
    rem = c;
    goto label_8;
label_8:
    dm1 = d-1;
    goto label_9;
label_9:
    if (rem>dm1) goto label_10;
    else goto label_11;
label_10:
    rem = rem-d;
    goto label_9;
label_11:
    if (rem==0) goto label_12;
    else goto label_13;
label_12:
    isprime = 0;
    goto label_14;
label_13:
    goto label_14;
label_14:
    d = d-1;
    goto label_6;
label_15:
    if (isprime==1) goto label_16;
    else goto label_17;
label_16:
    count = count+1;
    goto label_18;
label_17:
    goto label_18;
label_18:
    c = c-1;
    goto label_3;
label_19:
    output = count;
    goto exit;
exit:
    vars[0] = c;
    vars[1] = count;
    vars[2] = d;
    vars[3] = dm1;
    vars[4] = input;
    vars[5] = isprime;
    vars[6] = n;
    vars[7] = output;
    vars[8] = rem;
    return vars[7];
}
