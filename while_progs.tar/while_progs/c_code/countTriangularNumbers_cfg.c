#include <stdint.h>
int64_t countTriangularNumbers(int64_t vars[]) {
    int64_t count = 0, goUpToNumber = vars[1], i = vars[2], isNumFact = 0, n = 0, output = 0, sum = 0;
label_0:
    isNumFact = 0;
    goto label_1;
label_1:
    sum = 0;
    goto label_2;
label_2:
    n = 1;
    goto label_3;
label_3:
    count = 0;
    goto label_4;
label_4:
    if (i<goUpToNumber) goto label_5;
    else goto label_19;
label_5:
    if (sum<=i) goto label_6;
    else goto label_12;
label_6:
    sum = sum+n;
    goto label_7;
label_7:
    if (sum==i) goto label_8;
    else goto label_10;
label_8:
    isNumFact = 1;
    goto label_9;
label_9:
    sum = i+1;
    goto label_11;
label_10:
    goto label_11;
label_11:
    n = n+1;
    goto label_5;
label_12:
    if (isNumFact==1) goto label_13;
    else goto label_14;
label_13:
    count = count+1;
    goto label_15;
label_14:
    goto label_15;
label_15:
    isNumFact = 0;
    goto label_16;
label_16:
    sum = 0;
    goto label_17;
label_17:
    n = 1;
    goto label_18;
label_18:
    i = i+1;
    goto label_4;
label_19:
    output = count;
    goto exit;
exit:
    vars[0] = count;
    vars[1] = goUpToNumber;
    vars[2] = i;
    vars[3] = isNumFact;
    vars[4] = n;
    vars[5] = output;
    vars[6] = sum;
    return vars[5];
}
