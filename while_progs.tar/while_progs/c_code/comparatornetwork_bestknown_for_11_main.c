#define VAR_COUNT 13
#define LIVE_COUNT 11
#define LIVE_NAMES "w0", "w1", "w10", "w2", "w3", "w4", "w5", "w6", "w7", "w8", "w9", 
#define LIVE_OFFS 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 
#define PROGRAM_NAME comparatornetwork_bestknown_for_11
// If you change this, run:
// scripts/build_main_str.sh < src/main.c > src/main.c.str

#include <stdlib.h>
#include <stdio.h>

#ifndef LIVE_COUNT
#define LIVE_COUNT 0
#endif

#ifndef VAR_COUNT
#define VAR_COUNT 0
#endif

#ifndef LIVE_NAMES
#define LIVE_NAMES "input",
#endif

#ifndef LIVE_OFFS
#define LIVE_OFFS
#endif

#ifndef PROGRAM_NAME
#define PROGRAM_NAME program 
#endif

extern long PROGRAM_NAME(long *vars);

static const char* live_names[] = {
    LIVE_NAMES NULL
};

static const int live_offs[] = {
    LIVE_OFFS -1
};

int main(int argc, char **argv) {
    long vars[VAR_COUNT > 0 ? VAR_COUNT : 1] = {0};

    if (argc < 2 && LIVE_COUNT > 0) {
        fprintf(stderr, "Usage: %s", argv[0]);
        for(const char **it = live_names; *it != NULL; ++it) {
            fprintf(stderr, " %s", *it);
        }
        fprintf(stderr, "\n");
        return 1;
    }

    for (int i = 0; i < LIVE_COUNT; i++) {
        if(i + 1 > argc) {
            fprintf(stderr, "Error: Not enough args\n");
            return 1;
        }
        vars[live_offs[i]] = atol(argv[i + 1]);
    }

    printf("Initial state: %d\n", LIVE_COUNT);
    for (int i = 0; i < LIVE_COUNT; i++) {
        printf("  var[%s] = %ld\n", live_names[i], vars[live_offs[i]]);
    }

    long output = PROGRAM_NAME(vars);

    printf("\nFinal state:\n");
    printf("  var[output] = %ld\n", output);
    
    return 0;
}
