#include <stdint.h>
int64_t collatz(int64_t vars[]) {
    int64_t input = vars[0], n = vars[1], output = vars[2], quot = vars[3], rem = vars[4], steps = vars[5];
    n = input;
    steps = 0;
    while (n>1) {
        rem = n;
        quot = 0;
        while (rem>1) {
            rem = rem-2;
            quot = quot+1;
        }

        if (rem==0) {
            n = quot;
        }
        else {
            n = (3*n)+1;
        }

        steps = steps+1;
    }

    output = steps;
    vars[0] = input;
    vars[1] = n;
    vars[2] = output;
    vars[3] = quot;
    vars[4] = rem;
    vars[5] = steps;
    return vars[2];
}
