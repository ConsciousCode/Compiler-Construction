#include <stdint.h>
int64_t sumfactors(int64_t vars[]) {
    int64_t N = vars[0], a = vars[1], b = vars[2], factors = vars[3], output = vars[4], result = vars[5];
    result = 0;
    while (N>=2) {
        factors = 0;
        a = 2;
        while ((2*a)<=N) {
            b = N;
            while (b>=1) {
                if ((b*a)==N) {
                    factors = factors+1;
                }
                else {
;
                }

                b = b-1;
            }

            a = a+1;
        }

        result = result+factors;
        N = N-1;
    }

    output = result;
    vars[0] = N;
    vars[1] = a;
    vars[2] = b;
    vars[3] = factors;
    vars[4] = output;
    vars[5] = result;
    return vars[4];
}
