#include <stdint.h>
int64_t isprime(int64_t vars[]) {
    int64_t composite = 0, i = 0, input = vars[2], j = 0, output = 0;
label_0:
    composite = 0;
    goto label_1;
label_1:
    i = 2;
    goto label_2;
label_2:
    if ((i<input)&&(composite==0)) goto label_3;
    else goto label_9;
label_3:
    j = 1;
    goto label_4;
label_4:
    if ((i*j)<input) goto label_5;
    else goto label_6;
label_5:
    j = j+1;
    goto label_4;
label_6:
    if ((i*j)==input) goto label_7;
    else goto label_8;
label_7:
    composite = 1;
    goto label_2;
label_8:
    i = i+1;
    goto label_2;
label_9:
    output = 1-composite;
    goto exit;
exit:
    vars[0] = composite;
    vars[1] = i;
    vars[2] = input;
    vars[3] = j;
    vars[4] = output;
    return vars[4];
}
