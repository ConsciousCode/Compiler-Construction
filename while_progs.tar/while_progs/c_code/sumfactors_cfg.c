#include <stdint.h>
int64_t sumfactors(int64_t vars[]) {
    int64_t N = vars[0], a = 0, b = 0, factors = 0, output = 0, result = 0;
label_0:
    result = 0;
    goto label_1;
label_1:
    if (N>=2) goto label_2;
    else goto label_14;
label_2:
    factors = 0;
    goto label_3;
label_3:
    a = 2;
    goto label_4;
label_4:
    if ((2*a)<=N) goto label_5;
    else goto label_12;
label_5:
    b = N;
    goto label_6;
label_6:
    if (b>=1) goto label_7;
    else goto label_11;
label_7:
    if ((b*a)==N) goto label_8;
    else goto label_9;
label_8:
    factors = factors+1;
    goto label_10;
label_9:
    goto label_10;
label_10:
    b = b-1;
    goto label_6;
label_11:
    a = a+1;
    goto label_4;
label_12:
    result = result+factors;
    goto label_13;
label_13:
    N = N-1;
    goto label_1;
label_14:
    output = result;
    goto exit;
exit:
    vars[0] = N;
    vars[1] = a;
    vars[2] = b;
    vars[3] = factors;
    vars[4] = output;
    vars[5] = result;
    return vars[4];
}
