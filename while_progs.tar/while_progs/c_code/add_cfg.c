#include <stdint.h>
int64_t add(int64_t vars[]) {
    int64_t output = 0, x = 0, y = 0, z = 0;
label_0:
    x = 1;
    goto label_1;
label_1:
    y = 2;
    goto label_2;
label_2:
    z = x+y;
    goto label_3;
label_3:
    output = z;
    goto exit;
exit:
    vars[0] = output;
    vars[1] = x;
    vars[2] = y;
    vars[3] = z;
    return vars[0];
}
