#include <stdint.h>
int64_t primescounter(int64_t vars[]) {
    int64_t count = 0, i = 0, k = 0, output = 0, range = vars[4], result = 0;
label_0:
    result = 0;
    goto label_1;
label_1:
    if (range>=2) goto label_2;
    else goto label_18;
label_2:
    count = 0;
    goto label_3;
label_3:
    i = 2;
    goto label_4;
label_4:
    if ((i*i)<=range) goto label_5;
    else goto label_14;
label_5:
    k = range;
    goto label_6;
label_6:
    if (count>0) goto label_7;
    else goto label_8;
label_7:
    goto label_13;
label_8:
    if (k>=1) goto label_9;
    else goto label_13;
label_9:
    if ((k*i)==range) goto label_10;
    else goto label_11;
label_10:
    count = count+1;
    goto label_12;
label_11:
    goto label_12;
label_12:
    k = k-1;
    goto label_8;
label_13:
    i = i+1;
    goto label_4;
label_14:
    if (count>0) goto label_15;
    else goto label_16;
label_15:
    goto label_17;
label_16:
    result = 1+result;
    goto label_17;
label_17:
    range = range-1;
    goto label_1;
label_18:
    output = result;
    goto exit;
exit:
    vars[0] = count;
    vars[1] = i;
    vars[2] = k;
    vars[3] = output;
    vars[4] = range;
    vars[5] = result;
    return vars[3];
}
