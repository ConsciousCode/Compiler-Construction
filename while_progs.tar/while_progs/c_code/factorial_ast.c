#include <stdint.h>
int64_t factorial(int64_t vars[]) {
    int64_t output = vars[0], x = vars[1], y = vars[2], z = vars[3];
    y = x;
    z = 1;
    while (y>1) {
        z = z*y;
        y = y-1;
    }

    y = 0;
    output = z;
    vars[0] = output;
    vars[1] = x;
    vars[2] = y;
    vars[3] = z;
    return vars[0];
}
