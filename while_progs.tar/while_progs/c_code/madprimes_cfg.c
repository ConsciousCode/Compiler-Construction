#include <stdint.h>
int64_t madprimes(int64_t vars[]) {
    int64_t W = vars[0], closestprime = 0, count = 0, endput = 0, i = 0, input = 0, j = 0, k = 0, knapsack0 = 0, knapsack1 = 0, knapsack10 = 0, knapsack11 = 0, knapsack12 = 0, knapsack13 = 0, knapsack14 = 0, knapsack15 = 0, knapsack16 = 0, knapsack17 = 0, knapsack18 = 0, knapsack19 = 0, knapsack2 = 0, knapsack20 = 0, knapsack21 = 0, knapsack22 = 0, knapsack23 = 0, knapsack24 = 0, knapsack25 = 0, knapsack26 = 0, knapsack27 = 0, knapsack28 = 0, knapsack29 = 0, knapsack3 = 0, knapsack30 = 0, knapsack31 = 0, knapsack32 = 0, knapsack33 = 0, knapsack4 = 0, knapsack5 = 0, knapsack6 = 0, knapsack7 = 0, knapsack8 = 0, knapsack9 = 0, mod = 0, n = 0, output = 0, range = 0, result = 0, sqrt = 0, stop = 0, stop1 = 0, val0 = 0, val1 = 0, w = 0, weights0 = 0, weights1 = 0;
label_0:
    input = W;
    goto label_1;
label_1:
    mod = input;
    goto label_2;
label_2:
    if (!((mod==1)||(mod==0))) goto label_3;
    else goto label_4;
label_3:
    mod = mod-2;
    goto label_2;
label_4:
    if (mod==1) goto label_5;
    else goto label_6;
label_5:
    input = input-2;
    goto label_7;
label_6:
    input = input-1;
    goto label_7;
label_7:
    i = input;
    goto label_8;
label_8:
    stop1 = 0;
    goto label_9;
label_9:
    if ((i>=2)&&(stop1==0)) goto label_10;
    else goto label_25;
label_10:
    sqrt = 1;
    goto label_11;
label_11:
    if ((sqrt*sqrt)<=i) goto label_12;
    else goto label_13;
label_12:
    sqrt = sqrt+1;
    goto label_11;
label_13:
    j = 3;
    goto label_14;
label_14:
    stop = 0;
    goto label_15;
label_15:
    if ((j<=sqrt)&&(stop==0)) goto label_16;
    else goto label_22;
label_16:
    mod = i;
    goto label_17;
label_17:
    if (mod>0) goto label_18;
    else goto label_19;
label_18:
    mod = mod-j;
    goto label_17;
label_19:
    if (mod==0) goto label_20;
    else goto label_21;
label_20:
    stop = 1;
    goto label_15;
label_21:
    j = j+2;
    goto label_15;
label_22:
    if (j>sqrt) goto label_23;
    else goto label_24;
label_23:
    stop1 = 1;
    goto label_9;
label_24:
    i = i-2;
    goto label_9;
label_25:
    closestprime = i;
    goto label_26;
label_26:
    output = 0;
    goto label_27;
label_27:
    W = closestprime;
    goto label_29;
label_29:
    i = 0;
    goto label_31;
label_31:
    val0 = 9;
    goto label_33;
label_33:
    val1 = 10;
    goto label_34;
label_34:
    knapsack0 = 0;
    goto label_35;
label_35:
    knapsack1 = 0;
    goto label_36;
label_36:
    knapsack2 = 0;
    goto label_37;
label_37:
    knapsack3 = 0;
    goto label_38;
label_38:
    knapsack4 = 0;
    goto label_39;
label_39:
    knapsack5 = 0;
    goto label_40;
label_40:
    knapsack6 = 0;
    goto label_41;
label_41:
    knapsack7 = 0;
    goto label_42;
label_42:
    knapsack8 = 0;
    goto label_43;
label_43:
    knapsack9 = 0;
    goto label_44;
label_44:
    knapsack10 = 0;
    goto label_45;
label_45:
    knapsack11 = 0;
    goto label_46;
label_46:
    knapsack12 = 0;
    goto label_47;
label_47:
    knapsack13 = 0;
    goto label_48;
label_48:
    knapsack14 = 0;
    goto label_49;
label_49:
    knapsack15 = 0;
    goto label_50;
label_50:
    knapsack16 = 0;
    goto label_51;
label_51:
    knapsack17 = 0;
    goto label_52;
label_52:
    knapsack18 = 0;
    goto label_53;
label_53:
    knapsack19 = 0;
    goto label_54;
label_54:
    knapsack20 = 0;
    goto label_55;
label_55:
    knapsack21 = 0;
    goto label_56;
label_56:
    knapsack22 = 0;
    goto label_57;
label_57:
    knapsack23 = 0;
    goto label_58;
label_58:
    knapsack24 = 0;
    goto label_59;
label_59:
    knapsack25 = 0;
    goto label_60;
label_60:
    knapsack26 = 0;
    goto label_61;
label_61:
    knapsack27 = 0;
    goto label_62;
label_62:
    knapsack28 = 0;
    goto label_63;
label_63:
    knapsack29 = 0;
    goto label_64;
label_64:
    knapsack30 = 0;
    goto label_65;
label_65:
    knapsack31 = 0;
    goto label_66;
label_66:
    knapsack32 = 0;
    goto label_67;
label_67:
    knapsack33 = 0;
    goto label_68;
label_68:
    if ((i*17)<=W) goto label_69;
    else goto label_424;
label_69:
    w = 1;
    goto label_70;
label_70:
    if ((knapsack0+(val0*w))>knapsack15) goto label_71;
    else goto label_72;
label_71:
    knapsack15 = knapsack0+(val0*w);
    goto label_73;
label_72:
    goto label_73;
label_73:
    w = w+1;
    goto label_74;
label_74:
    if ((knapsack0+(val0*w))>knapsack30) goto label_75;
    else goto label_76;
label_75:
    knapsack30 = knapsack0+(val0*w);
    goto label_78;
label_76:
    goto label_78;
label_78:
    w = 1;
    goto label_79;
label_79:
    if ((knapsack1+(val0*w))>knapsack16) goto label_80;
    else goto label_81;
label_80:
    knapsack16 = knapsack1+(val0*w);
    goto label_82;
label_81:
    goto label_82;
label_82:
    w = w+1;
    goto label_83;
label_83:
    if ((knapsack1+(val0*w))>knapsack31) goto label_84;
    else goto label_85;
label_84:
    knapsack31 = knapsack1+(val0*w);
    goto label_87;
label_85:
    goto label_87;
label_87:
    w = 1;
    goto label_88;
label_88:
    if ((knapsack2+(val0*w))>knapsack17) goto label_89;
    else goto label_90;
label_89:
    knapsack17 = knapsack2+(val0*w);
    goto label_91;
label_90:
    goto label_91;
label_91:
    w = w+1;
    goto label_92;
label_92:
    if ((knapsack2+(val0*w))>knapsack32) goto label_93;
    else goto label_94;
label_93:
    knapsack32 = knapsack2+(val0*w);
    goto label_96;
label_94:
    goto label_96;
label_96:
    w = 1;
    goto label_97;
label_97:
    if ((knapsack3+(val0*w))>knapsack18) goto label_98;
    else goto label_99;
label_98:
    knapsack18 = knapsack3+(val0*w);
    goto label_100;
label_99:
    goto label_100;
label_100:
    w = w+1;
    goto label_101;
label_101:
    if ((knapsack3+(val0*w))>knapsack33) goto label_102;
    else goto label_103;
label_102:
    knapsack33 = knapsack3+(val0*w);
    goto label_105;
label_103:
    goto label_105;
label_105:
    w = 1;
    goto label_106;
label_106:
    if ((knapsack4+(val0*w))>knapsack19) goto label_107;
    else goto label_108;
label_107:
    knapsack19 = knapsack4+(val0*w);
    goto label_110;
label_108:
    goto label_110;
label_110:
    w = 1;
    goto label_111;
label_111:
    if ((knapsack5+(val0*w))>knapsack20) goto label_112;
    else goto label_113;
label_112:
    knapsack20 = knapsack5+(val0*w);
    goto label_115;
label_113:
    goto label_115;
label_115:
    w = 1;
    goto label_116;
label_116:
    if ((knapsack6+(val0*w))>knapsack21) goto label_117;
    else goto label_118;
label_117:
    knapsack21 = knapsack6+(val0*w);
    goto label_120;
label_118:
    goto label_120;
label_120:
    w = 1;
    goto label_121;
label_121:
    if ((knapsack7+(val0*w))>knapsack22) goto label_122;
    else goto label_123;
label_122:
    knapsack22 = knapsack7+(val0*w);
    goto label_125;
label_123:
    goto label_125;
label_125:
    w = 1;
    goto label_126;
label_126:
    if ((knapsack8+(val0*w))>knapsack23) goto label_127;
    else goto label_128;
label_127:
    knapsack23 = knapsack8+(val0*w);
    goto label_130;
label_128:
    goto label_130;
label_130:
    w = 1;
    goto label_131;
label_131:
    if ((knapsack9+(val0*w))>knapsack24) goto label_132;
    else goto label_133;
label_132:
    knapsack24 = knapsack9+(val0*w);
    goto label_135;
label_133:
    goto label_135;
label_135:
    w = 1;
    goto label_136;
label_136:
    if ((knapsack10+(val0*w))>knapsack25) goto label_137;
    else goto label_138;
label_137:
    knapsack25 = knapsack10+(val0*w);
    goto label_140;
label_138:
    goto label_140;
label_140:
    w = 1;
    goto label_141;
label_141:
    if ((knapsack11+(val0*w))>knapsack26) goto label_142;
    else goto label_143;
label_142:
    knapsack26 = knapsack11+(val0*w);
    goto label_145;
label_143:
    goto label_145;
label_145:
    w = 1;
    goto label_146;
label_146:
    if ((knapsack12+(val0*w))>knapsack27) goto label_147;
    else goto label_148;
label_147:
    knapsack27 = knapsack12+(val0*w);
    goto label_150;
label_148:
    goto label_150;
label_150:
    w = 1;
    goto label_151;
label_151:
    if ((knapsack13+(val0*w))>knapsack28) goto label_152;
    else goto label_153;
label_152:
    knapsack28 = knapsack13+(val0*w);
    goto label_155;
label_153:
    goto label_155;
label_155:
    w = 1;
    goto label_156;
label_156:
    if ((knapsack14+(val0*w))>knapsack29) goto label_157;
    else goto label_158;
label_157:
    knapsack29 = knapsack14+(val0*w);
    goto label_160;
label_158:
    goto label_160;
label_160:
    w = 1;
    goto label_161;
label_161:
    if ((knapsack15+(val0*w))>knapsack30) goto label_162;
    else goto label_163;
label_162:
    knapsack30 = knapsack15+(val0*w);
    goto label_165;
label_163:
    goto label_165;
label_165:
    w = 1;
    goto label_166;
label_166:
    if ((knapsack16+(val0*w))>knapsack31) goto label_167;
    else goto label_168;
label_167:
    knapsack31 = knapsack16+(val0*w);
    goto label_170;
label_168:
    goto label_170;
label_170:
    w = 1;
    goto label_171;
label_171:
    if ((knapsack0+(val1*w))>knapsack13) goto label_172;
    else goto label_173;
label_172:
    knapsack13 = knapsack0+(val1*w);
    goto label_174;
label_173:
    goto label_174;
label_174:
    w = w+1;
    goto label_175;
label_175:
    if ((knapsack0+(val1*w))>knapsack26) goto label_176;
    else goto label_177;
label_176:
    knapsack26 = knapsack0+(val1*w);
    goto label_179;
label_177:
    goto label_179;
label_179:
    w = 1;
    goto label_180;
label_180:
    if ((knapsack1+(val1*w))>knapsack14) goto label_181;
    else goto label_182;
label_181:
    knapsack14 = knapsack1+(val1*w);
    goto label_183;
label_182:
    goto label_183;
label_183:
    w = w+1;
    goto label_184;
label_184:
    if ((knapsack1+(val1*w))>knapsack27) goto label_185;
    else goto label_186;
label_185:
    knapsack27 = knapsack1+(val1*w);
    goto label_188;
label_186:
    goto label_188;
label_188:
    w = 1;
    goto label_189;
label_189:
    if ((knapsack2+(val1*w))>knapsack15) goto label_190;
    else goto label_191;
label_190:
    knapsack15 = knapsack2+(val1*w);
    goto label_192;
label_191:
    goto label_192;
label_192:
    w = w+1;
    goto label_193;
label_193:
    if ((knapsack2+(val1*w))>knapsack28) goto label_194;
    else goto label_195;
label_194:
    knapsack28 = knapsack2+(val1*w);
    goto label_197;
label_195:
    goto label_197;
label_197:
    w = 1;
    goto label_198;
label_198:
    if ((knapsack3+(val1*w))>knapsack16) goto label_199;
    else goto label_200;
label_199:
    knapsack16 = knapsack3+(val1*w);
    goto label_201;
label_200:
    goto label_201;
label_201:
    w = w+1;
    goto label_202;
label_202:
    if ((knapsack3+(val1*w))>knapsack29) goto label_203;
    else goto label_204;
label_203:
    knapsack29 = knapsack3+(val1*w);
    goto label_206;
label_204:
    goto label_206;
label_206:
    w = 1;
    goto label_207;
label_207:
    if ((knapsack4+(val1*w))>knapsack17) goto label_208;
    else goto label_209;
label_208:
    knapsack17 = knapsack4+(val1*w);
    goto label_210;
label_209:
    goto label_210;
label_210:
    w = w+1;
    goto label_211;
label_211:
    if ((knapsack4+(val1*w))>knapsack30) goto label_212;
    else goto label_213;
label_212:
    knapsack30 = knapsack4+(val1*w);
    goto label_215;
label_213:
    goto label_215;
label_215:
    w = 1;
    goto label_216;
label_216:
    if ((knapsack5+(val1*w))>knapsack18) goto label_217;
    else goto label_218;
label_217:
    knapsack18 = knapsack5+(val1*w);
    goto label_219;
label_218:
    goto label_219;
label_219:
    w = w+1;
    goto label_220;
label_220:
    if ((knapsack5+(val1*w))>knapsack31) goto label_221;
    else goto label_222;
label_221:
    knapsack31 = knapsack5+(val1*w);
    goto label_224;
label_222:
    goto label_224;
label_224:
    w = 1;
    goto label_225;
label_225:
    if ((knapsack6+(val1*w))>knapsack19) goto label_226;
    else goto label_227;
label_226:
    knapsack19 = knapsack6+(val1*w);
    goto label_228;
label_227:
    goto label_228;
label_228:
    w = w+1;
    goto label_229;
label_229:
    if ((knapsack6+(val1*w))>knapsack32) goto label_230;
    else goto label_231;
label_230:
    knapsack32 = knapsack6+(val1*w);
    goto label_233;
label_231:
    goto label_233;
label_233:
    w = 1;
    goto label_234;
label_234:
    if ((knapsack7+(val1*w))>knapsack20) goto label_235;
    else goto label_236;
label_235:
    knapsack20 = knapsack7+(val1*w);
    goto label_237;
label_236:
    goto label_237;
label_237:
    w = w+1;
    goto label_238;
label_238:
    if ((knapsack7+(val1*w))>knapsack33) goto label_239;
    else goto label_240;
label_239:
    knapsack33 = knapsack7+(val1*w);
    goto label_242;
label_240:
    goto label_242;
label_242:
    w = 1;
    goto label_243;
label_243:
    if ((knapsack8+(val1*w))>knapsack21) goto label_244;
    else goto label_245;
label_244:
    knapsack21 = knapsack8+(val1*w);
    goto label_247;
label_245:
    goto label_247;
label_247:
    w = 1;
    goto label_248;
label_248:
    if ((knapsack9+(val1*w))>knapsack22) goto label_249;
    else goto label_250;
label_249:
    knapsack22 = knapsack9+(val1*w);
    goto label_252;
label_250:
    goto label_252;
label_252:
    w = 1;
    goto label_253;
label_253:
    if ((knapsack10+(val1*w))>knapsack23) goto label_254;
    else goto label_255;
label_254:
    knapsack23 = knapsack10+(val1*w);
    goto label_257;
label_255:
    goto label_257;
label_257:
    w = 1;
    goto label_258;
label_258:
    if ((knapsack11+(val1*w))>knapsack24) goto label_259;
    else goto label_260;
label_259:
    knapsack24 = knapsack11+(val1*w);
    goto label_262;
label_260:
    goto label_262;
label_262:
    w = 1;
    goto label_263;
label_263:
    if ((knapsack12+(val1*w))>knapsack25) goto label_264;
    else goto label_265;
label_264:
    knapsack25 = knapsack12+(val1*w);
    goto label_267;
label_265:
    goto label_267;
label_267:
    w = 1;
    goto label_268;
label_268:
    if ((knapsack13+(val1*w))>knapsack26) goto label_269;
    else goto label_270;
label_269:
    knapsack26 = knapsack13+(val1*w);
    goto label_272;
label_270:
    goto label_272;
label_272:
    w = 1;
    goto label_273;
label_273:
    if ((knapsack14+(val1*w))>knapsack27) goto label_274;
    else goto label_275;
label_274:
    knapsack27 = knapsack14+(val1*w);
    goto label_277;
label_275:
    goto label_277;
label_277:
    w = 1;
    goto label_278;
label_278:
    if ((knapsack15+(val1*w))>knapsack28) goto label_279;
    else goto label_280;
label_279:
    knapsack28 = knapsack15+(val1*w);
    goto label_282;
label_280:
    goto label_282;
label_282:
    w = 1;
    goto label_283;
label_283:
    if ((knapsack16+(val1*w))>knapsack29) goto label_284;
    else goto label_285;
label_284:
    knapsack29 = knapsack16+(val1*w);
    goto label_287;
label_285:
    goto label_287;
label_287:
    if ((output<knapsack0)&&(((i*17)+0)<=W)) goto label_288;
    else goto label_289;
label_288:
    output = knapsack0;
    goto label_290;
label_289:
    goto label_290;
label_290:
    if ((output<knapsack1)&&(((i*17)+1)<=W)) goto label_291;
    else goto label_292;
label_291:
    output = knapsack1;
    goto label_293;
label_292:
    goto label_293;
label_293:
    if ((output<knapsack2)&&(((i*17)+2)<=W)) goto label_294;
    else goto label_295;
label_294:
    output = knapsack2;
    goto label_296;
label_295:
    goto label_296;
label_296:
    if ((output<knapsack3)&&(((i*17)+3)<=W)) goto label_297;
    else goto label_298;
label_297:
    output = knapsack3;
    goto label_299;
label_298:
    goto label_299;
label_299:
    if ((output<knapsack4)&&(((i*17)+4)<=W)) goto label_300;
    else goto label_301;
label_300:
    output = knapsack4;
    goto label_302;
label_301:
    goto label_302;
label_302:
    if ((output<knapsack5)&&(((i*17)+5)<=W)) goto label_303;
    else goto label_304;
label_303:
    output = knapsack5;
    goto label_305;
label_304:
    goto label_305;
label_305:
    if ((output<knapsack6)&&(((i*17)+6)<=W)) goto label_306;
    else goto label_307;
label_306:
    output = knapsack6;
    goto label_308;
label_307:
    goto label_308;
label_308:
    if ((output<knapsack7)&&(((i*17)+7)<=W)) goto label_309;
    else goto label_310;
label_309:
    output = knapsack7;
    goto label_311;
label_310:
    goto label_311;
label_311:
    if ((output<knapsack8)&&(((i*17)+8)<=W)) goto label_312;
    else goto label_313;
label_312:
    output = knapsack8;
    goto label_314;
label_313:
    goto label_314;
label_314:
    if ((output<knapsack9)&&(((i*17)+9)<=W)) goto label_315;
    else goto label_316;
label_315:
    output = knapsack9;
    goto label_317;
label_316:
    goto label_317;
label_317:
    if ((output<knapsack10)&&(((i*17)+10)<=W)) goto label_318;
    else goto label_319;
label_318:
    output = knapsack10;
    goto label_320;
label_319:
    goto label_320;
label_320:
    if ((output<knapsack11)&&(((i*17)+11)<=W)) goto label_321;
    else goto label_322;
label_321:
    output = knapsack11;
    goto label_323;
label_322:
    goto label_323;
label_323:
    if ((output<knapsack12)&&(((i*17)+12)<=W)) goto label_324;
    else goto label_325;
label_324:
    output = knapsack12;
    goto label_326;
label_325:
    goto label_326;
label_326:
    if ((output<knapsack13)&&(((i*17)+13)<=W)) goto label_327;
    else goto label_328;
label_327:
    output = knapsack13;
    goto label_329;
label_328:
    goto label_329;
label_329:
    if ((output<knapsack14)&&(((i*17)+14)<=W)) goto label_330;
    else goto label_331;
label_330:
    output = knapsack14;
    goto label_332;
label_331:
    goto label_332;
label_332:
    if ((output<knapsack15)&&(((i*17)+15)<=W)) goto label_333;
    else goto label_334;
label_333:
    output = knapsack15;
    goto label_335;
label_334:
    goto label_335;
label_335:
    if ((output<knapsack16)&&(((i*17)+16)<=W)) goto label_336;
    else goto label_337;
label_336:
    output = knapsack16;
    goto label_338;
label_337:
    goto label_338;
label_338:
    if ((output<knapsack17)&&(((i*17)+17)<=W)) goto label_339;
    else goto label_340;
label_339:
    output = knapsack17;
    goto label_341;
label_340:
    goto label_341;
label_341:
    if ((output<knapsack18)&&(((i*17)+18)<=W)) goto label_342;
    else goto label_343;
label_342:
    output = knapsack18;
    goto label_344;
label_343:
    goto label_344;
label_344:
    if ((output<knapsack19)&&(((i*17)+19)<=W)) goto label_345;
    else goto label_346;
label_345:
    output = knapsack19;
    goto label_347;
label_346:
    goto label_347;
label_347:
    if ((output<knapsack20)&&(((i*17)+20)<=W)) goto label_348;
    else goto label_349;
label_348:
    output = knapsack20;
    goto label_350;
label_349:
    goto label_350;
label_350:
    if ((output<knapsack21)&&(((i*17)+21)<=W)) goto label_351;
    else goto label_352;
label_351:
    output = knapsack21;
    goto label_353;
label_352:
    goto label_353;
label_353:
    if ((output<knapsack22)&&(((i*17)+22)<=W)) goto label_354;
    else goto label_355;
label_354:
    output = knapsack22;
    goto label_356;
label_355:
    goto label_356;
label_356:
    if ((output<knapsack23)&&(((i*17)+23)<=W)) goto label_357;
    else goto label_358;
label_357:
    output = knapsack23;
    goto label_359;
label_358:
    goto label_359;
label_359:
    if ((output<knapsack24)&&(((i*17)+24)<=W)) goto label_360;
    else goto label_361;
label_360:
    output = knapsack24;
    goto label_362;
label_361:
    goto label_362;
label_362:
    if ((output<knapsack25)&&(((i*17)+25)<=W)) goto label_363;
    else goto label_364;
label_363:
    output = knapsack25;
    goto label_365;
label_364:
    goto label_365;
label_365:
    if ((output<knapsack26)&&(((i*17)+26)<=W)) goto label_366;
    else goto label_367;
label_366:
    output = knapsack26;
    goto label_368;
label_367:
    goto label_368;
label_368:
    if ((output<knapsack27)&&(((i*17)+27)<=W)) goto label_369;
    else goto label_370;
label_369:
    output = knapsack27;
    goto label_371;
label_370:
    goto label_371;
label_371:
    if ((output<knapsack28)&&(((i*17)+28)<=W)) goto label_372;
    else goto label_373;
label_372:
    output = knapsack28;
    goto label_374;
label_373:
    goto label_374;
label_374:
    if ((output<knapsack29)&&(((i*17)+29)<=W)) goto label_375;
    else goto label_376;
label_375:
    output = knapsack29;
    goto label_377;
label_376:
    goto label_377;
label_377:
    if ((output<knapsack30)&&(((i*17)+30)<=W)) goto label_378;
    else goto label_379;
label_378:
    output = knapsack30;
    goto label_380;
label_379:
    goto label_380;
label_380:
    if ((output<knapsack31)&&(((i*17)+31)<=W)) goto label_381;
    else goto label_382;
label_381:
    output = knapsack31;
    goto label_383;
label_382:
    goto label_383;
label_383:
    if ((output<knapsack32)&&(((i*17)+32)<=W)) goto label_384;
    else goto label_385;
label_384:
    output = knapsack32;
    goto label_386;
label_385:
    goto label_386;
label_386:
    if ((output<knapsack33)&&(((i*17)+33)<=W)) goto label_387;
    else goto label_388;
label_387:
    output = knapsack33;
    goto label_389;
label_388:
    goto label_389;
label_389:
    knapsack0 = knapsack17;
    goto label_390;
label_390:
    knapsack17 = 0;
    goto label_391;
label_391:
    knapsack1 = knapsack18;
    goto label_392;
label_392:
    knapsack18 = 0;
    goto label_393;
label_393:
    knapsack2 = knapsack19;
    goto label_394;
label_394:
    knapsack19 = 0;
    goto label_395;
label_395:
    knapsack3 = knapsack20;
    goto label_396;
label_396:
    knapsack20 = 0;
    goto label_397;
label_397:
    knapsack4 = knapsack21;
    goto label_398;
label_398:
    knapsack21 = 0;
    goto label_399;
label_399:
    knapsack5 = knapsack22;
    goto label_400;
label_400:
    knapsack22 = 0;
    goto label_401;
label_401:
    knapsack6 = knapsack23;
    goto label_402;
label_402:
    knapsack23 = 0;
    goto label_403;
label_403:
    knapsack7 = knapsack24;
    goto label_404;
label_404:
    knapsack24 = 0;
    goto label_405;
label_405:
    knapsack8 = knapsack25;
    goto label_406;
label_406:
    knapsack25 = 0;
    goto label_407;
label_407:
    knapsack9 = knapsack26;
    goto label_408;
label_408:
    knapsack26 = 0;
    goto label_409;
label_409:
    knapsack10 = knapsack27;
    goto label_410;
label_410:
    knapsack27 = 0;
    goto label_411;
label_411:
    knapsack11 = knapsack28;
    goto label_412;
label_412:
    knapsack28 = 0;
    goto label_413;
label_413:
    knapsack12 = knapsack29;
    goto label_414;
label_414:
    knapsack29 = 0;
    goto label_415;
label_415:
    knapsack13 = knapsack30;
    goto label_416;
label_416:
    knapsack30 = 0;
    goto label_417;
label_417:
    knapsack14 = knapsack31;
    goto label_418;
label_418:
    knapsack31 = 0;
    goto label_419;
label_419:
    knapsack15 = knapsack32;
    goto label_420;
label_420:
    knapsack32 = 0;
    goto label_421;
label_421:
    knapsack16 = knapsack33;
    goto label_422;
label_422:
    knapsack33 = 0;
    goto label_423;
label_423:
    i = i+1;
    goto label_68;
label_424:
    range = output;
    goto label_426;
label_426:
    result = 0;
    goto label_427;
label_427:
    if (range>=2) goto label_428;
    else goto label_444;
label_428:
    count = 0;
    goto label_429;
label_429:
    i = 2;
    goto label_430;
label_430:
    if ((i*i)<=range) goto label_431;
    else goto label_440;
label_431:
    k = range;
    goto label_432;
label_432:
    if (count>0) goto label_433;
    else goto label_434;
label_433:
    goto label_439;
label_434:
    if (k>=1) goto label_435;
    else goto label_439;
label_435:
    if ((k*i)==range) goto label_436;
    else goto label_437;
label_436:
    count = count+1;
    goto label_438;
label_437:
    goto label_438;
label_438:
    k = k-1;
    goto label_434;
label_439:
    i = i+1;
    goto label_430;
label_440:
    if (count>0) goto label_441;
    else goto label_442;
label_441:
    goto label_443;
label_442:
    result = 1+result;
    goto label_443;
label_443:
    range = range-1;
    goto label_427;
label_444:
    output = result;
    goto exit;
exit:
    vars[0] = W;
    vars[1] = closestprime;
    vars[2] = count;
    vars[3] = endput;
    vars[4] = i;
    vars[5] = input;
    vars[6] = j;
    vars[7] = k;
    vars[8] = knapsack0;
    vars[9] = knapsack1;
    vars[10] = knapsack10;
    vars[11] = knapsack11;
    vars[12] = knapsack12;
    vars[13] = knapsack13;
    vars[14] = knapsack14;
    vars[15] = knapsack15;
    vars[16] = knapsack16;
    vars[17] = knapsack17;
    vars[18] = knapsack18;
    vars[19] = knapsack19;
    vars[20] = knapsack2;
    vars[21] = knapsack20;
    vars[22] = knapsack21;
    vars[23] = knapsack22;
    vars[24] = knapsack23;
    vars[25] = knapsack24;
    vars[26] = knapsack25;
    vars[27] = knapsack26;
    vars[28] = knapsack27;
    vars[29] = knapsack28;
    vars[30] = knapsack29;
    vars[31] = knapsack3;
    vars[32] = knapsack30;
    vars[33] = knapsack31;
    vars[34] = knapsack32;
    vars[35] = knapsack33;
    vars[36] = knapsack4;
    vars[37] = knapsack5;
    vars[38] = knapsack6;
    vars[39] = knapsack7;
    vars[40] = knapsack8;
    vars[41] = knapsack9;
    vars[42] = mod;
    vars[43] = n;
    vars[44] = output;
    vars[45] = range;
    vars[46] = result;
    vars[47] = sqrt;
    vars[48] = stop;
    vars[49] = stop1;
    vars[50] = val0;
    vars[51] = val1;
    vars[52] = w;
    vars[53] = weights0;
    vars[54] = weights1;
    return vars[44];
}
