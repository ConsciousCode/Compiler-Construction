#include <stdint.h>
int64_t madprimes(int64_t vars[]) {
    int64_t W = vars[0], closestprime = vars[1], count = vars[2], endput = vars[3], i = vars[4], input = vars[5], j = vars[6], k = vars[7], knapsack0 = vars[8], knapsack1 = vars[9], knapsack10 = vars[10], knapsack11 = vars[11], knapsack12 = vars[12], knapsack13 = vars[13], knapsack14 = vars[14], knapsack15 = vars[15], knapsack16 = vars[16], knapsack17 = vars[17], knapsack18 = vars[18], knapsack19 = vars[19], knapsack2 = vars[20], knapsack20 = vars[21], knapsack21 = vars[22], knapsack22 = vars[23], knapsack23 = vars[24], knapsack24 = vars[25], knapsack25 = vars[26], knapsack26 = vars[27], knapsack27 = vars[28], knapsack28 = vars[29], knapsack29 = vars[30], knapsack3 = vars[31], knapsack30 = vars[32], knapsack31 = vars[33], knapsack32 = vars[34], knapsack33 = vars[35], knapsack4 = vars[36], knapsack5 = vars[37], knapsack6 = vars[38], knapsack7 = vars[39], knapsack8 = vars[40], knapsack9 = vars[41], mod = vars[42], n = vars[43], output = vars[44], range = vars[45], result = vars[46], sqrt = vars[47], stop = vars[48], stop1 = vars[49], val0 = vars[50], val1 = vars[51], w = vars[52], weights0 = vars[53], weights1 = vars[54];
    input = W;
    mod = input;
    while (!((mod==1)||(mod==0))) {
        mod = mod-2;
    }

    if (mod==1) {
        input = input-2;
    }
    else {
        input = input-1;
    }

    i = input;
    stop1 = 0;
    while ((i>=2)&&(stop1==0)) {
        sqrt = 1;
        while ((sqrt*sqrt)<=i) {
            sqrt = sqrt+1;
        }

        j = 3;
        stop = 0;
        while ((j<=sqrt)&&(stop==0)) {
            mod = i;
            while (mod>0) {
                mod = mod-j;
            }

            if (mod==0) {
                stop = 1;
            }
            else {
                j = j+2;
            }

        }

        if (j>sqrt) {
            stop1 = 1;
        }
        else {
            i = i-2;
        }

    }

    closestprime = i;
    output = 0;
    W = closestprime;
    n = 2;
    i = 0;
    weights0 = 15;
    val0 = 9;
    weights1 = 13;
    val1 = 10;
    knapsack0 = 0;
    knapsack1 = 0;
    knapsack2 = 0;
    knapsack3 = 0;
    knapsack4 = 0;
    knapsack5 = 0;
    knapsack6 = 0;
    knapsack7 = 0;
    knapsack8 = 0;
    knapsack9 = 0;
    knapsack10 = 0;
    knapsack11 = 0;
    knapsack12 = 0;
    knapsack13 = 0;
    knapsack14 = 0;
    knapsack15 = 0;
    knapsack16 = 0;
    knapsack17 = 0;
    knapsack18 = 0;
    knapsack19 = 0;
    knapsack20 = 0;
    knapsack21 = 0;
    knapsack22 = 0;
    knapsack23 = 0;
    knapsack24 = 0;
    knapsack25 = 0;
    knapsack26 = 0;
    knapsack27 = 0;
    knapsack28 = 0;
    knapsack29 = 0;
    knapsack30 = 0;
    knapsack31 = 0;
    knapsack32 = 0;
    knapsack33 = 0;
    while ((i*17)<=W) {
        w = 1;
        if ((knapsack0+(val0*w))>knapsack15) {
            knapsack15 = knapsack0+(val0*w);
        }
        else {
;
        }

        w = w+1;
        if ((knapsack0+(val0*w))>knapsack30) {
            knapsack30 = knapsack0+(val0*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack1+(val0*w))>knapsack16) {
            knapsack16 = knapsack1+(val0*w);
        }
        else {
;
        }

        w = w+1;
        if ((knapsack1+(val0*w))>knapsack31) {
            knapsack31 = knapsack1+(val0*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack2+(val0*w))>knapsack17) {
            knapsack17 = knapsack2+(val0*w);
        }
        else {
;
        }

        w = w+1;
        if ((knapsack2+(val0*w))>knapsack32) {
            knapsack32 = knapsack2+(val0*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack3+(val0*w))>knapsack18) {
            knapsack18 = knapsack3+(val0*w);
        }
        else {
;
        }

        w = w+1;
        if ((knapsack3+(val0*w))>knapsack33) {
            knapsack33 = knapsack3+(val0*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack4+(val0*w))>knapsack19) {
            knapsack19 = knapsack4+(val0*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack5+(val0*w))>knapsack20) {
            knapsack20 = knapsack5+(val0*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack6+(val0*w))>knapsack21) {
            knapsack21 = knapsack6+(val0*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack7+(val0*w))>knapsack22) {
            knapsack22 = knapsack7+(val0*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack8+(val0*w))>knapsack23) {
            knapsack23 = knapsack8+(val0*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack9+(val0*w))>knapsack24) {
            knapsack24 = knapsack9+(val0*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack10+(val0*w))>knapsack25) {
            knapsack25 = knapsack10+(val0*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack11+(val0*w))>knapsack26) {
            knapsack26 = knapsack11+(val0*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack12+(val0*w))>knapsack27) {
            knapsack27 = knapsack12+(val0*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack13+(val0*w))>knapsack28) {
            knapsack28 = knapsack13+(val0*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack14+(val0*w))>knapsack29) {
            knapsack29 = knapsack14+(val0*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack15+(val0*w))>knapsack30) {
            knapsack30 = knapsack15+(val0*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack16+(val0*w))>knapsack31) {
            knapsack31 = knapsack16+(val0*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack0+(val1*w))>knapsack13) {
            knapsack13 = knapsack0+(val1*w);
        }
        else {
;
        }

        w = w+1;
        if ((knapsack0+(val1*w))>knapsack26) {
            knapsack26 = knapsack0+(val1*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack1+(val1*w))>knapsack14) {
            knapsack14 = knapsack1+(val1*w);
        }
        else {
;
        }

        w = w+1;
        if ((knapsack1+(val1*w))>knapsack27) {
            knapsack27 = knapsack1+(val1*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack2+(val1*w))>knapsack15) {
            knapsack15 = knapsack2+(val1*w);
        }
        else {
;
        }

        w = w+1;
        if ((knapsack2+(val1*w))>knapsack28) {
            knapsack28 = knapsack2+(val1*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack3+(val1*w))>knapsack16) {
            knapsack16 = knapsack3+(val1*w);
        }
        else {
;
        }

        w = w+1;
        if ((knapsack3+(val1*w))>knapsack29) {
            knapsack29 = knapsack3+(val1*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack4+(val1*w))>knapsack17) {
            knapsack17 = knapsack4+(val1*w);
        }
        else {
;
        }

        w = w+1;
        if ((knapsack4+(val1*w))>knapsack30) {
            knapsack30 = knapsack4+(val1*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack5+(val1*w))>knapsack18) {
            knapsack18 = knapsack5+(val1*w);
        }
        else {
;
        }

        w = w+1;
        if ((knapsack5+(val1*w))>knapsack31) {
            knapsack31 = knapsack5+(val1*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack6+(val1*w))>knapsack19) {
            knapsack19 = knapsack6+(val1*w);
        }
        else {
;
        }

        w = w+1;
        if ((knapsack6+(val1*w))>knapsack32) {
            knapsack32 = knapsack6+(val1*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack7+(val1*w))>knapsack20) {
            knapsack20 = knapsack7+(val1*w);
        }
        else {
;
        }

        w = w+1;
        if ((knapsack7+(val1*w))>knapsack33) {
            knapsack33 = knapsack7+(val1*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack8+(val1*w))>knapsack21) {
            knapsack21 = knapsack8+(val1*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack9+(val1*w))>knapsack22) {
            knapsack22 = knapsack9+(val1*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack10+(val1*w))>knapsack23) {
            knapsack23 = knapsack10+(val1*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack11+(val1*w))>knapsack24) {
            knapsack24 = knapsack11+(val1*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack12+(val1*w))>knapsack25) {
            knapsack25 = knapsack12+(val1*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack13+(val1*w))>knapsack26) {
            knapsack26 = knapsack13+(val1*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack14+(val1*w))>knapsack27) {
            knapsack27 = knapsack14+(val1*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack15+(val1*w))>knapsack28) {
            knapsack28 = knapsack15+(val1*w);
        }
        else {
;
        }

        w = w+1;
        w = 1;
        if ((knapsack16+(val1*w))>knapsack29) {
            knapsack29 = knapsack16+(val1*w);
        }
        else {
;
        }

        w = w+1;
        if ((output<knapsack0)&&(((i*17)+0)<=W)) {
            output = knapsack0;
        }
        else {
;
        }

        if ((output<knapsack1)&&(((i*17)+1)<=W)) {
            output = knapsack1;
        }
        else {
;
        }

        if ((output<knapsack2)&&(((i*17)+2)<=W)) {
            output = knapsack2;
        }
        else {
;
        }

        if ((output<knapsack3)&&(((i*17)+3)<=W)) {
            output = knapsack3;
        }
        else {
;
        }

        if ((output<knapsack4)&&(((i*17)+4)<=W)) {
            output = knapsack4;
        }
        else {
;
        }

        if ((output<knapsack5)&&(((i*17)+5)<=W)) {
            output = knapsack5;
        }
        else {
;
        }

        if ((output<knapsack6)&&(((i*17)+6)<=W)) {
            output = knapsack6;
        }
        else {
;
        }

        if ((output<knapsack7)&&(((i*17)+7)<=W)) {
            output = knapsack7;
        }
        else {
;
        }

        if ((output<knapsack8)&&(((i*17)+8)<=W)) {
            output = knapsack8;
        }
        else {
;
        }

        if ((output<knapsack9)&&(((i*17)+9)<=W)) {
            output = knapsack9;
        }
        else {
;
        }

        if ((output<knapsack10)&&(((i*17)+10)<=W)) {
            output = knapsack10;
        }
        else {
;
        }

        if ((output<knapsack11)&&(((i*17)+11)<=W)) {
            output = knapsack11;
        }
        else {
;
        }

        if ((output<knapsack12)&&(((i*17)+12)<=W)) {
            output = knapsack12;
        }
        else {
;
        }

        if ((output<knapsack13)&&(((i*17)+13)<=W)) {
            output = knapsack13;
        }
        else {
;
        }

        if ((output<knapsack14)&&(((i*17)+14)<=W)) {
            output = knapsack14;
        }
        else {
;
        }

        if ((output<knapsack15)&&(((i*17)+15)<=W)) {
            output = knapsack15;
        }
        else {
;
        }

        if ((output<knapsack16)&&(((i*17)+16)<=W)) {
            output = knapsack16;
        }
        else {
;
        }

        if ((output<knapsack17)&&(((i*17)+17)<=W)) {
            output = knapsack17;
        }
        else {
;
        }

        if ((output<knapsack18)&&(((i*17)+18)<=W)) {
            output = knapsack18;
        }
        else {
;
        }

        if ((output<knapsack19)&&(((i*17)+19)<=W)) {
            output = knapsack19;
        }
        else {
;
        }

        if ((output<knapsack20)&&(((i*17)+20)<=W)) {
            output = knapsack20;
        }
        else {
;
        }

        if ((output<knapsack21)&&(((i*17)+21)<=W)) {
            output = knapsack21;
        }
        else {
;
        }

        if ((output<knapsack22)&&(((i*17)+22)<=W)) {
            output = knapsack22;
        }
        else {
;
        }

        if ((output<knapsack23)&&(((i*17)+23)<=W)) {
            output = knapsack23;
        }
        else {
;
        }

        if ((output<knapsack24)&&(((i*17)+24)<=W)) {
            output = knapsack24;
        }
        else {
;
        }

        if ((output<knapsack25)&&(((i*17)+25)<=W)) {
            output = knapsack25;
        }
        else {
;
        }

        if ((output<knapsack26)&&(((i*17)+26)<=W)) {
            output = knapsack26;
        }
        else {
;
        }

        if ((output<knapsack27)&&(((i*17)+27)<=W)) {
            output = knapsack27;
        }
        else {
;
        }

        if ((output<knapsack28)&&(((i*17)+28)<=W)) {
            output = knapsack28;
        }
        else {
;
        }

        if ((output<knapsack29)&&(((i*17)+29)<=W)) {
            output = knapsack29;
        }
        else {
;
        }

        if ((output<knapsack30)&&(((i*17)+30)<=W)) {
            output = knapsack30;
        }
        else {
;
        }

        if ((output<knapsack31)&&(((i*17)+31)<=W)) {
            output = knapsack31;
        }
        else {
;
        }

        if ((output<knapsack32)&&(((i*17)+32)<=W)) {
            output = knapsack32;
        }
        else {
;
        }

        if ((output<knapsack33)&&(((i*17)+33)<=W)) {
            output = knapsack33;
        }
        else {
;
        }

        knapsack0 = knapsack17;
        knapsack17 = 0;
        knapsack1 = knapsack18;
        knapsack18 = 0;
        knapsack2 = knapsack19;
        knapsack19 = 0;
        knapsack3 = knapsack20;
        knapsack20 = 0;
        knapsack4 = knapsack21;
        knapsack21 = 0;
        knapsack5 = knapsack22;
        knapsack22 = 0;
        knapsack6 = knapsack23;
        knapsack23 = 0;
        knapsack7 = knapsack24;
        knapsack24 = 0;
        knapsack8 = knapsack25;
        knapsack25 = 0;
        knapsack9 = knapsack26;
        knapsack26 = 0;
        knapsack10 = knapsack27;
        knapsack27 = 0;
        knapsack11 = knapsack28;
        knapsack28 = 0;
        knapsack12 = knapsack29;
        knapsack29 = 0;
        knapsack13 = knapsack30;
        knapsack30 = 0;
        knapsack14 = knapsack31;
        knapsack31 = 0;
        knapsack15 = knapsack32;
        knapsack32 = 0;
        knapsack16 = knapsack33;
        knapsack33 = 0;
        i = i+1;
    }

    range = output;
    endput = output;
    result = 0;
    while (range>=2) {
        count = 0;
        i = 2;
        while ((i*i)<=range) {
            k = range;
            if (count>0) {
;
            }
            else {
                while (k>=1) {
                    if ((k*i)==range) {
                        count = count+1;
                    }
                    else {
;
                    }

                    k = k-1;
                }

            }

            i = i+1;
        }

        if (count>0) {
;
        }
        else {
            result = 1+result;
        }

        range = range-1;
    }

    output = result;
    vars[0] = W;
    vars[1] = closestprime;
    vars[2] = count;
    vars[3] = endput;
    vars[4] = i;
    vars[5] = input;
    vars[6] = j;
    vars[7] = k;
    vars[8] = knapsack0;
    vars[9] = knapsack1;
    vars[10] = knapsack10;
    vars[11] = knapsack11;
    vars[12] = knapsack12;
    vars[13] = knapsack13;
    vars[14] = knapsack14;
    vars[15] = knapsack15;
    vars[16] = knapsack16;
    vars[17] = knapsack17;
    vars[18] = knapsack18;
    vars[19] = knapsack19;
    vars[20] = knapsack2;
    vars[21] = knapsack20;
    vars[22] = knapsack21;
    vars[23] = knapsack22;
    vars[24] = knapsack23;
    vars[25] = knapsack24;
    vars[26] = knapsack25;
    vars[27] = knapsack26;
    vars[28] = knapsack27;
    vars[29] = knapsack28;
    vars[30] = knapsack29;
    vars[31] = knapsack3;
    vars[32] = knapsack30;
    vars[33] = knapsack31;
    vars[34] = knapsack32;
    vars[35] = knapsack33;
    vars[36] = knapsack4;
    vars[37] = knapsack5;
    vars[38] = knapsack6;
    vars[39] = knapsack7;
    vars[40] = knapsack8;
    vars[41] = knapsack9;
    vars[42] = mod;
    vars[43] = n;
    vars[44] = output;
    vars[45] = range;
    vars[46] = result;
    vars[47] = sqrt;
    vars[48] = stop;
    vars[49] = stop1;
    vars[50] = val0;
    vars[51] = val1;
    vars[52] = w;
    vars[53] = weights0;
    vars[54] = weights1;
    return vars[44];
}
