#include <stdint.h>
int64_t isprime(int64_t vars[]) {
    int64_t composite = vars[0], i = vars[1], input = vars[2], j = vars[3], output = vars[4];
    composite = 0;
    i = 2;
    while ((i<input)&&(composite==0)) {
        j = 1;
        while ((i*j)<input) {
            j = j+1;
        }

        if ((i*j)==input) {
            composite = 1;
        }
        else {
            i = i+1;
        }

    }

    output = 1-composite;
    vars[0] = composite;
    vars[1] = i;
    vars[2] = input;
    vars[3] = j;
    vars[4] = output;
    return vars[4];
}
