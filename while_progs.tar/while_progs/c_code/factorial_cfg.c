#include <stdint.h>
int64_t factorial(int64_t vars[]) {
    int64_t output = 0, x = vars[1], y = 0, z = 0;
label_0:
    y = x;
    goto label_1;
label_1:
    z = 1;
    goto label_2;
label_2:
    if (y>1) goto label_3;
    else goto label_6;
label_3:
    z = z*y;
    goto label_4;
label_4:
    y = y-1;
    goto label_2;
label_6:
    output = z;
    goto exit;
exit:
    vars[0] = output;
    vars[1] = x;
    vars[2] = y;
    vars[3] = z;
    return vars[0];
}
