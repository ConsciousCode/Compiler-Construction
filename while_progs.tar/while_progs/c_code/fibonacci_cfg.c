#include <stdint.h>
int64_t fibonacci(int64_t vars[]) {
    int64_t a = 0, b = 0, n = vars[2], output = 0, t = 0, z = 0;
label_0:
    a = 0;
    goto label_1;
label_1:
    b = 1;
    goto label_2;
label_2:
    z = 0;
    goto label_3;
label_3:
    if (!(n==z)) goto label_4;
    else goto label_9;
label_4:
    t = a+b;
    goto label_5;
label_5:
    a = b;
    goto label_6;
label_6:
    b = t;
    goto label_7;
label_7:
    n = n-1;
    goto label_8;
label_8:
    z = 0;
    goto label_3;
label_9:
    output = a;
    goto exit;
exit:
    vars[0] = a;
    vars[1] = b;
    vars[2] = n;
    vars[3] = output;
    vars[4] = t;
    vars[5] = z;
    return vars[3];
}
