#include <stdint.h>
int64_t closest_prime(int64_t vars[]) {
    int64_t closestprime = 0, i = 0, input = vars[2], j = 0, mod = 0, output = 0, sqrt = 0, stop = 0, stop1 = 0;
label_0:
    mod = input;
    goto label_1;
label_1:
    if (!((mod==1)||(mod==0))) goto label_2;
    else goto label_3;
label_2:
    mod = mod-2;
    goto label_1;
label_3:
    if (mod==1) goto label_4;
    else goto label_5;
label_4:
    input = input-2;
    goto label_6;
label_5:
    input = input-1;
    goto label_6;
label_6:
    i = input;
    goto label_7;
label_7:
    stop1 = 0;
    goto label_8;
label_8:
    if ((i>=2)&&(stop1==0)) goto label_9;
    else goto label_24;
label_9:
    sqrt = 1;
    goto label_10;
label_10:
    if ((sqrt*sqrt)<=i) goto label_11;
    else goto label_12;
label_11:
    sqrt = sqrt+1;
    goto label_10;
label_12:
    j = 3;
    goto label_13;
label_13:
    stop = 0;
    goto label_14;
label_14:
    if ((j<=sqrt)&&(stop==0)) goto label_15;
    else goto label_21;
label_15:
    mod = i;
    goto label_16;
label_16:
    if (mod>0) goto label_17;
    else goto label_18;
label_17:
    mod = mod-j;
    goto label_16;
label_18:
    if (mod==0) goto label_19;
    else goto label_20;
label_19:
    stop = 1;
    goto label_14;
label_20:
    j = j+2;
    goto label_14;
label_21:
    if (j>sqrt) goto label_22;
    else goto label_23;
label_22:
    stop1 = 1;
    goto label_8;
label_23:
    i = i-2;
    goto label_8;
label_24:
    closestprime = i;
    goto label_25;
label_25:
    output = closestprime;
    goto exit;
exit:
    vars[0] = closestprime;
    vars[1] = i;
    vars[2] = input;
    vars[3] = j;
    vars[4] = mod;
    vars[5] = output;
    vars[6] = sqrt;
    vars[7] = stop;
    vars[8] = stop1;
    return vars[5];
}
