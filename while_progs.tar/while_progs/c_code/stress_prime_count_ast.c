#include <stdint.h>
int64_t stress_prime_count(int64_t vars[]) {
    int64_t c = vars[0], count = vars[1], d = vars[2], dm1 = vars[3], input = vars[4], isprime = vars[5], n = vars[6], output = vars[7], rem = vars[8];
    n = input;
    count = 0;
    c = n;
    while (c>1) {
        isprime = 1;
        d = c-1;
        while (d>1) {
            rem = c;
            dm1 = d-1;
            while (rem>dm1) {
                rem = rem-d;
            }

            if (rem==0) {
                isprime = 0;
            }
            else {
;
            }

            d = d-1;
        }

        if (isprime==1) {
            count = count+1;
        }
        else {
;
        }

        c = c-1;
    }

    output = count;
    vars[0] = c;
    vars[1] = count;
    vars[2] = d;
    vars[3] = dm1;
    vars[4] = input;
    vars[5] = isprime;
    vars[6] = n;
    vars[7] = output;
    vars[8] = rem;
    return vars[7];
}
