#include <stdint.h>
int64_t stress_gcd_mod(int64_t vars[]) {
    int64_t a = vars[0], b = vars[1], input = vars[2], input2 = vars[3], output = vars[4], t = vars[5];
    a = input;
    b = input2;
    while (!(a==0)) {
        while (b>=a) {
            b = b-a;
        }

        t = a;
        a = b;
        b = t;
    }

    output = b;
    vars[0] = a;
    vars[1] = b;
    vars[2] = input;
    vars[3] = input2;
    vars[4] = output;
    vars[5] = t;
    return vars[4];
}
