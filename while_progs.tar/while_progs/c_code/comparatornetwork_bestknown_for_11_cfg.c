#include <stdint.h>
int64_t comparatornetwork_bestknown_for_11(int64_t vars[]) {
    int64_t output = 0, t = 0, w0 = vars[2], w1 = vars[3], w10 = vars[4], w2 = vars[5], w3 = vars[6], w4 = vars[7], w5 = vars[8], w6 = vars[9], w7 = vars[10], w8 = vars[11], w9 = vars[12];
label_0:
    if (w0<w1) goto label_1;
    else goto label_2;
label_1:
    goto label_5;
label_2:
    t = w0;
    goto label_3;
label_3:
    w0 = w1;
    goto label_4;
label_4:
    w1 = t;
    goto label_5;
label_5:
    if (w2<w3) goto label_6;
    else goto label_7;
label_6:
    goto label_10;
label_7:
    t = w2;
    goto label_8;
label_8:
    w2 = w3;
    goto label_9;
label_9:
    w3 = t;
    goto label_10;
label_10:
    if (w4<w5) goto label_11;
    else goto label_12;
label_11:
    goto label_15;
label_12:
    t = w4;
    goto label_13;
label_13:
    w4 = w5;
    goto label_14;
label_14:
    w5 = t;
    goto label_15;
label_15:
    if (w6<w7) goto label_16;
    else goto label_17;
label_16:
    goto label_20;
label_17:
    t = w6;
    goto label_18;
label_18:
    w6 = w7;
    goto label_19;
label_19:
    w7 = t;
    goto label_20;
label_20:
    if (w8<w9) goto label_21;
    else goto label_22;
label_21:
    goto label_25;
label_22:
    t = w8;
    goto label_23;
label_23:
    w8 = w9;
    goto label_24;
label_24:
    w9 = t;
    goto label_25;
label_25:
    if (w1<w3) goto label_26;
    else goto label_27;
label_26:
    goto label_30;
label_27:
    t = w1;
    goto label_28;
label_28:
    w1 = w3;
    goto label_29;
label_29:
    w3 = t;
    goto label_30;
label_30:
    if (w5<w7) goto label_31;
    else goto label_32;
label_31:
    goto label_35;
label_32:
    t = w5;
    goto label_33;
label_33:
    w5 = w7;
    goto label_34;
label_34:
    w7 = t;
    goto label_35;
label_35:
    if (w0<w2) goto label_36;
    else goto label_37;
label_36:
    goto label_40;
label_37:
    t = w0;
    goto label_38;
label_38:
    w0 = w2;
    goto label_39;
label_39:
    w2 = t;
    goto label_40;
label_40:
    if (w4<w6) goto label_41;
    else goto label_42;
label_41:
    goto label_45;
label_42:
    t = w4;
    goto label_43;
label_43:
    w4 = w6;
    goto label_44;
label_44:
    w6 = t;
    goto label_45;
label_45:
    if (w8<w10) goto label_46;
    else goto label_47;
label_46:
    goto label_50;
label_47:
    t = w8;
    goto label_48;
label_48:
    w8 = w10;
    goto label_49;
label_49:
    w10 = t;
    goto label_50;
label_50:
    if (w1<w2) goto label_51;
    else goto label_52;
label_51:
    goto label_55;
label_52:
    t = w1;
    goto label_53;
label_53:
    w1 = w2;
    goto label_54;
label_54:
    w2 = t;
    goto label_55;
label_55:
    if (w5<w6) goto label_56;
    else goto label_57;
label_56:
    goto label_60;
label_57:
    t = w5;
    goto label_58;
label_58:
    w5 = w6;
    goto label_59;
label_59:
    w6 = t;
    goto label_60;
label_60:
    if (w9<w10) goto label_61;
    else goto label_62;
label_61:
    goto label_65;
label_62:
    t = w9;
    goto label_63;
label_63:
    w9 = w10;
    goto label_64;
label_64:
    w10 = t;
    goto label_65;
label_65:
    if (w1<w5) goto label_66;
    else goto label_67;
label_66:
    goto label_70;
label_67:
    t = w1;
    goto label_68;
label_68:
    w1 = w5;
    goto label_69;
label_69:
    w5 = t;
    goto label_70;
label_70:
    if (w6<w10) goto label_71;
    else goto label_72;
label_71:
    goto label_75;
label_72:
    t = w6;
    goto label_73;
label_73:
    w6 = w10;
    goto label_74;
label_74:
    w10 = t;
    goto label_75;
label_75:
    if (w5<w9) goto label_76;
    else goto label_77;
label_76:
    goto label_80;
label_77:
    t = w5;
    goto label_78;
label_78:
    w5 = w9;
    goto label_79;
label_79:
    w9 = t;
    goto label_80;
label_80:
    if (w2<w6) goto label_81;
    else goto label_82;
label_81:
    goto label_85;
label_82:
    t = w2;
    goto label_83;
label_83:
    w2 = w6;
    goto label_84;
label_84:
    w6 = t;
    goto label_85;
label_85:
    if (w1<w5) goto label_86;
    else goto label_87;
label_86:
    goto label_90;
label_87:
    t = w1;
    goto label_88;
label_88:
    w1 = w5;
    goto label_89;
label_89:
    w5 = t;
    goto label_90;
label_90:
    if (w6<w10) goto label_91;
    else goto label_92;
label_91:
    goto label_95;
label_92:
    t = w6;
    goto label_93;
label_93:
    w6 = w10;
    goto label_94;
label_94:
    w10 = t;
    goto label_95;
label_95:
    if (w0<w4) goto label_96;
    else goto label_97;
label_96:
    goto label_100;
label_97:
    t = w0;
    goto label_98;
label_98:
    w0 = w4;
    goto label_99;
label_99:
    w4 = t;
    goto label_100;
label_100:
    if (w3<w7) goto label_101;
    else goto label_102;
label_101:
    goto label_105;
label_102:
    t = w3;
    goto label_103;
label_103:
    w3 = w7;
    goto label_104;
label_104:
    w7 = t;
    goto label_105;
label_105:
    if (w4<w8) goto label_106;
    else goto label_107;
label_106:
    goto label_110;
label_107:
    t = w4;
    goto label_108;
label_108:
    w4 = w8;
    goto label_109;
label_109:
    w8 = t;
    goto label_110;
label_110:
    if (w0<w4) goto label_111;
    else goto label_112;
label_111:
    goto label_115;
label_112:
    t = w0;
    goto label_113;
label_113:
    w0 = w4;
    goto label_114;
label_114:
    w4 = t;
    goto label_115;
label_115:
    if (w1<w4) goto label_116;
    else goto label_117;
label_116:
    goto label_120;
label_117:
    t = w1;
    goto label_118;
label_118:
    w1 = w4;
    goto label_119;
label_119:
    w4 = t;
    goto label_120;
label_120:
    if (w7<w10) goto label_121;
    else goto label_122;
label_121:
    goto label_125;
label_122:
    t = w7;
    goto label_123;
label_123:
    w7 = w10;
    goto label_124;
label_124:
    w10 = t;
    goto label_125;
label_125:
    if (w3<w8) goto label_126;
    else goto label_127;
label_126:
    goto label_130;
label_127:
    t = w3;
    goto label_128;
label_128:
    w3 = w8;
    goto label_129;
label_129:
    w8 = t;
    goto label_130;
label_130:
    if (w2<w3) goto label_131;
    else goto label_132;
label_131:
    goto label_135;
label_132:
    t = w2;
    goto label_133;
label_133:
    w2 = w3;
    goto label_134;
label_134:
    w3 = t;
    goto label_135;
label_135:
    if (w8<w9) goto label_136;
    else goto label_137;
label_136:
    goto label_140;
label_137:
    t = w8;
    goto label_138;
label_138:
    w8 = w9;
    goto label_139;
label_139:
    w9 = t;
    goto label_140;
label_140:
    if (w2<w4) goto label_141;
    else goto label_142;
label_141:
    goto label_145;
label_142:
    t = w2;
    goto label_143;
label_143:
    w2 = w4;
    goto label_144;
label_144:
    w4 = t;
    goto label_145;
label_145:
    if (w7<w9) goto label_146;
    else goto label_147;
label_146:
    goto label_150;
label_147:
    t = w7;
    goto label_148;
label_148:
    w7 = w9;
    goto label_149;
label_149:
    w9 = t;
    goto label_150;
label_150:
    if (w3<w5) goto label_151;
    else goto label_152;
label_151:
    goto label_155;
label_152:
    t = w3;
    goto label_153;
label_153:
    w3 = w5;
    goto label_154;
label_154:
    w5 = t;
    goto label_155;
label_155:
    if (w6<w8) goto label_156;
    else goto label_157;
label_156:
    goto label_160;
label_157:
    t = w6;
    goto label_158;
label_158:
    w6 = w8;
    goto label_159;
label_159:
    w8 = t;
    goto label_160;
label_160:
    if (w3<w4) goto label_161;
    else goto label_162;
label_161:
    goto label_165;
label_162:
    t = w3;
    goto label_163;
label_163:
    w3 = w4;
    goto label_164;
label_164:
    w4 = t;
    goto label_165;
label_165:
    if (w5<w6) goto label_166;
    else goto label_167;
label_166:
    goto label_170;
label_167:
    t = w5;
    goto label_168;
label_168:
    w5 = w6;
    goto label_169;
label_169:
    w6 = t;
    goto label_170;
label_170:
    if (w7<w8) goto label_171;
    else goto label_172;
label_171:
    goto label_175;
label_172:
    t = w7;
    goto label_173;
label_173:
    w7 = w8;
    goto label_174;
label_174:
    w8 = t;
    goto label_175;
label_175:
    output = (((((((((w0+w1)+w2)+w3)+w4)+w5)+w6)+w7)+w8)+w9)+w10;
    goto exit;
exit:
    vars[0] = output;
    vars[1] = t;
    vars[2] = w0;
    vars[3] = w1;
    vars[4] = w10;
    vars[5] = w2;
    vars[6] = w3;
    vars[7] = w4;
    vars[8] = w5;
    vars[9] = w6;
    vars[10] = w7;
    vars[11] = w8;
    vars[12] = w9;
    return vars[0];
}
