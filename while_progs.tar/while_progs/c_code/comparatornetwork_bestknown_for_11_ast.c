#include <stdint.h>
int64_t comparatornetwork_bestknown_for_11(int64_t vars[]) {
    int64_t output = vars[0], t = vars[1], w0 = vars[2], w1 = vars[3], w10 = vars[4], w2 = vars[5], w3 = vars[6], w4 = vars[7], w5 = vars[8], w6 = vars[9], w7 = vars[10], w8 = vars[11], w9 = vars[12];
    if (w0<w1) {
;
    }
    else {
        t = w0;
        w0 = w1;
        w1 = t;
    }

    if (w2<w3) {
;
    }
    else {
        t = w2;
        w2 = w3;
        w3 = t;
    }

    if (w4<w5) {
;
    }
    else {
        t = w4;
        w4 = w5;
        w5 = t;
    }

    if (w6<w7) {
;
    }
    else {
        t = w6;
        w6 = w7;
        w7 = t;
    }

    if (w8<w9) {
;
    }
    else {
        t = w8;
        w8 = w9;
        w9 = t;
    }

    if (w1<w3) {
;
    }
    else {
        t = w1;
        w1 = w3;
        w3 = t;
    }

    if (w5<w7) {
;
    }
    else {
        t = w5;
        w5 = w7;
        w7 = t;
    }

    if (w0<w2) {
;
    }
    else {
        t = w0;
        w0 = w2;
        w2 = t;
    }

    if (w4<w6) {
;
    }
    else {
        t = w4;
        w4 = w6;
        w6 = t;
    }

    if (w8<w10) {
;
    }
    else {
        t = w8;
        w8 = w10;
        w10 = t;
    }

    if (w1<w2) {
;
    }
    else {
        t = w1;
        w1 = w2;
        w2 = t;
    }

    if (w5<w6) {
;
    }
    else {
        t = w5;
        w5 = w6;
        w6 = t;
    }

    if (w9<w10) {
;
    }
    else {
        t = w9;
        w9 = w10;
        w10 = t;
    }

    if (w1<w5) {
;
    }
    else {
        t = w1;
        w1 = w5;
        w5 = t;
    }

    if (w6<w10) {
;
    }
    else {
        t = w6;
        w6 = w10;
        w10 = t;
    }

    if (w5<w9) {
;
    }
    else {
        t = w5;
        w5 = w9;
        w9 = t;
    }

    if (w2<w6) {
;
    }
    else {
        t = w2;
        w2 = w6;
        w6 = t;
    }

    if (w1<w5) {
;
    }
    else {
        t = w1;
        w1 = w5;
        w5 = t;
    }

    if (w6<w10) {
;
    }
    else {
        t = w6;
        w6 = w10;
        w10 = t;
    }

    if (w0<w4) {
;
    }
    else {
        t = w0;
        w0 = w4;
        w4 = t;
    }

    if (w3<w7) {
;
    }
    else {
        t = w3;
        w3 = w7;
        w7 = t;
    }

    if (w4<w8) {
;
    }
    else {
        t = w4;
        w4 = w8;
        w8 = t;
    }

    if (w0<w4) {
;
    }
    else {
        t = w0;
        w0 = w4;
        w4 = t;
    }

    if (w1<w4) {
;
    }
    else {
        t = w1;
        w1 = w4;
        w4 = t;
    }

    if (w7<w10) {
;
    }
    else {
        t = w7;
        w7 = w10;
        w10 = t;
    }

    if (w3<w8) {
;
    }
    else {
        t = w3;
        w3 = w8;
        w8 = t;
    }

    if (w2<w3) {
;
    }
    else {
        t = w2;
        w2 = w3;
        w3 = t;
    }

    if (w8<w9) {
;
    }
    else {
        t = w8;
        w8 = w9;
        w9 = t;
    }

    if (w2<w4) {
;
    }
    else {
        t = w2;
        w2 = w4;
        w4 = t;
    }

    if (w7<w9) {
;
    }
    else {
        t = w7;
        w7 = w9;
        w9 = t;
    }

    if (w3<w5) {
;
    }
    else {
        t = w3;
        w3 = w5;
        w5 = t;
    }

    if (w6<w8) {
;
    }
    else {
        t = w6;
        w6 = w8;
        w8 = t;
    }

    if (w3<w4) {
;
    }
    else {
        t = w3;
        w3 = w4;
        w4 = t;
    }

    if (w5<w6) {
;
    }
    else {
        t = w5;
        w5 = w6;
        w6 = t;
    }

    if (w7<w8) {
;
    }
    else {
        t = w7;
        w7 = w8;
        w8 = t;
    }

    output = (((((((((w0+w1)+w2)+w3)+w4)+w5)+w6)+w7)+w8)+w9)+w10;
    vars[0] = output;
    vars[1] = t;
    vars[2] = w0;
    vars[3] = w1;
    vars[4] = w10;
    vars[5] = w2;
    vars[6] = w3;
    vars[7] = w4;
    vars[8] = w5;
    vars[9] = w6;
    vars[10] = w7;
    vars[11] = w8;
    vars[12] = w9;
    return vars[0];
}
