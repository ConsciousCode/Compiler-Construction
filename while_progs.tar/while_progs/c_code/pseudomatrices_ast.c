#include <stdint.h>
int64_t pseudomatrices(int64_t vars[]) {
    int64_t a = vars[0], a__0__0 = vars[1], a__0__1 = vars[2], a__0__2 = vars[3], a__1__0 = vars[4], a__1__1 = vars[5], a__1__2 = vars[6], a__2__0 = vars[7], a__2__1 = vars[8], a__2__2 = vars[9], b = vars[10], b__0__0 = vars[11], b__0__1 = vars[12], b__0__2 = vars[13], b__1__0 = vars[14], b__1__1 = vars[15], b__1__2 = vars[16], b__2__0 = vars[17], b__2__1 = vars[18], b__2__2 = vars[19], c = vars[20], c__0__0 = vars[21], c__0__1 = vars[22], c__0__2 = vars[23], c__1__0 = vars[24], c__1__1 = vars[25], c__1__2 = vars[26], c__2__0 = vars[27], c__2__1 = vars[28], c__2__2 = vars[29], i = vars[30], j = vars[31], k = vars[32], output = vars[33], s = vars[34], t = vars[35];
    c__0__0 = 0;
    c__0__1 = 0;
    c__0__2 = 0;
    c__1__0 = 0;
    c__1__1 = 0;
    c__1__2 = 0;
    c__2__0 = 0;
    c__2__1 = 0;
    c__2__2 = 0;
    i = 0;
    while (i<3) {
        j = 0;
        while (j<3) {
            s = 0;
            k = 0;
            while (k<3) {
                if (i==0) {
                    if (k==0) {
                        a = a__0__0;
                    }
                    else {
                        if (k==1) {
                            a = a__0__1;
                        }
                        else {
                            if (k==2) {
                                a = a__0__2;
                            }
                            else {
                                a = 0;
                            }

                        }

                    }

                }
                else {
                    if (i==1) {
                        if (k==0) {
                            a = a__1__0;
                        }
                        else {
                            if (k==1) {
                                a = a__1__1;
                            }
                            else {
                                if (k==2) {
                                    a = a__1__2;
                                }
                                else {
                                    a = 0;
                                }

                            }

                        }

                    }
                    else {
                        if (i==2) {
                            if (k==0) {
                                a = a__2__0;
                            }
                            else {
                                if (k==1) {
                                    a = a__2__1;
                                }
                                else {
                                    if (k==2) {
                                        a = a__2__2;
                                    }
                                    else {
                                        a = 0;
                                    }

                                }

                            }

                        }
                        else {
                            a = 0;
                        }

                    }

                }

                if (k==0) {
                    if (j==0) {
                        b = b__0__0;
                    }
                    else {
                        if (j==1) {
                            b = b__0__1;
                        }
                        else {
                            if (j==2) {
                                b = b__0__2;
                            }
                            else {
                                b = 0;
                            }

                        }

                    }

                }
                else {
                    if (k==1) {
                        if (j==0) {
                            b = b__1__0;
                        }
                        else {
                            if (j==1) {
                                b = b__1__1;
                            }
                            else {
                                if (j==2) {
                                    b = b__1__2;
                                }
                                else {
                                    b = 0;
                                }

                            }

                        }

                    }
                    else {
                        if (k==2) {
                            if (j==0) {
                                b = b__2__0;
                            }
                            else {
                                if (j==1) {
                                    b = b__2__1;
                                }
                                else {
                                    if (j==2) {
                                        b = b__2__2;
                                    }
                                    else {
                                        b = 0;
                                    }

                                }

                            }

                        }
                        else {
                            b = 0;
                        }

                    }

                }

                s = s+(a*b);
                k = k+1;
            }

            if (i==0) {
                if (j==0) {
                    c__0__0 = s;
                }
                else {
                    if (j==1) {
                        c__0__1 = s;
                    }
                    else {
                        if (j==2) {
                            c__0__2 = s;
                        }
                        else {
;
                        }

                    }

                }

            }
            else {
                if (i==1) {
                    if (j==0) {
                        c__1__0 = s;
                    }
                    else {
                        if (j==1) {
                            c__1__1 = s;
                        }
                        else {
                            if (j==2) {
                                c__1__2 = s;
                            }
                            else {
;
                            }

                        }

                    }

                }
                else {
                    if (i==2) {
                        if (j==0) {
                            c__2__0 = s;
                        }
                        else {
                            if (j==1) {
                                c__2__1 = s;
                            }
                            else {
                                if (j==2) {
                                    c__2__2 = s;
                                }
                                else {
;
                                }

                            }

                        }

                    }
                    else {
;
                    }

                }

            }

            j = j+1;
        }

        i = i+1;
    }

    t = 0;
    i = 0;
    while (i<3) {
        j = 0;
        while (j<3) {
            if (i==0) {
                if (j==0) {
                    c = c__0__0;
                }
                else {
                    if (j==1) {
                        c = c__0__1;
                    }
                    else {
                        if (j==2) {
                            c = c__0__2;
                        }
                        else {
                            c = 0;
                        }

                    }

                }

            }
            else {
                if (i==1) {
                    if (j==0) {
                        c = c__1__0;
                    }
                    else {
                        if (j==1) {
                            c = c__1__1;
                        }
                        else {
                            if (j==2) {
                                c = c__1__2;
                            }
                            else {
                                c = 0;
                            }

                        }

                    }

                }
                else {
                    if (i==2) {
                        if (j==0) {
                            c = c__2__0;
                        }
                        else {
                            if (j==1) {
                                c = c__2__1;
                            }
                            else {
                                if (j==2) {
                                    c = c__2__2;
                                }
                                else {
                                    c = 0;
                                }

                            }

                        }

                    }
                    else {
                        c = 0;
                    }

                }

            }

            t = t+c;
            j = j+1;
        }

        i = i+1;
    }

    output = t;
    vars[0] = a;
    vars[1] = a__0__0;
    vars[2] = a__0__1;
    vars[3] = a__0__2;
    vars[4] = a__1__0;
    vars[5] = a__1__1;
    vars[6] = a__1__2;
    vars[7] = a__2__0;
    vars[8] = a__2__1;
    vars[9] = a__2__2;
    vars[10] = b;
    vars[11] = b__0__0;
    vars[12] = b__0__1;
    vars[13] = b__0__2;
    vars[14] = b__1__0;
    vars[15] = b__1__1;
    vars[16] = b__1__2;
    vars[17] = b__2__0;
    vars[18] = b__2__1;
    vars[19] = b__2__2;
    vars[20] = c;
    vars[21] = c__0__0;
    vars[22] = c__0__1;
    vars[23] = c__0__2;
    vars[24] = c__1__0;
    vars[25] = c__1__1;
    vars[26] = c__1__2;
    vars[27] = c__2__0;
    vars[28] = c__2__1;
    vars[29] = c__2__2;
    vars[30] = i;
    vars[31] = j;
    vars[32] = k;
    vars[33] = output;
    vars[34] = s;
    vars[35] = t;
    return vars[33];
}
