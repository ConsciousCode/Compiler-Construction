#include <stdint.h>
int64_t chain_prime(int64_t vars[]) {
    int64_t closestprime = 0, i = 0, input = vars[2], j = 0, mod = 0, output = 0, sqrt = 0, stop = 0, stop1 = 0;
label_0:
    mod = input;
    goto label_1;
label_1:
    if (!((mod==1)||(mod==0))) goto label_2;
    else goto label_3;
label_2:
    mod = mod-2;
    goto label_1;
label_3:
    if (mod==1) goto label_4;
    else goto label_5;
label_4:
    input = input-2;
    goto label_6;
label_5:
    input = input-1;
    goto label_6;
label_6:
    i = input;
    goto label_7;
label_7:
    stop1 = 0;
    goto label_8;
label_8:
    if ((i>=2)&&(stop1==0)) goto label_9;
    else goto label_24;
label_9:
    sqrt = 1;
    goto label_10;
label_10:
    if ((sqrt*sqrt)<=i) goto label_11;
    else goto label_12;
label_11:
    sqrt = sqrt+1;
    goto label_10;
label_12:
    j = 3;
    goto label_13;
label_13:
    stop = 0;
    goto label_14;
label_14:
    if ((j<=sqrt)&&(stop==0)) goto label_15;
    else goto label_21;
label_15:
    mod = i;
    goto label_16;
label_16:
    if (mod>0) goto label_17;
    else goto label_18;
label_17:
    mod = mod-j;
    goto label_16;
label_18:
    if (mod==0) goto label_19;
    else goto label_20;
label_19:
    stop = 1;
    goto label_14;
label_20:
    j = j+2;
    goto label_14;
label_21:
    if (j>sqrt) goto label_22;
    else goto label_23;
label_22:
    stop1 = 1;
    goto label_8;
label_23:
    i = i-2;
    goto label_8;
label_24:
    closestprime = i;
    goto label_25;
label_25:
    output = closestprime;
    goto label_26;
label_26:
    input = output;
    goto label_27;
label_27:
    mod = input;
    goto label_28;
label_28:
    if (!((mod==1)||(mod==0))) goto label_29;
    else goto label_30;
label_29:
    mod = mod-2;
    goto label_28;
label_30:
    if (mod==1) goto label_31;
    else goto label_32;
label_31:
    input = input-2;
    goto label_33;
label_32:
    input = input-1;
    goto label_33;
label_33:
    i = input;
    goto label_34;
label_34:
    stop1 = 0;
    goto label_35;
label_35:
    if ((i>=2)&&(stop1==0)) goto label_36;
    else goto label_51;
label_36:
    sqrt = 1;
    goto label_37;
label_37:
    if ((sqrt*sqrt)<=i) goto label_38;
    else goto label_39;
label_38:
    sqrt = sqrt+1;
    goto label_37;
label_39:
    j = 3;
    goto label_40;
label_40:
    stop = 0;
    goto label_41;
label_41:
    if ((j<=sqrt)&&(stop==0)) goto label_42;
    else goto label_48;
label_42:
    mod = i;
    goto label_43;
label_43:
    if (mod>0) goto label_44;
    else goto label_45;
label_44:
    mod = mod-j;
    goto label_43;
label_45:
    if (mod==0) goto label_46;
    else goto label_47;
label_46:
    stop = 1;
    goto label_41;
label_47:
    j = j+2;
    goto label_41;
label_48:
    if (j>sqrt) goto label_49;
    else goto label_50;
label_49:
    stop1 = 1;
    goto label_35;
label_50:
    i = i-2;
    goto label_35;
label_51:
    closestprime = i;
    goto label_52;
label_52:
    output = closestprime;
    goto label_53;
label_53:
    input = output;
    goto label_54;
label_54:
    mod = input;
    goto label_55;
label_55:
    if (!((mod==1)||(mod==0))) goto label_56;
    else goto label_57;
label_56:
    mod = mod-2;
    goto label_55;
label_57:
    if (mod==1) goto label_58;
    else goto label_59;
label_58:
    input = input-2;
    goto label_60;
label_59:
    input = input-1;
    goto label_60;
label_60:
    i = input;
    goto label_61;
label_61:
    stop1 = 0;
    goto label_62;
label_62:
    if ((i>=2)&&(stop1==0)) goto label_63;
    else goto label_78;
label_63:
    sqrt = 1;
    goto label_64;
label_64:
    if ((sqrt*sqrt)<=i) goto label_65;
    else goto label_66;
label_65:
    sqrt = sqrt+1;
    goto label_64;
label_66:
    j = 3;
    goto label_67;
label_67:
    stop = 0;
    goto label_68;
label_68:
    if ((j<=sqrt)&&(stop==0)) goto label_69;
    else goto label_75;
label_69:
    mod = i;
    goto label_70;
label_70:
    if (mod>0) goto label_71;
    else goto label_72;
label_71:
    mod = mod-j;
    goto label_70;
label_72:
    if (mod==0) goto label_73;
    else goto label_74;
label_73:
    stop = 1;
    goto label_68;
label_74:
    j = j+2;
    goto label_68;
label_75:
    if (j>sqrt) goto label_76;
    else goto label_77;
label_76:
    stop1 = 1;
    goto label_62;
label_77:
    i = i-2;
    goto label_62;
label_78:
    closestprime = i;
    goto label_79;
label_79:
    output = closestprime;
    goto label_80;
label_80:
    input = output;
    goto label_81;
label_81:
    mod = input;
    goto label_82;
label_82:
    if (!((mod==1)||(mod==0))) goto label_83;
    else goto label_84;
label_83:
    mod = mod-2;
    goto label_82;
label_84:
    if (mod==1) goto label_85;
    else goto label_86;
label_85:
    input = input-2;
    goto label_87;
label_86:
    input = input-1;
    goto label_87;
label_87:
    i = input;
    goto label_88;
label_88:
    stop1 = 0;
    goto label_89;
label_89:
    if ((i>=2)&&(stop1==0)) goto label_90;
    else goto label_105;
label_90:
    sqrt = 1;
    goto label_91;
label_91:
    if ((sqrt*sqrt)<=i) goto label_92;
    else goto label_93;
label_92:
    sqrt = sqrt+1;
    goto label_91;
label_93:
    j = 3;
    goto label_94;
label_94:
    stop = 0;
    goto label_95;
label_95:
    if ((j<=sqrt)&&(stop==0)) goto label_96;
    else goto label_102;
label_96:
    mod = i;
    goto label_97;
label_97:
    if (mod>0) goto label_98;
    else goto label_99;
label_98:
    mod = mod-j;
    goto label_97;
label_99:
    if (mod==0) goto label_100;
    else goto label_101;
label_100:
    stop = 1;
    goto label_95;
label_101:
    j = j+2;
    goto label_95;
label_102:
    if (j>sqrt) goto label_103;
    else goto label_104;
label_103:
    stop1 = 1;
    goto label_89;
label_104:
    i = i-2;
    goto label_89;
label_105:
    closestprime = i;
    goto label_106;
label_106:
    output = closestprime;
    goto label_107;
label_107:
    input = output;
    goto label_108;
label_108:
    mod = input;
    goto label_109;
label_109:
    if (!((mod==1)||(mod==0))) goto label_110;
    else goto label_111;
label_110:
    mod = mod-2;
    goto label_109;
label_111:
    if (mod==1) goto label_112;
    else goto label_113;
label_112:
    input = input-2;
    goto label_114;
label_113:
    input = input-1;
    goto label_114;
label_114:
    i = input;
    goto label_115;
label_115:
    stop1 = 0;
    goto label_116;
label_116:
    if ((i>=2)&&(stop1==0)) goto label_117;
    else goto label_132;
label_117:
    sqrt = 1;
    goto label_118;
label_118:
    if ((sqrt*sqrt)<=i) goto label_119;
    else goto label_120;
label_119:
    sqrt = sqrt+1;
    goto label_118;
label_120:
    j = 3;
    goto label_121;
label_121:
    stop = 0;
    goto label_122;
label_122:
    if ((j<=sqrt)&&(stop==0)) goto label_123;
    else goto label_129;
label_123:
    mod = i;
    goto label_124;
label_124:
    if (mod>0) goto label_125;
    else goto label_126;
label_125:
    mod = mod-j;
    goto label_124;
label_126:
    if (mod==0) goto label_127;
    else goto label_128;
label_127:
    stop = 1;
    goto label_122;
label_128:
    j = j+2;
    goto label_122;
label_129:
    if (j>sqrt) goto label_130;
    else goto label_131;
label_130:
    stop1 = 1;
    goto label_116;
label_131:
    i = i-2;
    goto label_116;
label_132:
    closestprime = i;
    goto label_133;
label_133:
    output = closestprime;
    goto label_134;
label_134:
    input = output;
    goto label_135;
label_135:
    mod = input;
    goto label_136;
label_136:
    if (!((mod==1)||(mod==0))) goto label_137;
    else goto label_138;
label_137:
    mod = mod-2;
    goto label_136;
label_138:
    if (mod==1) goto label_139;
    else goto label_140;
label_139:
    input = input-2;
    goto label_141;
label_140:
    input = input-1;
    goto label_141;
label_141:
    i = input;
    goto label_142;
label_142:
    stop1 = 0;
    goto label_143;
label_143:
    if ((i>=2)&&(stop1==0)) goto label_144;
    else goto label_159;
label_144:
    sqrt = 1;
    goto label_145;
label_145:
    if ((sqrt*sqrt)<=i) goto label_146;
    else goto label_147;
label_146:
    sqrt = sqrt+1;
    goto label_145;
label_147:
    j = 3;
    goto label_148;
label_148:
    stop = 0;
    goto label_149;
label_149:
    if ((j<=sqrt)&&(stop==0)) goto label_150;
    else goto label_156;
label_150:
    mod = i;
    goto label_151;
label_151:
    if (mod>0) goto label_152;
    else goto label_153;
label_152:
    mod = mod-j;
    goto label_151;
label_153:
    if (mod==0) goto label_154;
    else goto label_155;
label_154:
    stop = 1;
    goto label_149;
label_155:
    j = j+2;
    goto label_149;
label_156:
    if (j>sqrt) goto label_157;
    else goto label_158;
label_157:
    stop1 = 1;
    goto label_143;
label_158:
    i = i-2;
    goto label_143;
label_159:
    closestprime = i;
    goto label_160;
label_160:
    output = closestprime;
    goto label_161;
label_161:
    input = output;
    goto label_162;
label_162:
    mod = input;
    goto label_163;
label_163:
    if (!((mod==1)||(mod==0))) goto label_164;
    else goto label_165;
label_164:
    mod = mod-2;
    goto label_163;
label_165:
    if (mod==1) goto label_166;
    else goto label_167;
label_166:
    input = input-2;
    goto label_168;
label_167:
    input = input-1;
    goto label_168;
label_168:
    i = input;
    goto label_169;
label_169:
    stop1 = 0;
    goto label_170;
label_170:
    if ((i>=2)&&(stop1==0)) goto label_171;
    else goto label_186;
label_171:
    sqrt = 1;
    goto label_172;
label_172:
    if ((sqrt*sqrt)<=i) goto label_173;
    else goto label_174;
label_173:
    sqrt = sqrt+1;
    goto label_172;
label_174:
    j = 3;
    goto label_175;
label_175:
    stop = 0;
    goto label_176;
label_176:
    if ((j<=sqrt)&&(stop==0)) goto label_177;
    else goto label_183;
label_177:
    mod = i;
    goto label_178;
label_178:
    if (mod>0) goto label_179;
    else goto label_180;
label_179:
    mod = mod-j;
    goto label_178;
label_180:
    if (mod==0) goto label_181;
    else goto label_182;
label_181:
    stop = 1;
    goto label_176;
label_182:
    j = j+2;
    goto label_176;
label_183:
    if (j>sqrt) goto label_184;
    else goto label_185;
label_184:
    stop1 = 1;
    goto label_170;
label_185:
    i = i-2;
    goto label_170;
label_186:
    closestprime = i;
    goto label_187;
label_187:
    output = closestprime;
    goto label_188;
label_188:
    input = output;
    goto label_189;
label_189:
    mod = input;
    goto label_190;
label_190:
    if (!((mod==1)||(mod==0))) goto label_191;
    else goto label_192;
label_191:
    mod = mod-2;
    goto label_190;
label_192:
    if (mod==1) goto label_193;
    else goto label_194;
label_193:
    input = input-2;
    goto label_195;
label_194:
    input = input-1;
    goto label_195;
label_195:
    i = input;
    goto label_196;
label_196:
    stop1 = 0;
    goto label_197;
label_197:
    if ((i>=2)&&(stop1==0)) goto label_198;
    else goto label_213;
label_198:
    sqrt = 1;
    goto label_199;
label_199:
    if ((sqrt*sqrt)<=i) goto label_200;
    else goto label_201;
label_200:
    sqrt = sqrt+1;
    goto label_199;
label_201:
    j = 3;
    goto label_202;
label_202:
    stop = 0;
    goto label_203;
label_203:
    if ((j<=sqrt)&&(stop==0)) goto label_204;
    else goto label_210;
label_204:
    mod = i;
    goto label_205;
label_205:
    if (mod>0) goto label_206;
    else goto label_207;
label_206:
    mod = mod-j;
    goto label_205;
label_207:
    if (mod==0) goto label_208;
    else goto label_209;
label_208:
    stop = 1;
    goto label_203;
label_209:
    j = j+2;
    goto label_203;
label_210:
    if (j>sqrt) goto label_211;
    else goto label_212;
label_211:
    stop1 = 1;
    goto label_197;
label_212:
    i = i-2;
    goto label_197;
label_213:
    closestprime = i;
    goto label_214;
label_214:
    output = closestprime;
    goto label_215;
label_215:
    input = output;
    goto label_216;
label_216:
    mod = input;
    goto label_217;
label_217:
    if (!((mod==1)||(mod==0))) goto label_218;
    else goto label_219;
label_218:
    mod = mod-2;
    goto label_217;
label_219:
    if (mod==1) goto label_220;
    else goto label_221;
label_220:
    input = input-2;
    goto label_222;
label_221:
    input = input-1;
    goto label_222;
label_222:
    i = input;
    goto label_223;
label_223:
    stop1 = 0;
    goto label_224;
label_224:
    if ((i>=2)&&(stop1==0)) goto label_225;
    else goto label_240;
label_225:
    sqrt = 1;
    goto label_226;
label_226:
    if ((sqrt*sqrt)<=i) goto label_227;
    else goto label_228;
label_227:
    sqrt = sqrt+1;
    goto label_226;
label_228:
    j = 3;
    goto label_229;
label_229:
    stop = 0;
    goto label_230;
label_230:
    if ((j<=sqrt)&&(stop==0)) goto label_231;
    else goto label_237;
label_231:
    mod = i;
    goto label_232;
label_232:
    if (mod>0) goto label_233;
    else goto label_234;
label_233:
    mod = mod-j;
    goto label_232;
label_234:
    if (mod==0) goto label_235;
    else goto label_236;
label_235:
    stop = 1;
    goto label_230;
label_236:
    j = j+2;
    goto label_230;
label_237:
    if (j>sqrt) goto label_238;
    else goto label_239;
label_238:
    stop1 = 1;
    goto label_224;
label_239:
    i = i-2;
    goto label_224;
label_240:
    closestprime = i;
    goto label_241;
label_241:
    output = closestprime;
    goto label_242;
label_242:
    input = output;
    goto label_243;
label_243:
    mod = input;
    goto label_244;
label_244:
    if (!((mod==1)||(mod==0))) goto label_245;
    else goto label_246;
label_245:
    mod = mod-2;
    goto label_244;
label_246:
    if (mod==1) goto label_247;
    else goto label_248;
label_247:
    input = input-2;
    goto label_249;
label_248:
    input = input-1;
    goto label_249;
label_249:
    i = input;
    goto label_250;
label_250:
    stop1 = 0;
    goto label_251;
label_251:
    if ((i>=2)&&(stop1==0)) goto label_252;
    else goto label_267;
label_252:
    sqrt = 1;
    goto label_253;
label_253:
    if ((sqrt*sqrt)<=i) goto label_254;
    else goto label_255;
label_254:
    sqrt = sqrt+1;
    goto label_253;
label_255:
    j = 3;
    goto label_256;
label_256:
    stop = 0;
    goto label_257;
label_257:
    if ((j<=sqrt)&&(stop==0)) goto label_258;
    else goto label_264;
label_258:
    mod = i;
    goto label_259;
label_259:
    if (mod>0) goto label_260;
    else goto label_261;
label_260:
    mod = mod-j;
    goto label_259;
label_261:
    if (mod==0) goto label_262;
    else goto label_263;
label_262:
    stop = 1;
    goto label_257;
label_263:
    j = j+2;
    goto label_257;
label_264:
    if (j>sqrt) goto label_265;
    else goto label_266;
label_265:
    stop1 = 1;
    goto label_251;
label_266:
    i = i-2;
    goto label_251;
label_267:
    closestprime = i;
    goto label_268;
label_268:
    output = closestprime;
    goto exit;
exit:
    vars[0] = closestprime;
    vars[1] = i;
    vars[2] = input;
    vars[3] = j;
    vars[4] = mod;
    vars[5] = output;
    vars[6] = sqrt;
    vars[7] = stop;
    vars[8] = stop1;
    return vars[5];
}
