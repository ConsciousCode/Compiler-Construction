#include <stdint.h>
int64_t add(int64_t vars[]) {
    int64_t output = vars[0], x = vars[1], y = vars[2], z = vars[3];
    x = 1;
    y = 2;
    z = x+y;
    output = z;
    vars[0] = output;
    vars[1] = x;
    vars[2] = y;
    vars[3] = z;
    return vars[0];
}
