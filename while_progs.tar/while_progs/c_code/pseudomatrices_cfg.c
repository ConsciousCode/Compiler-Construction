#include <stdint.h>
int64_t pseudomatrices(int64_t vars[]) {
    int64_t a = 0, a__0__0 = vars[1], a__0__1 = vars[2], a__0__2 = vars[3], a__1__0 = vars[4], a__1__1 = vars[5], a__1__2 = vars[6], a__2__0 = vars[7], a__2__1 = vars[8], a__2__2 = vars[9], b = 0, b__0__0 = vars[11], b__0__1 = vars[12], b__0__2 = vars[13], b__1__0 = vars[14], b__1__1 = vars[15], b__1__2 = vars[16], b__2__0 = vars[17], b__2__1 = vars[18], b__2__2 = vars[19], c = 0, c__0__0 = 0, c__0__1 = 0, c__0__2 = 0, c__1__0 = 0, c__1__1 = 0, c__1__2 = 0, c__2__0 = 0, c__2__1 = 0, c__2__2 = 0, i = 0, j = 0, k = 0, output = 0, s = 0, t = 0;
label_0:
    c__0__0 = 0;
    goto label_1;
label_1:
    c__0__1 = 0;
    goto label_2;
label_2:
    c__0__2 = 0;
    goto label_3;
label_3:
    c__1__0 = 0;
    goto label_4;
label_4:
    c__1__1 = 0;
    goto label_5;
label_5:
    c__1__2 = 0;
    goto label_6;
label_6:
    c__2__0 = 0;
    goto label_7;
label_7:
    c__2__1 = 0;
    goto label_8;
label_8:
    c__2__2 = 0;
    goto label_9;
label_9:
    i = 0;
    goto label_10;
label_10:
    if (i<3) goto label_11;
    else goto label_95;
label_11:
    j = 0;
    goto label_12;
label_12:
    if (j<3) goto label_13;
    else goto label_94;
label_13:
    s = 0;
    goto label_14;
label_14:
    k = 0;
    goto label_15;
label_15:
    if (k<3) goto label_16;
    else goto label_68;
label_16:
    if (i==0) goto label_17;
    else goto label_24;
label_17:
    if (k==0) goto label_18;
    else goto label_19;
label_18:
    a = a__0__0;
    goto label_41;
label_19:
    if (k==1) goto label_20;
    else goto label_21;
label_20:
    a = a__0__1;
    goto label_41;
label_21:
    if (k==2) goto label_22;
    else goto label_23;
label_22:
    a = a__0__2;
    goto label_41;
label_23:
    a = 0;
    goto label_41;
label_24:
    if (i==1) goto label_25;
    else goto label_32;
label_25:
    if (k==0) goto label_26;
    else goto label_27;
label_26:
    a = a__1__0;
    goto label_41;
label_27:
    if (k==1) goto label_28;
    else goto label_29;
label_28:
    a = a__1__1;
    goto label_41;
label_29:
    if (k==2) goto label_30;
    else goto label_31;
label_30:
    a = a__1__2;
    goto label_41;
label_31:
    a = 0;
    goto label_41;
label_32:
    if (i==2) goto label_33;
    else goto label_40;
label_33:
    if (k==0) goto label_34;
    else goto label_35;
label_34:
    a = a__2__0;
    goto label_41;
label_35:
    if (k==1) goto label_36;
    else goto label_37;
label_36:
    a = a__2__1;
    goto label_41;
label_37:
    if (k==2) goto label_38;
    else goto label_39;
label_38:
    a = a__2__2;
    goto label_41;
label_39:
    a = 0;
    goto label_41;
label_40:
    a = 0;
    goto label_41;
label_41:
    if (k==0) goto label_42;
    else goto label_49;
label_42:
    if (j==0) goto label_43;
    else goto label_44;
label_43:
    b = b__0__0;
    goto label_66;
label_44:
    if (j==1) goto label_45;
    else goto label_46;
label_45:
    b = b__0__1;
    goto label_66;
label_46:
    if (j==2) goto label_47;
    else goto label_48;
label_47:
    b = b__0__2;
    goto label_66;
label_48:
    b = 0;
    goto label_66;
label_49:
    if (k==1) goto label_50;
    else goto label_57;
label_50:
    if (j==0) goto label_51;
    else goto label_52;
label_51:
    b = b__1__0;
    goto label_66;
label_52:
    if (j==1) goto label_53;
    else goto label_54;
label_53:
    b = b__1__1;
    goto label_66;
label_54:
    if (j==2) goto label_55;
    else goto label_56;
label_55:
    b = b__1__2;
    goto label_66;
label_56:
    b = 0;
    goto label_66;
label_57:
    if (k==2) goto label_58;
    else goto label_65;
label_58:
    if (j==0) goto label_59;
    else goto label_60;
label_59:
    b = b__2__0;
    goto label_66;
label_60:
    if (j==1) goto label_61;
    else goto label_62;
label_61:
    b = b__2__1;
    goto label_66;
label_62:
    if (j==2) goto label_63;
    else goto label_64;
label_63:
    b = b__2__2;
    goto label_66;
label_64:
    b = 0;
    goto label_66;
label_65:
    b = 0;
    goto label_66;
label_66:
    s = s+(a*b);
    goto label_67;
label_67:
    k = k+1;
    goto label_15;
label_68:
    if (i==0) goto label_69;
    else goto label_76;
label_69:
    if (j==0) goto label_70;
    else goto label_71;
label_70:
    c__0__0 = s;
    goto label_93;
label_71:
    if (j==1) goto label_72;
    else goto label_73;
label_72:
    c__0__1 = s;
    goto label_93;
label_73:
    if (j==2) goto label_74;
    else goto label_75;
label_74:
    c__0__2 = s;
    goto label_93;
label_75:
    goto label_93;
label_76:
    if (i==1) goto label_77;
    else goto label_84;
label_77:
    if (j==0) goto label_78;
    else goto label_79;
label_78:
    c__1__0 = s;
    goto label_93;
label_79:
    if (j==1) goto label_80;
    else goto label_81;
label_80:
    c__1__1 = s;
    goto label_93;
label_81:
    if (j==2) goto label_82;
    else goto label_83;
label_82:
    c__1__2 = s;
    goto label_93;
label_83:
    goto label_93;
label_84:
    if (i==2) goto label_85;
    else goto label_92;
label_85:
    if (j==0) goto label_86;
    else goto label_87;
label_86:
    c__2__0 = s;
    goto label_93;
label_87:
    if (j==1) goto label_88;
    else goto label_89;
label_88:
    c__2__1 = s;
    goto label_93;
label_89:
    if (j==2) goto label_90;
    else goto label_91;
label_90:
    c__2__2 = s;
    goto label_93;
label_91:
    goto label_93;
label_92:
    goto label_93;
label_93:
    j = j+1;
    goto label_12;
label_94:
    i = i+1;
    goto label_10;
label_95:
    t = 0;
    goto label_96;
label_96:
    i = 0;
    goto label_97;
label_97:
    if (i<3) goto label_98;
    else goto label_128;
label_98:
    j = 0;
    goto label_99;
label_99:
    if (j<3) goto label_100;
    else goto label_127;
label_100:
    if (i==0) goto label_101;
    else goto label_108;
label_101:
    if (j==0) goto label_102;
    else goto label_103;
label_102:
    c = c__0__0;
    goto label_125;
label_103:
    if (j==1) goto label_104;
    else goto label_105;
label_104:
    c = c__0__1;
    goto label_125;
label_105:
    if (j==2) goto label_106;
    else goto label_107;
label_106:
    c = c__0__2;
    goto label_125;
label_107:
    c = 0;
    goto label_125;
label_108:
    if (i==1) goto label_109;
    else goto label_116;
label_109:
    if (j==0) goto label_110;
    else goto label_111;
label_110:
    c = c__1__0;
    goto label_125;
label_111:
    if (j==1) goto label_112;
    else goto label_113;
label_112:
    c = c__1__1;
    goto label_125;
label_113:
    if (j==2) goto label_114;
    else goto label_115;
label_114:
    c = c__1__2;
    goto label_125;
label_115:
    c = 0;
    goto label_125;
label_116:
    if (i==2) goto label_117;
    else goto label_124;
label_117:
    if (j==0) goto label_118;
    else goto label_119;
label_118:
    c = c__2__0;
    goto label_125;
label_119:
    if (j==1) goto label_120;
    else goto label_121;
label_120:
    c = c__2__1;
    goto label_125;
label_121:
    if (j==2) goto label_122;
    else goto label_123;
label_122:
    c = c__2__2;
    goto label_125;
label_123:
    c = 0;
    goto label_125;
label_124:
    c = 0;
    goto label_125;
label_125:
    t = t+c;
    goto label_126;
label_126:
    j = j+1;
    goto label_99;
label_127:
    i = i+1;
    goto label_97;
label_128:
    output = t;
    goto exit;
exit:
    vars[0] = a;
    vars[1] = a__0__0;
    vars[2] = a__0__1;
    vars[3] = a__0__2;
    vars[4] = a__1__0;
    vars[5] = a__1__1;
    vars[6] = a__1__2;
    vars[7] = a__2__0;
    vars[8] = a__2__1;
    vars[9] = a__2__2;
    vars[10] = b;
    vars[11] = b__0__0;
    vars[12] = b__0__1;
    vars[13] = b__0__2;
    vars[14] = b__1__0;
    vars[15] = b__1__1;
    vars[16] = b__1__2;
    vars[17] = b__2__0;
    vars[18] = b__2__1;
    vars[19] = b__2__2;
    vars[20] = c;
    vars[21] = c__0__0;
    vars[22] = c__0__1;
    vars[23] = c__0__2;
    vars[24] = c__1__0;
    vars[25] = c__1__1;
    vars[26] = c__1__2;
    vars[27] = c__2__0;
    vars[28] = c__2__1;
    vars[29] = c__2__2;
    vars[30] = i;
    vars[31] = j;
    vars[32] = k;
    vars[33] = output;
    vars[34] = s;
    vars[35] = t;
    return vars[33];
}
