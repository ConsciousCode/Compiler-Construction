#include <stdint.h>
int64_t stress_factorial(int64_t vars[]) {
    int64_t i = 0, input = vars[1], output = 0, t = 0, x = 0, y = 0, z = 0;
label_0:
    x = input;
    goto label_1;
label_1:
    y = x;
    goto label_2;
label_2:
    z = 1;
    goto label_3;
label_3:
    if (y>1) goto label_4;
    else goto label_11;
label_4:
    t = 0;
    goto label_5;
label_5:
    i = z;
    goto label_6;
label_6:
    if (i>0) goto label_7;
    else goto label_9;
label_7:
    t = t+y;
    goto label_8;
label_8:
    i = i-1;
    goto label_6;
label_9:
    z = t;
    goto label_10;
label_10:
    y = y-1;
    goto label_3;
label_11:
    output = z;
    goto exit;
exit:
    vars[0] = i;
    vars[1] = input;
    vars[2] = output;
    vars[3] = t;
    vars[4] = x;
    vars[5] = y;
    vars[6] = z;
    return vars[2];
}
