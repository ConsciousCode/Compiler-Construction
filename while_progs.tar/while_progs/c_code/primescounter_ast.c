#include <stdint.h>
int64_t primescounter(int64_t vars[]) {
    int64_t count = vars[0], i = vars[1], k = vars[2], output = vars[3], range = vars[4], result = vars[5];
    result = 0;
    while (range>=2) {
        count = 0;
        i = 2;
        while ((i*i)<=range) {
            k = range;
            if (count>0) {
;
            }
            else {
                while (k>=1) {
                    if ((k*i)==range) {
                        count = count+1;
                    }
                    else {
;
                    }

                    k = k-1;
                }

            }

            i = i+1;
        }

        if (count>0) {
;
        }
        else {
            result = 1+result;
        }

        range = range-1;
    }

    output = result;
    vars[0] = count;
    vars[1] = i;
    vars[2] = k;
    vars[3] = output;
    vars[4] = range;
    vars[5] = result;
    return vars[3];
}
