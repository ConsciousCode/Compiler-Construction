#include <stdint.h>
int64_t closest_prime(int64_t vars[]) {
    int64_t closestprime = vars[0], i = vars[1], input = vars[2], j = vars[3], mod = vars[4], output = vars[5], sqrt = vars[6], stop = vars[7], stop1 = vars[8];
    mod = input;
    while (!((mod==1)||(mod==0))) {
        mod = mod-2;
    }

    if (mod==1) {
        input = input-2;
    }
    else {
        input = input-1;
    }

    i = input;
    stop1 = 0;
    while ((i>=2)&&(stop1==0)) {
        sqrt = 1;
        while ((sqrt*sqrt)<=i) {
            sqrt = sqrt+1;
        }

        j = 3;
        stop = 0;
        while ((j<=sqrt)&&(stop==0)) {
            mod = i;
            while (mod>0) {
                mod = mod-j;
            }

            if (mod==0) {
                stop = 1;
            }
            else {
                j = j+2;
            }

        }

        if (j>sqrt) {
            stop1 = 1;
        }
        else {
            i = i-2;
        }

    }

    closestprime = i;
    output = closestprime;
    vars[0] = closestprime;
    vars[1] = i;
    vars[2] = input;
    vars[3] = j;
    vars[4] = mod;
    vars[5] = output;
    vars[6] = sqrt;
    vars[7] = stop;
    vars[8] = stop1;
    return vars[5];
}
