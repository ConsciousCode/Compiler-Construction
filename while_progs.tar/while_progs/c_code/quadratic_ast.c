#include <stdint.h>
int64_t quadratic(int64_t vars[]) {
    int64_t a = vars[0], b = vars[1], c = vars[2], denominator = vars[3], discriminant = vars[4], guess = vars[5], last__guess = vars[6], n = vars[7], numerator1 = vars[8], numerator2 = vars[9], output = vars[10], quotient = vars[11], r1 = vars[12], r2 = vars[13], remainder = vars[14], roots = vars[15], sqrt__discriminant = vars[16];
    discriminant = (b*b)-((4*a)*c);
    if (discriminant<0) {
        roots = 0;
    }
    else {
        if (discriminant==0) {
            roots = 1;
            sqrt__discriminant = 0;
        }
        else {
            roots = 2;
            n = 50;
            last__guess = 0;
            guess = 1;
            while ((n>0)&&(!(last__guess==guess))) {
                last__guess = guess;
                quotient = 0;
                remainder = discriminant;
                while (remainder>=guess) {
                    quotient = quotient+1;
                    remainder = remainder-guess;
                }

                remainder = guess+quotient;
                quotient = 0;
                while (remainder>=2) {
                    quotient = quotient+1;
                    remainder = remainder-2;
                }

                guess = quotient;
            }

            sqrt__discriminant = guess;
        }

        denominator = 2*a;
        numerator1 = (0-b)-sqrt__discriminant;
        r1 = 0;
        while (numerator1>=denominator) {
            r1 = r1+1;
            numerator1 = numerator1-denominator;
        }

        while (numerator1<=(0-denominator)) {
            r1 = r1-1;
            numerator1 = numerator1+denominator;
        }

        if (roots>1) {
            numerator2 = (0-b)+sqrt__discriminant;
            r2 = 0;
            while (numerator2>=denominator) {
                r2 = r2+1;
                numerator2 = numerator2-denominator;
            }

            while (numerator2<=(0-denominator)) {
                r2 = r2-1;
                numerator2 = numerator2+denominator;
            }

        }
        else {
;
        }

    }

    output = roots;
    vars[0] = a;
    vars[1] = b;
    vars[2] = c;
    vars[3] = denominator;
    vars[4] = discriminant;
    vars[5] = guess;
    vars[6] = last__guess;
    vars[7] = n;
    vars[8] = numerator1;
    vars[9] = numerator2;
    vars[10] = output;
    vars[11] = quotient;
    vars[12] = r1;
    vars[13] = r2;
    vars[14] = remainder;
    vars[15] = roots;
    vars[16] = sqrt__discriminant;
    return vars[10];
}
