#include <stdint.h>
int64_t collatz(int64_t vars[]) {
    int64_t input = vars[0], n = 0, output = 0, quot = 0, rem = 0, steps = 0;
label_0:
    n = input;
    goto label_1;
label_1:
    steps = 0;
    goto label_2;
label_2:
    if (n>1) goto label_3;
    else goto label_12;
label_3:
    rem = n;
    goto label_4;
label_4:
    quot = 0;
    goto label_5;
label_5:
    if (rem>1) goto label_6;
    else goto label_8;
label_6:
    rem = rem-2;
    goto label_7;
label_7:
    quot = quot+1;
    goto label_5;
label_8:
    if (rem==0) goto label_9;
    else goto label_10;
label_9:
    n = quot;
    goto label_11;
label_10:
    n = (3*n)+1;
    goto label_11;
label_11:
    steps = steps+1;
    goto label_2;
label_12:
    output = steps;
    goto exit;
exit:
    vars[0] = input;
    vars[1] = n;
    vars[2] = output;
    vars[3] = quot;
    vars[4] = rem;
    vars[5] = steps;
    return vars[2];
}
