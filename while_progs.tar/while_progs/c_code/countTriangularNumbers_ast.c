#include <stdint.h>
int64_t countTriangularNumbers(int64_t vars[]) {
    int64_t count = vars[0], goUpToNumber = vars[1], i = vars[2], isNumFact = vars[3], n = vars[4], output = vars[5], sum = vars[6];
    isNumFact = 0;
    sum = 0;
    n = 1;
    count = 0;
    while (i<goUpToNumber) {
        while (sum<=i) {
            sum = sum+n;
            if (sum==i) {
                isNumFact = 1;
                sum = i+1;
            }
            else {
;
            }

            n = n+1;
        }

        if (isNumFact==1) {
            count = count+1;
        }
        else {
;
        }

        isNumFact = 0;
        sum = 0;
        n = 1;
        i = i+1;
    }

    output = count;
    vars[0] = count;
    vars[1] = goUpToNumber;
    vars[2] = i;
    vars[3] = isNumFact;
    vars[4] = n;
    vars[5] = output;
    vars[6] = sum;
    return vars[5];
}
